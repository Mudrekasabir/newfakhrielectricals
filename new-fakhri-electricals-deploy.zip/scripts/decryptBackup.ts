// Usage: npx tsx scripts/decryptBackup.ts path/to/2026-09-13.enc
// Prints the decrypted JSON snapshot to stdout — redirect to a file if
// you want to keep it: npx tsx scripts/decryptBackup.ts backup.enc > snapshot.json
//
// Requires BACKUP_ENCRYPTION_KEY in your environment (the same key used to
// encrypt it — see .env.example).
import { readFileSync } from "fs";
import { decrypt } from "../src/lib/backup";

const filePath = process.argv[2];
if (!filePath) {
  console.error("Usage: npx tsx scripts/decryptBackup.ts path/to/backup.enc");
  process.exit(1);
}

const key = process.env.BACKUP_ENCRYPTION_KEY;
if (!key) {
  console.error("Set BACKUP_ENCRYPTION_KEY in your environment first.");
  process.exit(1);
}

const encrypted = readFileSync(filePath, "utf8").trim();
const json = decrypt(encrypted, key);
console.log(json);
