# New Fakhri Electricals

Sales and supplier management system. Built with Next.js, MySQL (via Prisma),
and NextAuth. Deploys to Vercel.

This is **Phase 1–3** of the build: project setup, database schema, and the
login/role system with the Sales/Suppliers entry screen. Phases 4–6 (the
actual Sales and Suppliers screens, and live chat) come next.

## 1. Install dependencies

```bash
npm install
```

## 2. Set up the MySQL database

Vercel does not host MySQL itself — pick one managed provider:

- **PlanetScale** (recommended, generous free tier, built-in backups)
- **Railway**
- **Aiven**

Create a database, then copy its connection string.

## 3. Configure environment variables

Copy `.env.example` to `.env` and fill in:

```bash
cp .env.example .env
```

- `DATABASE_URL` — the MySQL connection string from step 2.
- `NEXTAUTH_SECRET` — generate one with `openssl rand -base64 32`.
- `NEXTAUTH_URL` — `http://localhost:3000` for local dev.

## 4. Create the database tables

```bash
npm run prisma:migrate
```

This reads `prisma/schema.prisma` and creates every table in your MySQL
database (users, customers, sales, suppliers, supplier bills, chat, audit
log — the full list is in that file).

## 5. Create the first admin login

```bash
npm run prisma:seed
```

This prints an email and temporary password to the terminal. **Log in once
and change the password immediately** — there is no separate "change
password" screen yet, so for now that means updating the user's row directly
or through an admin screen we'll add in a later phase. If you want a specific
email/password instead of the default, set `SEED_ADMIN_EMAIL` and
`SEED_ADMIN_PASSWORD` env vars before running the seed command.

## 6. Run it locally

```bash
npm run dev
```

Visit `http://localhost:3000` — it redirects to `/login`. Sign in with the
seeded admin account, and you'll land on the entry screen with Sales and
Suppliers options.

## 7. Deploy to Vercel

1. Push this project to a GitHub repo.
2. Import the repo in Vercel.
3. Add the same environment variables (`DATABASE_URL`, `NEXTAUTH_SECRET`,
   `NEXTAUTH_URL` — set this to your Vercel URL, e.g.
   `https://new-fakhri-electricals.vercel.app`) in the Vercel project
   settings.
4. Deploy. No domain needed yet — the free `*.vercel.app` URL works fine
   until you buy one.

## How access control works

- Every account has a role: `ADMIN`, `SALES`, or `SUPPLIER_STAFF`.
- `ADMIN` sees both Sales and Suppliers on the entry screen. `SALES` only
  sees Sales, `SUPPLIER_STAFF` only sees Suppliers.
- This is enforced in two places on purpose: the entry screen only *shows*
  the links a role can use, and `src/middleware.ts` blocks the actual page
  even if someone types the URL directly. The second one is what actually
  matters for security — never rely on hiding a link alone.

## What's next (Phases 4–6)

- **Phase 4:** real Sales screens — customers, invoices, product catalog,
  sales history.
- **Phase 5:** real Suppliers screens — supplier records, bill uploads,
  payment tracking.
- **Phase 6:** live chat between customers and staff, using Pusher or Ably
  (Vercel's serverless functions can't hold an open connection, so real-time
  chat needs one of these).

## Supplier bills — how file storage works

Suppliers module has no purchase-order or product-catalog concept — staff
just record which supplier a bill is from, its total amount, and a photo or
PDF of the bill itself as proof. No line items, no product descriptions.

Uploaded bill files (JPG/PNG/WEBP/PDF, capped at 4MB each) are stored
directly in the MySQL database as a `Bytes`/`LONGBLOB` column, not on disk or
in cloud storage — this keeps setup to just the one database with no extra
service or env vars to configure. That's fine at small-shop volume, but if
bill uploads grow heavy over time (thousands of scanned invoices), it's
worth moving file storage to something like S3 or Cloudinary later; the
upload/read code is isolated to `src/app/api/supplier-bills/` so that swap
wouldn't touch the rest of the app.

## Security notes already in place

- Passwords are hashed with bcrypt, never stored in plain text.
- Login errors never reveal whether an email exists in the system.
- Security headers (`X-Frame-Options`, `X-Content-Type-Options`, etc.) are
  set on every response in `next.config.js`.
- `src/lib/audit.ts` provides a `logAudit()` helper — call it from every
  route that creates, edits, or deletes a sale, supplier, or payment, so
  there's always a record of who changed what.
