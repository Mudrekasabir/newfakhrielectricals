import "next-auth";
import "next-auth/jwt";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: "ADMIN" | "SALES" | "SUPPLIER_STAFF";
      name?: string | null;
      email?: string | null;
    };
  }

  interface User {
    id: string;
    role: "ADMIN" | "SALES" | "SUPPLIER_STAFF";
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string;
    role: "ADMIN" | "SALES" | "SUPPLIER_STAFF";
  }
}
