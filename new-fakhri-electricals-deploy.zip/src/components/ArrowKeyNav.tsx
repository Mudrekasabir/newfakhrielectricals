"use client";

import { useEffect } from "react";

// The ordered set of pages behind each area's tab strip (SalesNav /
// SuppliersNav). Kept as a plain lookup here rather than scraped from the
// DOM because SalesNav tucks most of its links inside a closed "Manage
// records" dropdown — they wouldn't exist in the DOM to scrape until a
// staff member opened it. If those nav components' routes change, update
// the matching list below too.
const ROUTE_GROUPS: string[][] = [
  ["/sales", "/sales/customers", "/sales/customers/ledger", "/sales/products", "/sales/new", "/sales/history"],
  ["/suppliers", "/suppliers/bills", "/suppliers/payments", "/suppliers/history"],
];

function isInsideAField(el: Element | null): boolean {
  if (!el) return false;
  const tag = el.tagName;
  if (tag === "TEXTAREA" || tag === "SELECT") return true;
  if (tag === "INPUT") {
    const type = (el as HTMLInputElement).type;
    return !["checkbox", "radio", "file", "submit", "button", "reset"].includes(type);
  }
  return false;
}

/**
 * Left/Right arrow keys "slide" between the pages in the current section
 * (Sales' Message customers/Customers/Products/etc, or Suppliers'
 * Suppliers/Bills/Payments/History) — a quick way to flip between screens
 * without reaching for the tabs at the top.
 *
 * Only engages when focus isn't sitting inside a text field, a <select>,
 * or the command palette, so it never steals the left/right arrows someone
 * is using to move a text cursor. Mounted once in the root layout.
 */
export default function ArrowKeyNav() {
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
      if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;

      const active = document.activeElement;
      if (isInsideAField(active)) return;
      if (active?.closest(".cmdk-panel")) return;
      if (document.querySelector(".cmdk-backdrop")) return; // palette is open

      const path = window.location.pathname;
      const group = ROUTE_GROUPS.find((g) => g.includes(path));
      if (!group) return;

      const currentIndex = group.indexOf(path);
      const nextIndex = e.key === "ArrowRight" ? currentIndex + 1 : currentIndex - 1;
      const href = group[nextIndex];
      if (!href) return; // already at the first/last page in this section

      e.preventDefault();

      const content = document.querySelector<HTMLElement>(".content");
      if (content) {
        content.classList.add(e.key === "ArrowRight" ? "arrow-nav-exit-left" : "arrow-nav-exit-right");
      }
      // A brief pause lets the exit animation actually play before the
      // (full, server-rendered) page navigation swaps everything out.
      window.setTimeout(() => {
        window.location.href = href;
      }, 110);
    }

    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  return null;
}
