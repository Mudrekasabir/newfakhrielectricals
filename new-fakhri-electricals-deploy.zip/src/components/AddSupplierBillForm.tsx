"use client";

import { useRef, useState } from "react";

export type SupplierBillRecord = {
  id: string;
  supplierId: string;
  supplierName: string;
  supplierPhone?: string;
  billNumber: string | null;
  amount: number;
  billDate: string | null;
  note: string | null;
  fileName: string;
  fileType: string;
  createdAt: string;
  createdByName: string;
};

type SupplierOption = { id: string; name: string };

export default function AddSupplierBillForm({
  suppliers,
  fixedSupplierId,
  onCreated,
}: {
  suppliers: SupplierOption[];
  /** When set (e.g. on a supplier's own page) the supplier picker is hidden. */
  fixedSupplierId?: string;
  onCreated: (bill: SupplierBillRecord) => void;
}) {
  const [supplierId, setSupplierId] = useState(fixedSupplierId || "");
  const [amount, setAmount] = useState("");
  const [billNumber, setBillNumber] = useState("");
  const [billDate, setBillDate] = useState("");
  const [note, setNote] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const amountNum = Number(amount);
    if (!supplierId) {
      setError("Select a supplier");
      return;
    }
    if (!Number.isFinite(amountNum) || amountNum <= 0) {
      setError("Enter the bill's total amount");
      return;
    }
    if (!file) {
      setError("Attach the supplier's bill — a photo or PDF");
      return;
    }

    const form = new FormData();
    form.append("supplierId", supplierId);
    form.append("amount", String(amountNum));
    if (billNumber.trim()) form.append("billNumber", billNumber.trim());
    if (billDate) form.append("billDate", billDate);
    if (note.trim()) form.append("note", note.trim());
    form.append("file", file);

    setSubmitting(true);
    const res = await fetch("/api/supplier-bills", { method: "POST", body: form });
    setSubmitting(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Could not upload the bill — try again");
      return;
    }

    const saved: SupplierBillRecord = await res.json();
    onCreated(saved);

    if (!fixedSupplierId) setSupplierId("");
    setAmount("");
    setBillNumber("");
    setBillDate("");
    setNote("");
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  return (
    <form onSubmit={handleSubmit} className="panel" style={{ marginBottom: 24 }}>
      <h2 style={{ fontSize: 18, marginTop: 0 }}>Upload a bill</h2>

      {error && <p className="error-text">{error}</p>}

      <div className="form-row">
        {!fixedSupplierId && (
          <div className="field" style={{ flex: 2, minWidth: 180 }}>
            <label htmlFor="bill-supplier">Supplier</label>
            <select id="bill-supplier" value={supplierId} onChange={(e) => setSupplierId(e.target.value)} required>
              <option value="">Select a supplier…</option>
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        )}
        <div className="field" style={{ flex: 1, minWidth: 120 }}>
          <label htmlFor="bill-amount">Total amount</label>
          <input
            id="bill-amount"
            type="number"
            min="0"
            step="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>
        <div className="field" style={{ flex: 1, minWidth: 140 }}>
          <label htmlFor="bill-number">Bill / invoice # (optional)</label>
          <input id="bill-number" value={billNumber} onChange={(e) => setBillNumber(e.target.value)} />
        </div>
        <div className="field" style={{ flex: 1, minWidth: 150 }}>
          <label htmlFor="bill-date">Bill date (optional)</label>
          <input id="bill-date" type="date" value={billDate} onChange={(e) => setBillDate(e.target.value)} />
        </div>
      </div>

      <div className="form-row">
        <div className="field" style={{ flex: 2, minWidth: 200 }}>
          <label htmlFor="bill-note">Note (optional)</label>
          <input id="bill-note" value={note} onChange={(e) => setNote(e.target.value)} />
        </div>
        <div className="field" style={{ flex: 2, minWidth: 220 }}>
          <label htmlFor="bill-file">Bill photo or PDF</label>
          <input
            id="bill-file"
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/heic,image/heif,application/pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            required
          />
        </div>
        <button type="submit" className="btn-primary" disabled={submitting} style={{ marginBottom: 18 }}>
          {submitting ? "Uploading…" : "Upload bill"}
        </button>
      </div>
      <p className="muted" style={{ margin: 0 }}>
        JPG, PNG, WEBP, or PDF — up to 4MB.
      </p>
    </form>
  );
}
