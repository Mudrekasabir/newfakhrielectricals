"use client";

import { useState } from "react";
import { balanceTagClass, formatBalance } from "@/lib/balanceFormat";

type Supplier = { id: string; name: string; phone: string; address: string | null };
type BalanceInfo = { balance: number; bills: number; payments: number };

export default function SuppliersManager({
  initialSuppliers,
  initialBalances,
}: {
  initialSuppliers: Supplier[];
  initialBalances: Record<string, BalanceInfo>;
}) {
  const [suppliers, setSuppliers] = useState(initialSuppliers);
  const [balances] = useState(initialBalances);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editAddress, setEditAddress] = useState("");
  const [editError, setEditError] = useState<string | null>(null);
  const [editSaving, setEditSaving] = useState(false);

  function startEdit(s: Supplier) {
    setEditingId(s.id);
    setEditName(s.name);
    setEditPhone(s.phone);
    setEditAddress(s.address || "");
    setEditError(null);
  }

  function cancelEdit() {
    setEditingId(null);
    setEditError(null);
  }

  function handleEditKeyDown(e: React.KeyboardEvent<HTMLInputElement>, id: string) {
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      saveEdit(id);
    } else if (e.key === "Escape") {
      e.preventDefault();
      cancelEdit();
    }
  }

  async function saveEdit(id: string) {
    setEditError(null);
    if (!editName.trim() || !editPhone.trim()) {
      setEditError("Name and phone are required");
      return;
    }
    setEditSaving(true);
    const res = await fetch(`/api/suppliers/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: editName.trim(),
        phone: editPhone.trim(),
        address: editAddress.trim() || null,
      }),
    });
    setEditSaving(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setEditError(data.error || "Could not save changes — try again");
      return;
    }

    const saved: Supplier = await res.json();
    setSuppliers((prev) => prev.map((s) => (s.id === id ? saved : s)));
    setEditingId(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!name.trim() || !phone.trim()) {
      setError("Name and phone are required");
      return;
    }

    const tempId = `temp-${Date.now()}`;
    const payload = { name: name.trim(), phone: phone.trim(), address: address.trim() || null };

    setSuppliers((prev) => [{ id: tempId, ...payload }, ...prev]);
    setName("");
    setPhone("");
    setAddress("");
    setSubmitting(true);

    const res = await fetch("/api/suppliers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setSubmitting(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setSuppliers((prev) => prev.filter((s) => s.id !== tempId));
      setError(data.error || "Could not add the supplier — try again");
      setName(payload.name);
      setPhone(payload.phone);
      setAddress(payload.address || "");
      return;
    }

    const saved: Supplier = await res.json();
    setSuppliers((prev) => prev.map((s) => (s.id === tempId ? saved : s)));
  }

  return (
    <>
      <form onSubmit={handleSubmit} className="panel" style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 18, marginTop: 0 }}>Add a supplier</h2>

        {error && <p className="error-text">{error}</p>}

        <div className="form-row">
          <div className="field" style={{ flex: 2, minWidth: 180 }}>
            <label htmlFor="name">Name</label>
            <input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="field" style={{ flex: 1, minWidth: 140 }}>
            <label htmlFor="phone">Phone</label>
            <input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} required />
          </div>
          <div className="field" style={{ flex: 2, minWidth: 180 }}>
            <label htmlFor="address">Address (optional)</label>
            <input id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>
          <button type="submit" className="btn-primary" style={{ marginBottom: 18 }}>
            Add supplier
          </button>
        </div>
      </form>

      <div className="panel">
        {suppliers.length === 0 ? (
          <p className="muted">No suppliers yet — add the first one above.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Balance</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {suppliers.map((s) => {
                const info = balances[s.id];
                const isPending = s.id.startsWith("temp-") && submitting;
                const isEditing = editingId === s.id;

                if (isEditing) {
                  return (
                    <tr key={s.id} className="table-row-hover">
                      <td>
                        <input
                          autoFocus
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          onKeyDown={(e) => handleEditKeyDown(e, s.id)}
                          style={{ width: "100%" }}
                        />
                      </td>
                      <td>
                        <input
                          value={editPhone}
                          onChange={(e) => setEditPhone(e.target.value)}
                          onKeyDown={(e) => handleEditKeyDown(e, s.id)}
                          style={{ width: "100%" }}
                        />
                      </td>
                      <td>
                        <input
                          value={editAddress}
                          onChange={(e) => setEditAddress(e.target.value)}
                          onKeyDown={(e) => handleEditKeyDown(e, s.id)}
                          style={{ width: "100%" }}
                        />
                      </td>
                      <td>
                        {info ? (
                          <span className={balanceTagClass(info.balance)}>{formatBalance(info.balance)}</span>
                        ) : (
                          <span className="tag tag-paid">Fully settled</span>
                        )}
                      </td>
                      <td>
                        <div style={{ display: "flex", gap: 8 }}>
                          <button type="button" className="btn-primary" disabled={editSaving} onClick={() => saveEdit(s.id)}>
                            {editSaving ? "Saving…" : "Save"}
                          </button>
                          <button type="button" className="btn-secondary" disabled={editSaving} onClick={cancelEdit}>
                            Cancel
                          </button>
                        </div>
                        {editError && <p className="error-text" style={{ margin: "6px 0 0" }}>{editError}</p>}
                      </td>
                    </tr>
                  );
                }

                return (
                  <tr key={s.id} className="table-row-hover" style={isPending ? { opacity: 0.6 } : undefined}>
                    <td>
                      {s.id.startsWith("temp-") ? (
                        s.name
                      ) : (
                        <a href={`/suppliers/${s.id}`} style={{ color: "inherit", textDecoration: "underline" }}>
                          {s.name}
                        </a>
                      )}
                    </td>
                    <td>{s.phone}</td>
                    <td>{s.address || "—"}</td>
                    <td>
                      {info ? (
                        <span
                          className={balanceTagClass(info.balance)}
                          title={`${info.bills} bill${info.bills === 1 ? "" : "s"} · ${info.payments} payment${info.payments === 1 ? "" : "s"}`}
                        >
                          {formatBalance(info.balance)}
                        </span>
                      ) : (
                        <span className="tag tag-paid">Fully settled</span>
                      )}
                    </td>
                    <td>
                      {!s.id.startsWith("temp-") && (
                        <div style={{ display: "flex", gap: 8 }}>
                          <a href={`/suppliers/${s.id}`} className="btn-secondary" style={{ textDecoration: "none" }}>
                            View
                          </a>
                          <button type="button" className="btn-secondary" onClick={() => startEdit(s)}>
                            Edit
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
