"use client";

import { useState } from "react";

type Product = { id: string; name: string; sku: string; unit: string; unitPrice: number };

const COMMON_UNITS = ["pcs", "meter", "kg", "box", "packet", "roll", "litre", "pair"];

export default function ProductsManager({ initialProducts }: { initialProducts: Product[] }) {
  const [products, setProducts] = useState(initialProducts);

  const [name, setName] = useState("");
  const [sku, setSku] = useState("");
  const [unit, setUnit] = useState("pcs");
  const [unitPrice, setUnitPrice] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<Product | null>(null);
  const [editError, setEditError] = useState<string | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const priceNum = Number(unitPrice);
    if (!name.trim() || !sku.trim() || !unit.trim() || !Number.isFinite(priceNum) || priceNum < 0) {
      setError("Name, SKU, unit, and a valid price are required");
      return;
    }

    const tempId = `temp-${Date.now()}`;
    const payload = { name: name.trim(), sku: sku.trim(), unit: unit.trim(), unitPrice: priceNum };

    setProducts((prev) => [...prev, { id: tempId, ...payload }].sort((a, b) => a.name.localeCompare(b.name)));
    setName("");
    setSku("");
    setUnit("pcs");
    setUnitPrice("");
    setSubmitting(true);

    const res = await fetch("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setSubmitting(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setProducts((prev) => prev.filter((p) => p.id !== tempId));
      setError(data.error || "Could not add the product — try again");
      setName(payload.name);
      setSku(payload.sku);
      setUnit(payload.unit);
      setUnitPrice(String(payload.unitPrice));
      return;
    }

    const saved: Product = await res.json();
    setProducts((prev) => prev.map((p) => (p.id === tempId ? saved : p)));
  }

  function startEdit(p: Product) {
    setEditingId(p.id);
    setEditDraft({ ...p });
    setEditError(null);
  }

  function cancelEdit() {
    setEditingId(null);
    setEditDraft(null);
    setEditError(null);
  }

  async function saveEdit() {
    if (!editDraft) return;
    const priceNum = Number(editDraft.unitPrice);
    if (!editDraft.name.trim() || !editDraft.sku.trim() || !editDraft.unit.trim() || !Number.isFinite(priceNum) || priceNum < 0) {
      setEditError("Name, SKU, unit, and a valid price are required");
      return;
    }

    setSavingEdit(true);
    setEditError(null);
    const res = await fetch(`/api/products/${editDraft.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: editDraft.name.trim(),
        sku: editDraft.sku.trim(),
        unit: editDraft.unit.trim(),
        unitPrice: priceNum,
      }),
    });
    setSavingEdit(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setEditError(data.error || "Could not save changes");
      return;
    }

    const saved: Product = await res.json();
    setProducts((prev) => prev.map((p) => (p.id === saved.id ? saved : p)).sort((a, b) => a.name.localeCompare(b.name)));
    cancelEdit();
  }

  return (
    <>
      <form onSubmit={handleSubmit} className="panel" style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 18, marginTop: 0 }}>Add a product</h2>

        {error && <p className="error-text">{error}</p>}

        <div className="form-row">
          <div className="field" style={{ flex: 2, minWidth: 180 }}>
            <label htmlFor="name">Name</label>
            <input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="field" style={{ flex: 1, minWidth: 120 }}>
            <label htmlFor="sku">SKU</label>
            <input id="sku" value={sku} onChange={(e) => setSku(e.target.value)} required />
          </div>
          <div className="field" style={{ flex: 1, minWidth: 120 }}>
            <label htmlFor="unit">Unit</label>
            <input id="unit" list="unit-options" value={unit} onChange={(e) => setUnit(e.target.value)} required />
            <datalist id="unit-options">
              {COMMON_UNITS.map((u) => (
                <option key={u} value={u} />
              ))}
            </datalist>
          </div>
          <div className="field" style={{ flex: 1, minWidth: 120 }}>
            <label htmlFor="unitPrice">Price per unit</label>
            <input
              id="unitPrice"
              type="number"
              min="0"
              step="0.01"
              value={unitPrice}
              onChange={(e) => setUnitPrice(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn-primary" style={{ marginBottom: 18 }}>
            Add product
          </button>
        </div>
      </form>

      <div className="panel">
        {products.length === 0 ? (
          <p className="muted">No products yet — add the first one above.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>SKU</th>
                <th>Unit</th>
                <th>Price per unit</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => {
                const isPending = p.id.startsWith("temp-") && submitting;
                const isEditing = editingId === p.id;

                if (isEditing && editDraft) {
                  return (
                    <tr key={p.id}>
                      <td>
                        <input value={editDraft.name} onChange={(e) => setEditDraft({ ...editDraft, name: e.target.value })} />
                      </td>
                      <td>
                        <input value={editDraft.sku} onChange={(e) => setEditDraft({ ...editDraft, sku: e.target.value })} />
                      </td>
                      <td>
                        <input
                          list="unit-options"
                          value={editDraft.unit}
                          onChange={(e) => setEditDraft({ ...editDraft, unit: e.target.value })}
                        />
                      </td>
                      <td>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={editDraft.unitPrice}
                          onChange={(e) => setEditDraft({ ...editDraft, unitPrice: Number(e.target.value) })}
                        />
                      </td>
                      <td style={{ whiteSpace: "nowrap" }}>
                        <button type="button" className="btn-primary" onClick={saveEdit} disabled={savingEdit}>
                          Save
                        </button>{" "}
                        <button type="button" className="btn-secondary" onClick={cancelEdit}>
                          Cancel
                        </button>
                        {editError && <p className="error-text">{editError}</p>}
                      </td>
                    </tr>
                  );
                }

                return (
                  <tr key={p.id} className="table-row-hover" style={isPending ? { opacity: 0.6 } : undefined}>
                    <td>{p.name}</td>
                    <td>{p.sku}</td>
                    <td>{p.unit}</td>
                    <td>{Number(p.unitPrice).toFixed(2)}</td>
                    <td>
                      <button type="button" className="btn-secondary" onClick={() => startEdit(p)}>
                        Edit
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
