"use client";

import { signOut } from "next-auth/react";

export default function SignOutButton() {
  return (
    <button
      onClick={() => signOut({ callbackUrl: "/login" })}
      className="muted"
      style={{ background: "none", border: "none", cursor: "pointer", textDecoration: "underline" }}
    >
      Sign out
    </button>
  );
}
