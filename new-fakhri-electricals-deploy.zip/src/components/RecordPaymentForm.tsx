"use client";

import { useEffect, useState } from "react";
import { buildWhatsAppLink, buildSmsLink, smsBodySeparator } from "@/lib/messageLinks";
import { renderSupplierPaymentReceipt, todayDateLabel } from "@/lib/receiptTemplates";

const PAYMENT_METHODS = ["Cash", "Bank Transfer", "UPI", "Cheque", "Card", "Other"];

type Supplier = { id: string; name: string; phone: string };
type BillOption = { id: string; billNumber: string | null; amount: number };
export type SupplierPaymentRecord = {
  id: string;
  createdAt: string;
  amount: number;
  method: string | null;
  reference: string | null;
  note: string | null;
  supplierId: string;
  supplierName: string;
  supplierPhone: string;
  billId: string | null;
  billLabel: string | null;
};

export default function RecordPaymentForm({
  suppliers,
  initialPayments,
}: {
  suppliers: Supplier[];
  initialPayments: SupplierPaymentRecord[];
}) {
  const [payments, setPayments] = useState(initialPayments);
  const [supplierId, setSupplierId] = useState("");
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("Cash");
  const [reference, setReference] = useState("");
  const [billId, setBillId] = useState("");
  const [billOptions, setBillOptions] = useState<BillOption[]>([]);
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setBillId("");
    if (!supplierId) {
      setBillOptions([]);
      return;
    }
    let cancelled = false;
    fetch(`/api/supplier-bills?supplierId=${supplierId}`)
      .then((res) => (res.ok ? res.json() : []))
      .then((data) => {
        if (!cancelled) setBillOptions(data);
      })
      .catch(() => {
        if (!cancelled) setBillOptions([]);
      });
    return () => {
      cancelled = true;
    };
  }, [supplierId]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const amountNum = Number(amount);
    if (!supplierId || !Number.isFinite(amountNum) || amountNum <= 0) {
      setError("Select a supplier and enter an amount above zero");
      return;
    }

    setSubmitting(true);
    const res = await fetch("/api/supplier-payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        supplierId,
        amount: amountNum,
        method: method || null,
        reference: reference || null,
        note: note || null,
        billId: billId || null,
      }),
    });
    setSubmitting(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Could not record the payment");
      return;
    }

    const saved: SupplierPaymentRecord = await res.json();
    setPayments((prev) => [saved, ...prev]);
    setSupplierId("");
    setAmount("");
    setMethod("Cash");
    setReference("");
    setBillId("");
    setNote("");
  }

  function sendReceipt(payment: SupplierPaymentRecord, channel: "WHATSAPP" | "SMS") {
    if (!payment.supplierPhone) return;
    const template = renderSupplierPaymentReceipt({
      supplierName: payment.supplierName,
      amount: payment.amount,
      method: payment.method,
      reference: payment.reference,
      note: payment.note,
      date: todayDateLabel(),
    });
    const pdfUrl = `${window.location.origin}/api/supplier-payments/${payment.id}/pdf`;
    const body = `${template}\n\nPayment voucher PDF: ${pdfUrl}`;
    const url =
      channel === "WHATSAPP"
        ? buildWhatsAppLink(payment.supplierPhone, body)
        : buildSmsLink(payment.supplierPhone, body, smsBodySeparator());
    window.open(url, "_blank");
  }

  return (
    <>
      <form onSubmit={handleSubmit} className="panel" style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 18, marginTop: 0 }}>Record a payment</h2>

        {error && <p className="error-text">{error}</p>}

        <div className="form-row">
          <div className="field" style={{ flex: 2, minWidth: 180 }}>
            <label htmlFor="supplier">Supplier</label>
            <select id="supplier" value={supplierId} onChange={(e) => setSupplierId(e.target.value)} required>
              <option value="">Select a supplier…</option>
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <div className="field" style={{ flex: 1, minWidth: 120 }}>
            <label htmlFor="amount">Amount</label>
            <input id="amount" type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} required />
          </div>
          <div className="field" style={{ flex: 1, minWidth: 140 }}>
            <label htmlFor="method">Method</label>
            <select id="method" value={method} onChange={(e) => setMethod(e.target.value)}>
              {PAYMENT_METHODS.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>
          <div className="field" style={{ flex: 1, minWidth: 150 }}>
            <label htmlFor="reference">Reference (optional)</label>
            <input id="reference" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="UTR, cheque no…" />
          </div>
        </div>

        <div className="form-row">
          <div className="field" style={{ flex: 2, minWidth: 200 }}>
            <label htmlFor="bill">Apply to a bill (optional)</label>
            <select id="bill" value={billId} onChange={(e) => setBillId(e.target.value)} disabled={!supplierId || billOptions.length === 0}>
              <option value="">
                {!supplierId ? "Select a supplier first" : billOptions.length === 0 ? "No bills on file" : "Not tied to a specific bill"}
              </option>
              {billOptions.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.billNumber || "Bill"} — Rs.{b.amount.toFixed(2)}
                </option>
              ))}
            </select>
          </div>
          <div className="field" style={{ flex: 2, minWidth: 180 }}>
            <label htmlFor="note">Note (optional)</label>
            <input id="note" value={note} onChange={(e) => setNote(e.target.value)} />
          </div>
          <button type="submit" className="btn-primary" disabled={submitting} style={{ marginBottom: 18 }}>
            Record payment
          </button>
        </div>
      </form>

      <div className="panel">
        {payments.length === 0 ? (
          <p className="muted">No payments recorded yet.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Supplier</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Reference</th>
                <th>Against bill</th>
                <th>Note</th>
                <th>Receipt</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((p) => (
                <tr key={p.id}>
                  <td>
                    {new Date(p.createdAt).toLocaleString("en-IN", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </td>
                  <td>
                    <a href={`/suppliers/${p.supplierId}`} style={{ color: "inherit", textDecoration: "underline" }}>
                      {p.supplierName}
                    </a>
                  </td>
                  <td>Rs.{p.amount.toFixed(2)}</td>
                  <td>{p.method || "—"}</td>
                  <td>{p.reference || "—"}</td>
                  <td>{p.billLabel || "—"}</td>
                  <td>{p.note || "—"}</td>
                  <td>
                    {p.supplierPhone ? (
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        <button type="button" className="btn-secondary" onClick={() => sendReceipt(p, "WHATSAPP")}>
                          WhatsApp
                        </button>
                        <button type="button" className="btn-secondary" onClick={() => sendReceipt(p, "SMS")}>
                          SMS
                        </button>
                        <a
                          href={`/api/supplier-payments/${p.id}/pdf`}
                          target="_blank"
                          rel="noreferrer"
                          className="btn-secondary"
                          style={{ textDecoration: "none" }}
                        >
                          View PDF
                        </a>
                      </div>
                    ) : (
                      <span className="muted">No phone</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
