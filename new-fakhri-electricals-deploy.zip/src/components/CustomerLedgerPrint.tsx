"use client";

import { useMemo, useState } from "react";
import { formatBalance, balanceTagClass } from "@/lib/balanceFormat";
import { SHOP_NAME, SHOP_ADDRESS, SHOP_PHONE } from "@/lib/receiptTemplates";

export type LedgerRow = {
  id: string;
  name: string;
  phone: string;
  address: string | null;
  balance: number;
};

type Filter = "all" | "due" | "credit" | "settled";

export default function CustomerLedgerPrint({ rows }: { rows: LedgerRow[] }) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("all");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows
      .filter((r) => {
        if (q && !r.name.toLowerCase().includes(q) && !r.phone.includes(q)) return false;
        if (filter === "due" && !(r.balance > 0.004)) return false;
        if (filter === "credit" && !(r.balance < -0.004)) return false;
        if (filter === "settled" && Math.abs(r.balance) > 0.004) return false;
        return true;
      })
      .sort((a, b) => b.balance - a.balance);
  }, [rows, query, filter]);

  const totalDue = filtered.reduce((sum, r) => (r.balance > 0 ? sum + r.balance : sum), 0);
  const totalCredit = filtered.reduce((sum, r) => (r.balance < 0 ? sum + Math.abs(r.balance) : sum), 0);
  const netOutstanding = totalDue - totalCredit;

  const today = new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });

  return (
    <div>
      <div className="panel no-print" style={{ marginBottom: 20, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
        <input
          type="text"
          placeholder="Search by name or phone…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={{ flex: "1 1 240px", minWidth: 200 }}
        />
        <div style={{ display: "flex", gap: 6 }}>
          {(["all", "due", "credit", "settled"] as Filter[]).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={filter === f ? "btn-primary" : "btn-secondary"}
              style={{ textTransform: "capitalize" }}
            >
              {f}
            </button>
          ))}
        </div>
        <button type="button" className="btn-primary" style={{ marginLeft: "auto" }} onClick={() => window.print()}>
          🖨 Print ledger
        </button>
      </div>

      <div className="panel ledger-print-area" style={{ marginBottom: 24 }}>
        <div className="ledger-print-header">
          <h1 style={{ margin: "0 0 2px", fontSize: 22 }}>{SHOP_NAME}</h1>
          <p className="muted" style={{ margin: "0 0 2px", fontSize: 14 }}>
            {SHOP_ADDRESS} · {SHOP_PHONE}
          </p>
          <h2 style={{ margin: "10px 0 2px", fontSize: 18 }}>Customer Ledger — Dues &amp; Balances</h2>
          <p className="muted" style={{ margin: 0, fontSize: 14 }}>
            Generated on {today} · {filtered.length} customer{filtered.length === 1 ? "" : "s"}
            {filter !== "all" ? ` · filtered: ${filter}` : ""}
          </p>
        </div>

        <div style={{ display: "flex", gap: 32, flexWrap: "wrap", margin: "16px 0" }}>
          <div>
            <p className="muted" style={{ margin: "0 0 4px", fontSize: 14 }}>
              Total dues
            </p>
            <p style={{ margin: 0, fontSize: 20, fontWeight: 700 }}>Rs.{totalDue.toFixed(2)}</p>
          </div>
          <div>
            <p className="muted" style={{ margin: "0 0 4px", fontSize: 14 }}>
              Total credit
            </p>
            <p style={{ margin: 0, fontSize: 20, fontWeight: 700 }}>Rs.{totalCredit.toFixed(2)}</p>
          </div>
          <div>
            <p className="muted" style={{ margin: "0 0 4px", fontSize: 14 }}>
              Net outstanding
            </p>
            <p style={{ margin: 0, fontSize: 20, fontWeight: 700 }}>{formatBalance(netOutstanding)}</p>
          </div>
        </div>

        {filtered.length === 0 ? (
          <p className="muted">No customers match this view.</p>
        ) : (
          <table className="table ledger-table">
            <thead>
              <tr>
                <th style={{ width: 36 }}>#</th>
                <th>Customer name</th>
                <th>Phone</th>
                <th className="no-print">Address</th>
                <th style={{ textAlign: "right" }}>Balance</th>
                <th className="no-print">Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r, i) => (
                <tr key={r.id} className="table-row-hover">
                  <td>{i + 1}</td>
                  <td>{r.name}</td>
                  <td>{r.phone}</td>
                  <td className="no-print">{r.address || "—"}</td>
                  <td style={{ textAlign: "right", fontWeight: 600 }}>
                    {r.balance > 0.004 ? "+" : r.balance < -0.004 ? "-" : ""}Rs.{Math.abs(r.balance).toFixed(2)}
                  </td>
                  <td className="no-print">
                    <span className={balanceTagClass(r.balance)}>{formatBalance(r.balance)}</span>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={4} style={{ textAlign: "right", fontWeight: 700 }}>
                  Net outstanding
                </td>
                <td style={{ textAlign: "right", fontWeight: 700 }}>Rs.{netOutstanding.toFixed(2)}</td>
                <td className="no-print"></td>
              </tr>
            </tfoot>
          </table>
        )}

        <p className="muted ledger-print-footer" style={{ marginTop: 24, fontSize: 13 }}>
          This is a system-generated ledger. Balances are computed from recorded sales, payments and returns as of the
          generation date above.
        </p>
      </div>
    </div>
  );
}
