export default function SuppliersNav() {
  return (
    <div className="section-nav">
      <a href="/suppliers">Suppliers</a>
      <a href="/suppliers/bills">Bills</a>
      <a href="/suppliers/payments">Payments</a>
      <a href="/suppliers/history">History</a>
    </div>
  );
}
