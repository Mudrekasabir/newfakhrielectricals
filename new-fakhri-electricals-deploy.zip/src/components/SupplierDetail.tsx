"use client";

import { useMemo, useState } from "react";
import { balanceTagClass, formatBalance } from "@/lib/balanceFormat";
import { buildWhatsAppLink, buildSmsLink, smsBodySeparator } from "@/lib/messageLinks";
import { renderSupplierPaymentReceipt, todayDateLabel } from "@/lib/receiptTemplates";
import AddSupplierBillForm, { SupplierBillRecord } from "@/components/AddSupplierBillForm";
import type { SupplierPaymentRecord } from "@/components/RecordPaymentForm";

const PAYMENT_METHODS = ["Cash", "Bank Transfer", "UPI", "Cheque", "Card", "Other"];

type Supplier = { id: string; name: string; phone: string; address: string | null };

function formatDateTime(iso: string) {
  return new Date(iso).toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

export default function SupplierDetail({
  supplier,
  initialBills,
  initialPayments,
}: {
  supplier: Supplier;
  initialBills: SupplierBillRecord[];
  initialPayments: SupplierPaymentRecord[];
}) {
  const [contact, setContact] = useState(supplier);
  const [bills, setBills] = useState(initialBills);
  const [payments, setPayments] = useState(initialPayments);

  // ---- Contact card editing ----
  const [editingContact, setEditingContact] = useState(false);
  const [editName, setEditName] = useState(contact.name);
  const [editPhone, setEditPhone] = useState(contact.phone);
  const [editAddress, setEditAddress] = useState(contact.address || "");
  const [contactError, setContactError] = useState<string | null>(null);
  const [contactSaving, setContactSaving] = useState(false);

  function startEditContact() {
    setEditName(contact.name);
    setEditPhone(contact.phone);
    setEditAddress(contact.address || "");
    setContactError(null);
    setEditingContact(true);
  }

  function handleContactKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      saveContact();
    } else if (e.key === "Escape") {
      e.preventDefault();
      setEditingContact(false);
    }
  }

  async function saveContact() {
    setContactError(null);
    if (!editName.trim() || !editPhone.trim()) {
      setContactError("Name and phone are required");
      return;
    }
    setContactSaving(true);
    const res = await fetch(`/api/suppliers/${contact.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: editName.trim(), phone: editPhone.trim(), address: editAddress.trim() || null }),
    });
    setContactSaving(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setContactError(data.error || "Could not save changes — try again");
      return;
    }

    const saved = await res.json();
    setContact(saved);
    setEditingContact(false);
  }

  // ---- Record payment ----
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("Cash");
  const [reference, setReference] = useState("");
  const [billId, setBillId] = useState("");
  const [note, setNote] = useState("");
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [paymentSubmitting, setPaymentSubmitting] = useState(false);

  async function handleRecordPayment(e: React.FormEvent) {
    e.preventDefault();
    setPaymentError(null);

    const amountNum = Number(amount);
    if (!Number.isFinite(amountNum) || amountNum <= 0) {
      setPaymentError("Enter an amount above zero");
      return;
    }

    setPaymentSubmitting(true);
    const res = await fetch("/api/supplier-payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        supplierId: contact.id,
        amount: amountNum,
        method: method || null,
        reference: reference || null,
        note: note || null,
        billId: billId || null,
      }),
    });
    setPaymentSubmitting(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setPaymentError(data.error || "Could not record the payment");
      return;
    }

    const saved: SupplierPaymentRecord = await res.json();
    setPayments((prev) => [saved, ...prev]);
    setAmount("");
    setMethod("Cash");
    setReference("");
    setBillId("");
    setNote("");
  }

  function sendReceipt(payment: SupplierPaymentRecord, channel: "WHATSAPP" | "SMS") {
    if (!contact.phone) return;
    const template = renderSupplierPaymentReceipt({
      supplierName: contact.name,
      amount: payment.amount,
      method: payment.method,
      reference: payment.reference,
      note: payment.note,
      date: todayDateLabel(),
    });
    const pdfUrl = `${window.location.origin}/api/supplier-payments/${payment.id}/pdf`;
    const body = `${template}\n\nPayment voucher PDF: ${pdfUrl}`;
    const url =
      channel === "WHATSAPP"
        ? buildWhatsAppLink(contact.phone, body)
        : buildSmsLink(contact.phone, body, smsBodySeparator());
    window.open(url, "_blank");
  }

  // ---- Balance + merged ledger ----
  const balance = useMemo(
    () => bills.reduce((sum, b) => sum + b.amount, 0) - payments.reduce((sum, p) => sum + p.amount, 0),
    [bills, payments]
  );

  const ledger = useMemo(() => {
    type Entry =
      | { kind: "bill"; id: string; date: string; amount: number; bill: SupplierBillRecord }
      | { kind: "payment"; id: string; date: string; amount: number; payment: SupplierPaymentRecord };

    const entries: Entry[] = [
      ...bills.map((b) => ({ kind: "bill" as const, id: b.id, date: b.createdAt, amount: b.amount, bill: b })),
      ...payments.map((p) => ({ kind: "payment" as const, id: p.id, date: p.createdAt, amount: p.amount, payment: p })),
    ].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let running = 0;
    const withRunning = entries.map((e) => {
      running += e.kind === "bill" ? e.amount : -e.amount;
      return { ...e, runningBalance: running };
    });
    return withRunning.reverse(); // newest first
  }, [bills, payments]);

  return (
    <>
      <div className="panel" style={{ marginBottom: 24 }}>
        {editingContact ? (
          <>
            {contactError && <p className="error-text">{contactError}</p>}
            <div className="form-row">
              <div className="field" style={{ flex: 2, minWidth: 180 }}>
                <label>Name</label>
                <input autoFocus value={editName} onChange={(e) => setEditName(e.target.value)} onKeyDown={handleContactKeyDown} />
              </div>
              <div className="field" style={{ flex: 1, minWidth: 140 }}>
                <label>Phone</label>
                <input value={editPhone} onChange={(e) => setEditPhone(e.target.value)} onKeyDown={handleContactKeyDown} />
              </div>
              <div className="field" style={{ flex: 2, minWidth: 180 }}>
                <label>Address</label>
                <input value={editAddress} onChange={(e) => setEditAddress(e.target.value)} onKeyDown={handleContactKeyDown} />
              </div>
              <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
                <button type="button" className="btn-primary" disabled={contactSaving} onClick={saveContact}>
                  {contactSaving ? "Saving…" : "Save"}
                </button>
                <button type="button" className="btn-secondary" disabled={contactSaving} onClick={() => setEditingContact(false)}>
                  Cancel
                </button>
              </div>
            </div>
          </>
        ) : (
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 16 }}>
            <div>
              <h1 style={{ fontSize: 22, margin: "0 0 6px" }}>{contact.name}</h1>
              <p className="muted" style={{ margin: "0 0 2px" }}>{contact.phone}</p>
              <p className="muted" style={{ margin: 0 }}>{contact.address || "No address on file"}</p>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <span className={balanceTagClass(balance)} style={{ fontSize: 18, padding: "6px 14px" }}>
                {formatBalance(balance)}
              </span>
              <button type="button" className="btn-secondary" onClick={startEditContact}>
                Edit contact
              </button>
            </div>
          </div>
        )}
      </div>

      <AddSupplierBillForm
        suppliers={[{ id: contact.id, name: contact.name }]}
        fixedSupplierId={contact.id}
        onCreated={(bill) => setBills((prev) => [bill, ...prev])}
      />

      <form onSubmit={handleRecordPayment} className="panel" style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 18, marginTop: 0 }}>Record a payment</h2>

        {paymentError && <p className="error-text">{paymentError}</p>}

        <div className="form-row">
          <div className="field" style={{ flex: 1, minWidth: 120 }}>
            <label htmlFor="payment-amount">Amount</label>
            <input id="payment-amount" type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} required />
          </div>
          <div className="field" style={{ flex: 1, minWidth: 140 }}>
            <label htmlFor="payment-method">Method</label>
            <select id="payment-method" value={method} onChange={(e) => setMethod(e.target.value)}>
              {PAYMENT_METHODS.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>
          <div className="field" style={{ flex: 1, minWidth: 150 }}>
            <label htmlFor="payment-reference">Reference (optional)</label>
            <input id="payment-reference" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="UTR, cheque no…" />
          </div>
          <div className="field" style={{ flex: 2, minWidth: 200 }}>
            <label htmlFor="payment-bill">Apply to a bill (optional)</label>
            <select id="payment-bill" value={billId} onChange={(e) => setBillId(e.target.value)} disabled={bills.length === 0}>
              <option value="">{bills.length === 0 ? "No bills on file" : "Not tied to a specific bill"}</option>
              {bills.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.billNumber || "Bill"} — Rs.{b.amount.toFixed(2)} ({formatDate(b.createdAt)})
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="form-row">
          <div className="field" style={{ flex: 2, minWidth: 200 }}>
            <label htmlFor="payment-note">Note (optional)</label>
            <input id="payment-note" value={note} onChange={(e) => setNote(e.target.value)} />
          </div>
          <button type="submit" className="btn-primary" disabled={paymentSubmitting} style={{ marginBottom: 18 }}>
            {paymentSubmitting ? "Recording…" : "Record payment"}
          </button>
        </div>
      </form>

      <div className="panel">
        <h2 style={{ fontSize: 18, marginTop: 0 }}>Transaction history</h2>
        {ledger.length === 0 ? (
          <p className="muted">No bills or payments recorded yet — upload a bill or record a payment above.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Details</th>
                <th>Amount</th>
                <th>Balance after</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {ledger.map((entry) => {
                if (entry.kind === "bill") {
                  const b = entry.bill;
                  return (
                    <tr key={`bill-${entry.id}`} className="table-row-hover">
                      <td>{formatDateTime(entry.date)}</td>
                      <td>
                        <span className="tag tag-due">Bill</span>
                      </td>
                      <td>
                        {b.billNumber ? `${b.billNumber} — ` : ""}
                        {b.note || "—"}
                      </td>
                      <td>+Rs.{b.amount.toFixed(2)}</td>
                      <td>{formatBalance(entry.runningBalance)}</td>
                      <td>
                        <a
                          href={`/api/supplier-bills/${b.id}/file`}
                          target="_blank"
                          rel="noreferrer"
                          className="btn-secondary"
                          style={{ textDecoration: "none" }}
                        >
                          View bill
                        </a>
                      </td>
                    </tr>
                  );
                }

                const p = entry.payment;
                return (
                  <tr key={`payment-${entry.id}`} className="table-row-hover">
                    <td>{formatDateTime(entry.date)}</td>
                    <td>
                      <span className="tag tag-paid">Payment</span>
                    </td>
                    <td>
                      {p.method || "—"}
                      {p.reference ? ` · ${p.reference}` : ""}
                      {p.billLabel ? ` · against ${p.billLabel}` : ""}
                      {p.note ? ` · ${p.note}` : ""}
                    </td>
                    <td>-Rs.{p.amount.toFixed(2)}</td>
                    <td>{formatBalance(entry.runningBalance)}</td>
                    <td>
                      {contact.phone && (
                        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                          <button type="button" className="btn-secondary" onClick={() => sendReceipt(p, "WHATSAPP")}>
                            WhatsApp
                          </button>
                          <button type="button" className="btn-secondary" onClick={() => sendReceipt(p, "SMS")}>
                            SMS
                          </button>
                          <a
                            href={`/api/supplier-payments/${p.id}/pdf`}
                            target="_blank"
                            rel="noreferrer"
                            className="btn-secondary"
                            style={{ textDecoration: "none" }}
                          >
                            View PDF
                          </a>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
