"use client";

import { useEffect, useRef, useState } from "react";

export default function SalesNav() {
  const [menuOpen, setMenuOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setMenuOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="section-nav">
      <a href="/sales">Message customers</a>

      <div className="section-nav-more" ref={ref}>
        <button type="button" onClick={() => setMenuOpen((v) => !v)}>
          Manage records ▾
        </button>
        {menuOpen && (
          <div className="section-nav-more-menu">
            <a href="/sales/customers">Customers</a>
            <a href="/sales/customers/ledger">Customer ledger (print)</a>
            <a href="/sales/products">Products</a>
            <a href="/sales/new">New sale</a>
            <a href="/sales/history">Sales history</a>
          </div>
        )}
      </div>
    </div>
  );
}
