"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type Customer = { id: string; name: string; phone: string };
type Product = { id: string; name: string; unit: string; unitPrice: number };

const CUSTOM_VALUE = "__custom__";

// productId is set when picked from the catalog. When it's CUSTOM_VALUE,
// customName/customPrice hold a one-off item that isn't in the catalog.
type Row = { productId: string; customName: string; customPrice: string; quantity: number };

export default function NewSaleForm({ customers, products }: { customers: Customer[]; products: Product[] }) {
  const router = useRouter();
  const [customerId, setCustomerId] = useState("");
  const [rows, setRows] = useState<Row[]>([{ productId: "", customName: "", customPrice: "", quantity: 1 }]);
  const [paidAmount, setPaidAmount] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const total = useMemo(() => {
    return rows.reduce((sum, row) => {
      if (row.productId === CUSTOM_VALUE) {
        return sum + Number(row.customPrice || 0) * (row.quantity || 0);
      }
      const product = products.find((p) => p.id === row.productId);
      if (!product) return sum;
      return sum + product.unitPrice * (row.quantity || 0);
    }, 0);
  }, [rows, products]);

  function updateRow(index: number, patch: Partial<Row>) {
    setRows((prev) => prev.map((r, i) => (i === index ? { ...r, ...patch } : r)));
  }

  function addRow() {
    setRows((prev) => [...prev, { productId: "", customName: "", customPrice: "", quantity: 1 }]);
  }

  // Ref on the item-rows container (see data-kbd-nav-scope below) — when
  // KeyboardFormNav runs out of fields to move to inside it (i.e. Enter or
  // ArrowDown was pressed in the last field of the last row), it fires this
  // event instead of doing nothing, so staff can keep adding rows without
  // touching the "+ Add another item" button.
  const itemRowsRef = useRef<HTMLDivElement>(null);
  // Set right before adding a row from the keyboard shortcut, then consumed
  // by the effect below once the new row has actually committed to the DOM.
  // (A plain setTimeout here raced the render and could leave focus behind
  // on the old field — this doesn't.)
  const focusNewRowRef = useRef(false);

  function handleAddRowShortcut() {
    focusNewRowRef.current = true;
    addRow();
  }

  useEffect(() => {
    if (!focusNewRowRef.current) return;
    focusNewRowRef.current = false;
    const selects = itemRowsRef.current?.querySelectorAll<HTMLSelectElement>("select");
    const last = selects && selects[selects.length - 1];
    last?.focus();
  }, [rows.length]);

  useEffect(() => {
    const el = itemRowsRef.current;
    if (!el) return;
    el.addEventListener("kbdnav:add-row", handleAddRowShortcut);
    return () => el.removeEventListener("kbdnav:add-row", handleAddRowShortcut);
  });

  function removeRow(index: number) {
    setRows((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!customerId) {
      setError("Select a customer");
      return;
    }

    const items = [];
    for (const row of rows) {
      if (!row.productId || row.quantity <= 0) continue;
      if (row.productId === CUSTOM_VALUE) {
        if (!row.customName.trim() || !(Number(row.customPrice) > 0)) continue;
        items.push({ customName: row.customName.trim(), unitPrice: Number(row.customPrice), quantity: row.quantity });
      } else {
        items.push({ productId: row.productId, quantity: row.quantity });
      }
    }

    if (items.length === 0) {
      setError("Add at least one item — pick a product or type a custom item with a price");
      return;
    }

    setLoading(true);
    const res = await fetch("/api/sales", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customerId,
        items,
        paidAmount: Number(paidAmount || 0),
      }),
    });
    setLoading(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Could not record the sale");
      return;
    }

    router.push("/sales/history");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="panel">
      {error && <p className="error-text">{error}</p>}

      <div className="field" style={{ maxWidth: 340 }}>
        <label htmlFor="customer">Customer</label>
        <select id="customer" value={customerId} onChange={(e) => setCustomerId(e.target.value)} required>
          <option value="">Select a customer…</option>
          {customers.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} — {c.phone}
            </option>
          ))}
        </select>
      </div>

      <p className="muted" style={{ margin: "20px 0 8px" }}>
        Items <span style={{ fontWeight: 400 }}>— press Enter or ↓ in the last field to add another row</span>
      </p>

      <div ref={itemRowsRef} data-kbd-nav-scope>
        {rows.map((row, index) => {
        const isCustom = row.productId === CUSTOM_VALUE;
        const product = products.find((p) => p.id === row.productId);
        return (
          <div className="form-row" key={index} style={{ marginBottom: 12, alignItems: "flex-start" }}>
            <div className="field" style={{ flex: 2, minWidth: 200, marginBottom: 0 }}>
              <select value={row.productId} onChange={(e) => updateRow(index, { productId: e.target.value })}>
                <option value="">Select a product…</option>
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.unit})
                  </option>
                ))}
                <option value={CUSTOM_VALUE}>+ Custom item (not in catalog)…</option>
              </select>
              {isCustom && (
                <input
                  style={{ marginTop: 8 }}
                  placeholder="Item name, e.g. 2m Copper Wire"
                  value={row.customName}
                  onChange={(e) => updateRow(index, { customName: e.target.value })}
                />
              )}
            </div>
            <div className="field" style={{ flex: 1, minWidth: 100, marginBottom: 0 }}>
              <input
                type="number"
                min="1"
                value={row.quantity}
                onChange={(e) => updateRow(index, { quantity: Number(e.target.value) })}
              />
              {!isCustom && product && (
                <p className="muted" style={{ margin: "4px 0 0", fontSize: 16 }}>
                  Qty in {product.unit}
                </p>
              )}
              {isCustom && (
                <input
                  style={{ marginTop: 8 }}
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="Price each"
                  value={row.customPrice}
                  onChange={(e) => updateRow(index, { customPrice: e.target.value })}
                />
              )}
            </div>
            <span className="muted" style={{ minWidth: 90 }}>
              {isCustom
                ? (Number(row.customPrice || 0) * row.quantity).toFixed(2)
                : product
                  ? (product.unitPrice * row.quantity).toFixed(2)
                  : "—"}
            </span>
            {rows.length > 1 && (
              <button type="button" className="btn-secondary" onClick={() => removeRow(index)} data-kbd-nav-skip>
                Remove
              </button>
            )}
          </div>
        );
        })}
      </div>

      <button type="button" className="btn-secondary" onClick={addRow} style={{ marginBottom: 24 }}>
        + Add another item
      </button>

      <div className="form-row">
        <div className="field" style={{ maxWidth: 180 }}>
          <label htmlFor="paidAmount">Amount paid now</label>
          <input
            id="paidAmount"
            type="number"
            min="0"
            step="0.01"
            value={paidAmount}
            onChange={(e) => setPaidAmount(e.target.value)}
          />
        </div>
        <p style={{ fontSize: 22, fontWeight: 700, marginLeft: "auto" }}>Total: {total.toFixed(2)}</p>
      </div>

      <button type="submit" className="btn-primary" disabled={loading}>
        {loading && <span className="spinner" />}
        {loading ? "Recording…" : "Record sale"}
      </button>
    </form>
  );
}
