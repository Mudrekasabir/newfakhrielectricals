"use client";

import { useEffect } from "react";

// Fields Enter/Shift+Enter should hop between. Buttons are included so a
// row's "Remove"/icon buttons sit in the same tab order, but file/submit/
// button inputs are excluded — Enter on those should do their normal thing
// (open the file picker, submit, click), not get hijacked into "next field".
const FOCUSABLE_SELECTOR =
  "input:not([type=hidden]):not([type=file]):not([type=submit]):not([type=button]):not([disabled]), " +
  "select:not([disabled]), " +
  "button:not([disabled])";

// Subset of the above that Up/Down "move a row" is safe to hijack on.
// <select> and number/date/etc. inputs already give Up/Down a native,
// expected meaning (cycle options, bump the value) — taking that over
// would be a regression, not a convenience. Plain text-like inputs have no
// native use for Up/Down, so those are fair game.
const ARROW_ROW_NAV_SELECTOR =
  'input[type="text"]:not([disabled]), input[type="tel"]:not([disabled]), input[type="email"]:not([disabled]), ' +
  'input[type="search"]:not([disabled]), input[type="url"]:not([disabled]), input:not([type]):not([disabled])';

function isEditableTextInput(el: HTMLElement): boolean {
  if (el.tagName === "SELECT") return true;
  if (el.tagName !== "INPUT") return false;
  const type = (el as HTMLInputElement).type;
  return !["checkbox", "radio", "file", "submit", "button", "reset"].includes(type);
}

function visibleFocusables(scope: HTMLElement, selector: string): HTMLElement[] {
  return Array.from(scope.querySelectorAll<HTMLElement>(selector)).filter(
    (el) => el.offsetParent !== null && !el.hasAttribute("data-kbd-nav-skip")
  );
}

/**
 * Makes every plain data-entry form in the app behave like a spreadsheet:
 *
 * - Enter moves to the next field, Shift+Enter moves back — so staff can
 *   fill in a customer, add sale items, enter product rows, etc. entirely
 *   from the keyboard instead of reaching for the mouse to click into each
 *   box.
 * - Inside a repeating item list ([data-kbd-nav-scope], e.g. the sale/
 *   invoice item rows), ArrowDown/ArrowUp jump straight to the same field
 *   one row down/up — like moving between cells in a spreadsheet column —
 *   and ArrowDown on the very last row adds a new row and lands in it,
 *   exactly like pressing Enter there does.
 *
 * Mounted once in the root layout; needs no per-form wiring.
 *
 * Deliberately leaves <textarea> alone (Enter should insert a newline
 * there, as in the message composer) and only ever moves within the
 * nearest <form> — or, for fields outside any form (item rows sometimes
 * live in a plain <div>), the nearest [data-kbd-nav-scope] container, or
 * the whole document as a last resort.
 */
export default function KeyboardFormNav() {
  useEffect(() => {
    function handleEnter(e: KeyboardEvent, target: HTMLElement) {
      if (target.tagName === "TEXTAREA") return; // let newlines through
      if (!isEditableTextInput(target) && target.tagName !== "BUTTON") return;
      // A <button type="submit"> as the very last stop should still submit
      // on Enter rather than getting swallowed.
      if (target.tagName === "BUTTON" && (target as HTMLButtonElement).type === "submit") return;

      const scope =
        target.closest<HTMLElement>("[data-kbd-nav-scope]") || target.closest("form") || document.body;

      const focusables = visibleFocusables(scope, FOCUSABLE_SELECTOR);
      const currentIndex = focusables.indexOf(target);
      if (currentIndex === -1) return;

      const nextIndex = e.shiftKey ? currentIndex - 1 : currentIndex + 1;
      const next = focusables[nextIndex];

      if (next) {
        e.preventDefault();
        next.focus();
        if (next instanceof HTMLInputElement && isEditableTextInput(next)) {
          next.select();
        }
        return;
      }

      // No more fields ahead in this scope. If the scope opted in, ask the
      // component to add another row (see NewSaleForm / item-row lists)
      // instead of doing nothing.
      if (!e.shiftKey && scope.hasAttribute("data-kbd-nav-scope")) {
        e.preventDefault();
        scope.dispatchEvent(new CustomEvent("kbdnav:add-row", { bubbles: false }));
      }
      // Otherwise (plain form, last field) let Enter do its normal thing —
      // typically submitting the form, which is the expected behaviour.
    }

    function handleArrowVertical(e: KeyboardEvent, target: HTMLElement, direction: 1 | -1) {
      // Only meaningful inside a repeating row list — elsewhere, leave
      // Up/Down alone entirely (native scrolling, native <select> cycling,
      // native number-input stepping, etc).
      const scope = target.closest<HTMLElement>("[data-kbd-nav-scope]");
      if (!scope) return;
      if (!target.matches(ARROW_ROW_NAV_SELECTOR)) return;

      const rows = Array.from(scope.children).filter((c): c is HTMLElement => c instanceof HTMLElement);
      const rowIndex = rows.findIndex((row) => row.contains(target));
      if (rowIndex === -1) return;

      const targetRow = rows[rowIndex + direction];
      if (!targetRow) {
        // Past the last row, going down: same convenience as Enter — add a
        // new row and land in it. Going up past the first row: nothing to
        // do, leave the caret where it is.
        if (direction === 1) {
          e.preventDefault();
          scope.dispatchEvent(new CustomEvent("kbdnav:add-row", { bubbles: false }));
        }
        return;
      }

      const colInCurrentRow = visibleFocusables(rows[rowIndex], FOCUSABLE_SELECTOR);
      const colIndex = colInCurrentRow.indexOf(target);
      if (colIndex === -1) return;

      const colInTargetRow = visibleFocusables(targetRow, FOCUSABLE_SELECTOR);
      const dest = colInTargetRow[colIndex] || colInTargetRow[colInTargetRow.length - 1];
      if (!dest) return;

      e.preventDefault();
      dest.focus();
      if (dest instanceof HTMLInputElement) dest.select();
    }

    function onKeyDown(e: KeyboardEvent) {
      if (e.key !== "Enter" && e.key !== "ArrowDown" && e.key !== "ArrowUp") return;

      const target = e.target as HTMLElement | null;
      if (!target) return;
      // The command palette (Ctrl/Cmd+K) has its own Enter/arrow-key
      // handling for picking a result — leave it alone entirely.
      if (target.closest(".cmdk-panel")) return;

      if (e.key === "Enter") {
        handleEnter(e, target);
      } else {
        handleArrowVertical(e, target, e.key === "ArrowDown" ? 1 : -1);
      }
    }

    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  return null;
}
