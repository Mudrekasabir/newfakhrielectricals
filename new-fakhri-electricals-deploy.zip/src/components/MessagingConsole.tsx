"use client";

import { useEffect, useRef, useState } from "react";
import { smsBodySeparator } from "@/lib/messageLinks";
import { formatBalance } from "@/lib/balanceFormat";
import { renderPurchaseReceipt, renderReturnReceipt, lineItemsTotal, todayDateLabel, SHOP_NAME, type ReceiptItem } from "@/lib/receiptTemplates";

type CustomerRow = {
  id: string;
  name: string;
  phone: string;
  lastMessage: string | null;
  lastMessageAt: string | null;
};

type ProductOption = { id: string; name: string; unit: string; unitPrice: number };

type MessageEntry = {
  kind: "MESSAGE";
  id: string;
  createdAt: string;
  messageType: "PURCHASE" | "RETURN" | "CUSTOM";
  channel: "WHATSAPP" | "SMS";
  body: string;
};
type SaleEntry = {
  kind: "SALE";
  id: string;
  createdAt: string;
  items: { itemName: string; quantity: number; unitPrice: number }[];
  totalAmount: number;
  paidAmount: number;
  balanceAfter: number;
};
type ReturnEntry = {
  kind: "RETURN";
  id: string;
  createdAt: string;
  items: string;
  amount: number;
  balanceAfter: number;
};
type TimelineEntry = MessageEntry | SaleEntry | ReturnEntry;

type MessageType = "PURCHASE" | "RETURN" | "CUSTOM";

// quantity/unitPrice kept as strings while editing so an empty field doesn't
// render as a jarring "0" — parsed to numbers wherever they're actually used.
type ItemRow = { name: string; quantity: string; unitPrice: string };

function emptyItemRow(): ItemRow {
  return { name: "", quantity: "1", unitPrice: "" };
}

function toReceiptItems(rows: ItemRow[]): ReceiptItem[] {
  return rows
    .filter((r) => r.name.trim() && Number(r.quantity) > 0)
    .map((r) => ({ name: r.name.trim(), quantity: Number(r.quantity), unitPrice: Number(r.unitPrice || 0) }));
}

function channelTagClass(channel: string) {
  return channel === "WHATSAPP" ? "tag tag-paid" : "tag tag-partial";
}

// Shared look for the small text-link-style action buttons tucked into a
// chat bubble's meta line (Print / WhatsApp / SMS / Delete).
const metaLinkStyle: React.CSSProperties = {
  marginLeft: 8,
  background: "none",
  border: "none",
  color: "inherit",
  cursor: "pointer",
  padding: 0,
  fontSize: 15,
  textDecoration: "underline",
};

// Minimal HTML-escaping for text interpolated into the print window's
// markup (item names, customer name/phone) — these come from staff-entered
// data, not user-supplied HTML, but escaping keeps stray "<" or "&" from
// breaking the printed layout.
function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export default function MessagingConsole() {
  const [customers, setCustomers] = useState<CustomerRow[]>([]);
  const [products, setProducts] = useState<ProductOption[]>([]);
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [history, setHistory] = useState<TimelineEntry[]>([]);
  const [balance, setBalance] = useState<number | null>(null);
  const [ledgerCounts, setLedgerCounts] = useState<{ saleCount: number; returnCount: number } | null>(null);
  const [threadLoading, setThreadLoading] = useState(false);

  const [messageType, setMessageType] = useState<MessageType>("PURCHASE");
  const [itemRows, setItemRows] = useState<ItemRow[]>([emptyItemRow()]);
  const [paidAmount, setPaidAmount] = useState("");
  const [customBody, setCustomBody] = useState("");

  // The auto-generated PURCHASE/RETURN receipt text can be hand-edited
  // before sending (an "editable invoice") — null means "no manual edits
  // yet, keep following the auto-generated template as items/amounts
  // change"; once the staff types into the preview, it switches to holding
  // their exact text so further template recalculation doesn't clobber it.
  const [editedBody, setEditedBody] = useState<string | null>(null);

  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [deletingMessageId, setDeletingMessageId] = useState<string | null>(null);
  const [resendingId, setResendingId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  async function loadCustomers() {
    const res = await fetch("/api/messages/customers");
    if (res.ok) setCustomers(await res.json());
  }

  async function loadProducts() {
    const res = await fetch("/api/products");
    if (res.ok) setProducts(await res.json());
  }

  async function loadHistory(id: string) {
    const res = await fetch(`/api/messages?customerId=${id}`);
    if (res.ok) setHistory(await res.json());
  }

  async function loadBalance(id: string) {
    const res = await fetch(`/api/customers/${id}/balance`);
    if (res.ok) {
      const data = await res.json();
      setBalance(data.balance);
      setLedgerCounts({ saleCount: data.saleCount, returnCount: data.returnCount });
    }
  }

  useEffect(() => {
    loadCustomers();
    loadProducts();
  }, []);

  useEffect(() => {
    if (selectedId) {
      setThreadLoading(true);
      setHistory([]);
      setBalance(null);
      setLedgerCounts(null);
      Promise.all([loadHistory(selectedId), loadBalance(selectedId)]).finally(() => setThreadLoading(false));
    }
  }, [selectedId]);

  // Keep the newest message in view whenever the thread changes — without
  // this the box just sits scrolled wherever it was, which looks "stuck".
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ block: "end" });
  }, [history]);

  const selected = customers.find((c) => c.id === selectedId);

  const filtered = customers.filter(
    (c) => c.name.toLowerCase().includes(search.toLowerCase()) || c.phone.includes(search)
  );

  function updateItemRow(index: number, patch: Partial<ItemRow>) {
    setItemRows((prev) => prev.map((r, i) => (i === index ? { ...r, ...patch } : r)));
  }

  // Called as the item-name field changes. When what's typed matches a
  // catalog product exactly (case-insensitive) — which is what happens the
  // instant staff pick a suggestion from the datalist dropdown — the price
  // (and unit, for the hint under the field) auto-fills from the catalog so
  // nobody has to remember or retype it. Anything that doesn't match a
  // product stays a free-text custom item, price typed in by hand as before.
  function handleItemNameChange(index: number, value: string) {
    const match = products.find((p) => p.name.toLowerCase() === value.trim().toLowerCase());
    if (match) {
      updateItemRow(index, { name: value, unitPrice: String(match.unitPrice) });
    } else {
      updateItemRow(index, { name: value });
    }
  }

  function addItemRow() {
    setItemRows((prev) => [...prev, emptyItemRow()]);
  }

  function removeItemRow(index: number) {
    setItemRows((prev) => (prev.length > 1 ? prev.filter((_, i) => i !== index) : prev));
  }

  function resetForm() {
    setItemRows([emptyItemRow()]);
    setPaidAmount("");
    setCustomBody("");
    setEditedBody(null);
  }

  const receiptItems = toReceiptItems(itemRows);
  const computedTotal = lineItemsTotal(receiptItems);

  async function useLatestSale() {
    if (!selectedId) return;
    const res = await fetch(`/api/customers/${selectedId}/latest-sale`);
    if (!res.ok) {
      setError("This customer has no recorded sales yet");
      return;
    }
    const data = await res.json();
    if (Array.isArray(data.itemRows) && data.itemRows.length > 0) {
      setItemRows(
        data.itemRows.map((r: { name: string; quantity: number; unitPrice: number }) => ({
          name: r.name,
          quantity: String(r.quantity),
          unitPrice: String(r.unitPrice),
        }))
      );
    }
    setPaidAmount(String(data.paidAmount));
    setError(null);
  }

  // The auto-generated text for the current type/items/amount — this is
  // what the preview follows until the staff manually edits it (see
  // `editedBody`), and it's always what the ledger amounts (Sale/Return
  // rows) are computed from, regardless of any text edits.
  function buildTemplate(): string {
    if (!selected) return "";
    if (messageType === "PURCHASE") {
      if (receiptItems.length === 0) return "Add at least one item with a price to see a preview…";
      return renderPurchaseReceipt({
        customerName: selected.name,
        customerPhone: selected.phone,
        items: receiptItems,
        paidAmount: Number(paidAmount || 0),
        date: todayDateLabel(),
      });
    }
    if (messageType === "RETURN") {
      if (receiptItems.length === 0) return "Add at least one returned item with a price to see a preview…";
      const newBalance = (balance ?? 0) - computedTotal;
      return renderReturnReceipt({
        customerName: selected.name,
        customerPhone: selected.phone,
        items: receiptItems,
        date: todayDateLabel(),
        updatedBalance: newBalance,
      });
    }
    return customBody || "Type a message to see a preview…";
  }

  const template = buildTemplate();
  // What's actually shown/sent: the staff's manual edit if there is one,
  // otherwise the live template. CUSTOM has its own single-line composer
  // already, so it isn't affected by manual preview edits.
  const previewBody = messageType !== "CUSTOM" && editedBody !== null ? editedBody : template;
  const isPreviewEdited = messageType !== "CUSTOM" && editedBody !== null;

  // Logs the message server-side (canonical text, audit trail) and gets back
  // a wa.me / sms: link, then opens it — staff still taps Send inside
  // WhatsApp/Messages itself. Nothing is sent from our server.
  //
  // The window for WhatsApp is opened *synchronously*, right here, before
  // any `await` — opening it after the network request resolves is what
  // was silently failing: browsers only allow window.open() to succeed
  // without being blocked when it happens directly inside the click
  // handler's own turn, not after an awaited fetch. We open a blank tab
  // now and point it at the real link once we have it.
  async function handleSend(channel: "WHATSAPP" | "SMS") {
    if (!selectedId) return;
    setError(null);
    setNotice(null);
    setSending(true);

    const preOpenedTab = channel === "WHATSAPP" ? window.open("", "_blank") : null;

    // Shows the message in the thread immediately — loadHistory() below
    // replaces it with the server's version once the request resolves, so
    // this is purely a perceived-speed improvement, not a source of truth.
    const tempId = `temp-${Date.now()}`;
    setHistory((prev) => [
      ...prev,
      { kind: "MESSAGE", id: tempId, createdAt: new Date().toISOString(), messageType, channel, body: previewBody },
    ]);

    let res: Response;
    try {
      res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerId: selectedId,
          messageType,
          channel,
          items: receiptItems,
          paidAmount: Number(paidAmount || 0),
          customBody,
          editedBody: isPreviewEdited ? editedBody : undefined,
          smsSeparator: smsBodySeparator(),
        }),
      });
    } catch {
      setSending(false);
      setHistory((prev) => prev.filter((h) => h.id !== tempId));
      preOpenedTab?.close();
      setError("Could not reach the server — check your connection and try again.");
      return;
    }
    setSending(false);

    const data = await res.json().catch(() => ({}));
    if (res.ok) {
      if (channel === "WHATSAPP") {
        if (preOpenedTab) {
          preOpenedTab.location.href = data.link;
        } else {
          // Pop-up was blocked even for the pre-opened tab (rare, but
          // possible with strict blocker settings) — fall back to a
          // direct open, and if that's blocked too, the link is still
          // right there in the notice below to tap manually.
          window.open(data.link, "_blank");
        }
      } else {
        window.location.href = data.link;
      }
      setNotice(`Opened ${channel === "WHATSAPP" ? "WhatsApp" : "your SMS app"} with the message ready — tap Send there to finish.`);
      resetForm();
      loadHistory(selectedId);
      loadCustomers();
      loadBalance(selectedId);
    } else {
      preOpenedTab?.close();
      setHistory((prev) => prev.filter((h) => h.id !== tempId));
      setError(data.error || `Could not prepare the message (server returned ${res.status})`);
    }
  }

  async function handleDeleteMessage(id: string) {
    if (!window.confirm("Delete this message from the thread? This only removes our record of it — it can't unsend anything already opened in WhatsApp/SMS.")) {
      return;
    }
    setError(null);
    setDeletingMessageId(id);
    const prevHistory = history;
    setHistory((h) => h.filter((entry) => entry.id !== id));

    const res = await fetch(`/api/messages/${id}`, { method: "DELETE" });
    setDeletingMessageId(null);

    if (!res.ok) {
      setHistory(prevHistory);
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Could not delete this message — try again");
      return;
    }

    if (selectedId) loadCustomers();
  }

  // Opens a formatted, print-ready invoice in a new tab and triggers the
  // browser print dialog. This is entirely client-side (no server round
  // trip, nothing logged) — it just turns whatever is currently in the
  // preview into a proper printable page with a letterhead and an items
  // table, for when the customer wants a paper copy instead of/alongside
  // the WhatsApp or SMS message.
  function handlePrintInvoice() {
    if (!selected) return;

    const isReturn = messageType === "RETURN";
    const total = computedTotal;
    const paid = Number(paidAmount || 0);
    const due = isReturn ? 0 : total - paid;

    const rowsHtml = receiptItems
      .map(
        (item, i) => `
          <tr>
            <td>${i + 1}</td>
            <td>${escapeHtml(item.name)}</td>
            <td class="num">${item.quantity}</td>
            <td class="num">Rs.${item.unitPrice.toFixed(2)}</td>
            <td class="num">Rs.${(item.unitPrice * item.quantity).toFixed(2)}</td>
          </tr>`
      )
      .join("");

    const win = window.open("", "_blank");
    if (!win) {
      setError("Could not open the print window — check your pop-up blocker and try again.");
      return;
    }

    win.document.write(`<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>${isReturn ? "Return" : "Invoice"} — ${escapeHtml(selected.name)}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #1a1a1a; padding: 32px; max-width: 720px; margin: 0 auto; }
  h1 { font-size: 22px; margin: 0 0 2px; }
  .muted { color: #555; font-size: 13px; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1a1a1a; padding-bottom: 14px; margin-bottom: 18px; }
  .doc-type { font-size: 15px; font-weight: bold; text-align: right; }
  table { width: 100%; border-collapse: collapse; margin: 18px 0; }
  th, td { padding: 8px 6px; border-bottom: 1px solid #ddd; font-size: 13px; text-align: left; }
  th { font-size: 11px; text-transform: uppercase; color: #555; }
  td.num, th.num { text-align: right; }
  .totals { width: 260px; margin-left: auto; font-size: 14px; }
  .totals div { display: flex; justify-content: space-between; padding: 4px 0; }
  .totals .grand { font-weight: bold; border-top: 1px solid #1a1a1a; margin-top: 4px; padding-top: 8px; font-size: 16px; }
  .due { color: #b5342a; }
  .credit { color: #1f7a3d; }
  footer { margin-top: 40px; font-size: 12px; color: #777; text-align: center; }
  @media print { body { padding: 0; } }
</style>
</head>
<body>
  <div class="header">
    <div>
      <h1>${escapeHtml(SHOP_NAME)}</h1>
      <div class="muted">${escapeHtml(todayDateLabel())}</div>
    </div>
    <div>
      <div class="doc-type">${isReturn ? "RETURN" : "INVOICE"}</div>
      <div class="muted">Customer: ${escapeHtml(selected.name)}</div>
      <div class="muted">${escapeHtml(selected.phone)}</div>
    </div>
  </div>

  <table>
    <thead>
      <tr><th>#</th><th>Item</th><th class="num">Qty</th><th class="num">Price</th><th class="num">Amount</th></tr>
    </thead>
    <tbody>
      ${rowsHtml || `<tr><td colspan="5" class="muted">No items added</td></tr>`}
    </tbody>
  </table>

  <div class="totals">
    <div><span>${isReturn ? "Refund amount" : "Total"}</span><span>Rs.${total.toFixed(2)}</span></div>
    ${
      isReturn
        ? ""
        : `<div><span>Paid</span><span>Rs.${paid.toFixed(2)}</span></div>
           <div class="grand ${due > 0.004 ? "due" : due < -0.004 ? "credit" : ""}">
             <span>${due > 0.004 ? "Balance due" : due < -0.004 ? "Credit" : "Status"}</span>
             <span>${due > 0.004 ? `Rs.${due.toFixed(2)}` : due < -0.004 ? `Rs.${Math.abs(due).toFixed(2)}` : "Fully paid"}</span>
           </div>`
    }
  </div>

  <footer>Thank you for your business — ${escapeHtml(SHOP_NAME)}</footer>
</body>
</html>`);
    win.document.close();
    win.focus();
    // Give the new document a beat to finish laying out before print().
    setTimeout(() => win.print(), 300);
  }

  // Opens the real, server-rendered invoice PDF for an already-recorded sale
  // — the exact same PDF whose link gets sent via WhatsApp/SMS, so what
  // staff print here is always identical to what the customer receives.
  function handlePrintSaleInvoice(entry: SaleEntry) {
    window.open(`/api/invoices/${entry.id}/pdf`, "_blank");
  }

  // Same, for a recorded return.
  function handlePrintReturnPdf(entry: ReturnEntry) {
    window.open(`/api/returns/${entry.id}/pdf`, "_blank");
  }

  // wa.me/sms: links can only pre-fill *text* — neither protocol has any
  // way to attach a real file, so the "WhatsApp"/"SMS" buttons above can
  // only ever send a link to the PDF, never the PDF itself. The only way to
  // hand over the actual file without paying for a WhatsApp Business API
  // integration is the device's own share sheet: fetch the PDF, wrap it as
  // a File, and let the OS offer WhatsApp (or Messages, email, etc.) as a
  // target the way "Share" from any app does. This only works on phones
  // (iOS Safari / Android Chrome) — desktop browsers have no share sheet to
  // hand a file to, so there we just open the PDF for a manual save/attach.
  const [sharingId, setSharingId] = useState<string | null>(null);

  async function handleSharePdf(id: string, kind: "SALE" | "RETURN") {
    setError(null);
    setNotice(null);
    setSharingId(id);

    const url = kind === "SALE" ? `/api/invoices/${id}/pdf` : `/api/returns/${id}/pdf`;

    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error("Could not load the PDF");
      const blob = await res.blob();
      const filename = `${kind === "SALE" ? "invoice" : "return"}-${id}.pdf`;
      const file = new File([blob], filename, { type: "application/pdf" });

      const nav = navigator as Navigator & {
        canShare?: (data?: ShareData) => boolean;
        share?: (data?: ShareData) => Promise<void>;
      };

      if (nav.canShare && nav.share && nav.canShare({ files: [file] })) {
        await nav.share({
          files: [file],
          title: kind === "SALE" ? `Invoice — ${SHOP_NAME}` : `Return — ${SHOP_NAME}`,
        });
        setNotice("Pick WhatsApp (or any app) in the sheet that just opened — the actual PDF file goes with it.");
      } else {
        window.open(url, "_blank");
        setNotice(
          "This browser can't hand off files directly, so the PDF just opened instead — on a phone, use its own Share button from there to send the file via WhatsApp."
        );
      }
    } catch (err) {
      if (!(err instanceof DOMException && err.name === "AbortError")) {
        // AbortError just means staff closed the share sheet without picking
        // anything — not worth surfacing as an error.
        setError("Could not prepare the PDF to share — try again.");
      }
    } finally {
      setSharingId(null);
    }
  }

  // Prints every past sale and return for the customer currently open in
  // the thread as one combined, dated statement — for when someone wants
  // "all my bills" on paper at once instead of clicking Print on each
  // invoice bubble one at a time. Built entirely from the timeline
  // already loaded for this thread, so it's instant and needs no extra
  // server round trip.
  function handlePrintAllBills() {
    if (!selected) return;

    const saleEntries = history.filter((e): e is SaleEntry => e.kind === "SALE");
    const returnEntries = history.filter((e): e is ReturnEntry => e.kind === "RETURN");

    if (saleEntries.length === 0 && returnEntries.length === 0) {
      setError("No past bills to print for this customer yet.");
      return;
    }

    const totalBilled = saleEntries.reduce((sum, s) => sum + s.totalAmount, 0);
    const totalPaid = saleEntries.reduce((sum, s) => sum + s.paidAmount, 0);
    const totalReturned = returnEntries.reduce((sum, r) => sum + r.amount, 0);
    const netDue = totalBilled - totalPaid - totalReturned;

    const rowsHtml = [
      ...saleEntries.map((s) => ({ kind: "Sale" as const, date: new Date(s.createdAt), entry: s })),
      ...returnEntries.map((r) => ({ kind: "Return" as const, date: new Date(r.createdAt), entry: r })),
    ]
      .sort((a, b) => a.date.getTime() - b.date.getTime())
      .map(({ kind, date, entry }) => {
        const dateLabel = date.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
        if (kind === "Sale") {
          const sale = entry as SaleEntry;
          const due = sale.totalAmount - sale.paidAmount;
          const itemsLabel = sale.items.map((i) => `${escapeHtml(i.itemName)} x${i.quantity}`).join(", ");
          return `
            <tr>
              <td>${dateLabel}</td>
              <td><span class="pill pill-bill">Bill</span></td>
              <td>${itemsLabel}</td>
              <td class="num">Rs.${sale.totalAmount.toFixed(2)}</td>
              <td class="num">Rs.${sale.paidAmount.toFixed(2)}</td>
              <td class="num ${due > 0.004 ? "due" : ""}">Rs.${due.toFixed(2)}</td>
            </tr>`;
        }
        const ret = entry as ReturnEntry;
        return `
          <tr>
            <td>${dateLabel}</td>
            <td><span class="pill pill-return">Return</span></td>
            <td>${escapeHtml(ret.items)}</td>
            <td class="num">—</td>
            <td class="num">—</td>
            <td class="num credit">-Rs.${ret.amount.toFixed(2)}</td>
          </tr>`;
      })
      .join("");

    const win = window.open("", "_blank");
    if (!win) {
      setError("Could not open the print window — check your pop-up blocker and try again.");
      return;
    }

    win.document.write(`<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Statement — ${escapeHtml(selected.name)}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #1a1a1a; padding: 32px; max-width: 860px; margin: 0 auto; }
  h1 { font-size: 22px; margin: 0 0 2px; }
  .muted { color: #555; font-size: 13px; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1a1a1a; padding-bottom: 14px; margin-bottom: 18px; }
  .doc-type { font-size: 15px; font-weight: bold; text-align: right; }
  table { width: 100%; border-collapse: collapse; margin: 18px 0; }
  th, td { padding: 8px 6px; border-bottom: 1px solid #ddd; font-size: 13px; text-align: left; }
  th { font-size: 11px; text-transform: uppercase; color: #555; }
  td.num, th.num { text-align: right; }
  td.due { color: #b5342a; }
  td.credit { color: #1f7a3d; }
  .pill { display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 11px; font-weight: bold; }
  .pill-bill { background: #fbe7de; color: #a2461c; }
  .pill-return { background: #dff3e6; color: #1f7a3d; }
  .totals { width: 280px; margin-left: auto; font-size: 14px; }
  .totals div { display: flex; justify-content: space-between; padding: 4px 0; }
  .totals .grand { font-weight: bold; border-top: 1px solid #1a1a1a; margin-top: 4px; padding-top: 8px; font-size: 16px; }
  .due { color: #b5342a; }
  .credit { color: #1f7a3d; }
  footer { margin-top: 40px; font-size: 12px; color: #777; text-align: center; }
  @media print { body { padding: 0; } tr { page-break-inside: avoid; } }
</style>
</head>
<body>
  <div class="header">
    <div>
      <h1>${escapeHtml(SHOP_NAME)}</h1>
      <div class="muted">${escapeHtml(todayDateLabel())}</div>
    </div>
    <div>
      <div class="doc-type">CUSTOMER STATEMENT</div>
      <div class="muted">${escapeHtml(selected.name)}</div>
      <div class="muted">${escapeHtml(selected.phone)}</div>
    </div>
  </div>

  <table>
    <thead>
      <tr><th>Date</th><th>Type</th><th>Details</th><th class="num">Billed</th><th class="num">Paid</th><th class="num">Due</th></tr>
    </thead>
    <tbody>
      ${rowsHtml}
    </tbody>
  </table>

  <div class="totals">
    <div><span>Total billed</span><span>Rs.${totalBilled.toFixed(2)}</span></div>
    <div><span>Total paid</span><span>Rs.${totalPaid.toFixed(2)}</span></div>
    <div><span>Total returned</span><span>Rs.${totalReturned.toFixed(2)}</span></div>
    <div class="grand ${netDue > 0.004 ? "due" : netDue < -0.004 ? "credit" : ""}">
      <span>${netDue > 0.004 ? "Balance due" : netDue < -0.004 ? "Credit" : "Status"}</span>
      <span>${netDue > 0.004 ? `Rs.${netDue.toFixed(2)}` : netDue < -0.004 ? `Rs.${Math.abs(netDue).toFixed(2)}` : "Fully settled"}</span>
    </div>
  </div>

  <footer>This statement covers every recorded sale and return for this customer — ${escapeHtml(SHOP_NAME)}</footer>
</body>
</html>`);
    win.document.close();
    win.focus();
    setTimeout(() => win.print(), 300);
  }

  async function handleResendSaleInvoice(entry: SaleEntry, channel: "WHATSAPP" | "SMS") {
    if (!selectedId) return;
    setError(null);
    setNotice(null);
    setResendingId(`${entry.id}-${channel}`);

    const preOpenedTab = channel === "WHATSAPP" ? window.open("", "_blank") : null;

    let res: Response;
    try {
      res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerId: selectedId,
          messageType: "PURCHASE",
          channel,
          saleId: entry.id,
          smsSeparator: smsBodySeparator(),
        }),
      });
    } catch {
      setResendingId(null);
      preOpenedTab?.close();
      setError("Could not reach the server — check your connection and try again.");
      return;
    }
    setResendingId(null);

    const data = await res.json().catch(() => ({}));
    if (res.ok) {
      if (channel === "WHATSAPP") {
        if (preOpenedTab) {
          preOpenedTab.location.href = data.link;
        } else {
          window.open(data.link, "_blank");
        }
      } else {
        window.location.href = data.link;
      }
      setNotice(`Opened ${channel === "WHATSAPP" ? "WhatsApp" : "your SMS app"} with this invoice ready — tap Send there to finish.`);
      loadHistory(selectedId);
    } else {
      preOpenedTab?.close();
      setError(data.error || `Could not prepare the invoice (server returned ${res.status})`);
    }
  }

  // Ref on the item-rows container — see NewSaleForm.tsx / KeyboardFormNav
  // for the full explanation. When Enter or ArrowDown is pressed in the
  // last field of the last row, KeyboardFormNav fires "kbdnav:add-row" on
  // this container instead of doing nothing, so staff can keep entering
  // items with the keyboard alone.
  const itemRowsRef = useRef<HTMLDivElement>(null);
  // Set right before adding a row from the keyboard shortcut, then consumed
  // by the effect below once the new row has actually committed to the DOM
  // — more reliable than a blind setTimeout, which could race the render.
  const focusNewItemRowRef = useRef(false);

  function handleAddItemRowShortcut() {
    focusNewItemRowRef.current = true;
    addItemRow();
  }

  useEffect(() => {
    if (!focusNewItemRowRef.current) return;
    focusNewItemRowRef.current = false;
    const inputs = itemRowsRef.current?.querySelectorAll<HTMLInputElement>("input");
    // The newly added row's first (name) field is the first input of the
    // last row — with 3 inputs per row, that's 3 back from the very end.
    const target = inputs && inputs[inputs.length - 3];
    target?.focus();
  }, [itemRows.length]);

  useEffect(() => {
    const el = itemRowsRef.current;
    if (!el) return;
    el.addEventListener("kbdnav:add-row", handleAddItemRowShortcut);
    return () => el.removeEventListener("kbdnav:add-row", handleAddItemRowShortcut);
  });

  function renderItemRows() {
    return (
      <>
        <div className="form-row" style={{ marginBottom: 4 }}>
          <span className="muted" style={{ flex: 2, minWidth: 180, fontSize: 16 }}>
            Item
          </span>
          <span className="muted" style={{ flex: 1, minWidth: 70, fontSize: 16 }}>
            Qty
          </span>
          <span className="muted" style={{ flex: 1, minWidth: 90, fontSize: 16 }}>
            Price each
          </span>
          <span className="muted" style={{ minWidth: 90, fontSize: 16 }}>
            Line total
          </span>
        </div>
        <div ref={itemRowsRef} data-kbd-nav-scope>
          {itemRows.map((row, index) => {
          const lineTotal = Number(row.quantity || 0) * Number(row.unitPrice || 0);
          const matchedProduct = products.find((p) => p.name.toLowerCase() === row.name.trim().toLowerCase());
          return (
            <div className="form-row" key={index} style={{ marginBottom: 8, alignItems: "center" }}>
              <div className="field" style={{ flex: 2, minWidth: 180, marginBottom: 0 }}>
                <input
                  placeholder="e.g. Copper Wire 1.5mm"
                  value={row.name}
                  list="messaging-product-options"
                  onChange={(e) => handleItemNameChange(index, e.target.value)}
                />
                {matchedProduct && (
                  <p className="muted" style={{ margin: "4px 0 0", fontSize: 15 }}>
                    From catalog · {matchedProduct.unit} · Rs.{matchedProduct.unitPrice.toFixed(2)} each
                  </p>
                )}
              </div>
              <div className="field" style={{ flex: 1, minWidth: 70, marginBottom: 0 }}>
                <input
                  type="number"
                  min="1"
                  value={row.quantity}
                  onChange={(e) => updateItemRow(index, { quantity: e.target.value })}
                />
              </div>
              <div className="field" style={{ flex: 1, minWidth: 90, marginBottom: 0 }}>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  value={row.unitPrice}
                  onChange={(e) => updateItemRow(index, { unitPrice: e.target.value })}
                />
              </div>
              <span className="muted" style={{ minWidth: 90 }}>
                Rs.{lineTotal.toFixed(2)}
              </span>
              {itemRows.length > 1 && (
                <button type="button" className="btn-secondary" onClick={() => removeItemRow(index)} data-kbd-nav-skip>
                  Remove
                </button>
              )}
            </div>
          );
          })}
        </div>
        <datalist id="messaging-product-options">
          {products.map((p) => (
            <option key={p.id} value={p.name} />
          ))}
        </datalist>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <button type="button" className="btn-secondary" onClick={addItemRow}>
            + Add item
          </button>
          <strong>Total: Rs.{computedTotal.toFixed(2)}</strong>
        </div>
      </>
    );
  }

  return (
    <div className={`chat-layout${selectedId ? " has-selection" : ""}`}>
      <div className="chat-list">
        <div style={{ padding: 10, borderBottom: "1px solid var(--panel-border)" }}>
          <input
            data-shortcut="search"
            placeholder="Search customers… (press / to jump here)"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              width: "100%",
              background: "var(--bg)",
              border: "1px solid var(--panel-border)",
              borderRadius: "var(--radius)",
              padding: "8px 10px",
              color: "var(--text)",
              fontSize: 17,
            }}
          />
        </div>
        {filtered.length === 0 ? (
          <p className="muted chat-list-empty">
            {customers.length === 0 ? "No customers yet — add one from Manage records." : "No matches."}
          </p>
        ) : (
          filtered.map((c) => (
            <button
              key={c.id}
              className={`chat-list-item${c.id === selectedId ? " active" : ""}`}
              onClick={() => setSelectedId(c.id)}
            >
              <div className="chat-list-item-name">
                <span>{c.name}</span>
              </div>
              <div className="chat-list-item-preview">{c.lastMessage || c.phone}</div>
            </button>
          ))
        )}
      </div>

      <div className="chat-thread">
        {!selectedId ? (
          <div className="chat-thread-empty">
            <p className="muted">Select a customer to message them</p>
          </div>
        ) : (
          <>
            <div className="chat-thread-header">
              <div className="chat-thread-header-info">
                <button
                  type="button"
                  className="chat-back-btn"
                  onClick={() => setSelectedId(null)}
                  aria-label="Back to customer list"
                  title="Back to customer list"
                >
                  ←
                </button>
                <div>
                  <strong>{selected?.name}</strong> <span className="muted">{selected?.phone}</span>
                </div>
              </div>
              {balance !== null && (
                <span style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                  <span className={balance > 0.004 ? "tag tag-due" : balance < -0.004 ? "tag tag-partial" : "tag tag-paid"}>
                    {formatBalance(balance)}
                  </span>
                  {ledgerCounts && (
                    <span className="muted" style={{ fontSize: 15 }}>
                      {ledgerCounts.saleCount} sale{ledgerCounts.saleCount === 1 ? "" : "s"} · {ledgerCounts.returnCount} return
                      {ledgerCounts.returnCount === 1 ? "" : "s"}
                    </span>
                  )}
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={handlePrintAllBills}
                    disabled={!ledgerCounts || (ledgerCounts.saleCount === 0 && ledgerCounts.returnCount === 0)}
                    title="Print every past bill and return for this customer as one statement"
                    style={{ padding: "6px 12px", fontSize: 14 }}
                  >
                    🖨 Print all bills
                  </button>
                </span>
              )}
            </div>

            <div className="chat-thread-messages">
              {threadLoading ? (
                <>
                  <div className="skeleton-line" style={{ width: "70%" }} />
                  <div className="skeleton-line" style={{ width: "45%", alignSelf: "flex-end" }} />
                  <div className="skeleton-line" style={{ width: "60%" }} />
                </>
              ) : history.length === 0 ? (
                <p className="muted">No activity with this customer yet.</p>
              ) : (
                history.map((entry) => {
                  if (entry.kind === "MESSAGE") {
                    const isTemp = entry.id.startsWith("temp-");
                    return (
                      <div key={entry.id} className="chat-bubble chat-bubble-staff" style={{ whiteSpace: "pre-wrap", position: "relative" }}>
                        {entry.body}
                        <span className="chat-bubble-meta">
                          <span className={channelTagClass(entry.channel)} style={{ marginRight: 6 }}>
                            {entry.channel}
                          </span>
                          {new Date(entry.createdAt).toLocaleString("en-IN", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" })}
                          {!isTemp && (
                            <button
                              type="button"
                              onClick={() => handleDeleteMessage(entry.id)}
                              disabled={deletingMessageId === entry.id}
                              title="Delete this message"
                              style={{ ...metaLinkStyle, color: "var(--danger)" }}
                            >
                              {deletingMessageId === entry.id ? "Deleting…" : "Delete"}
                            </button>
                          )}
                        </span>
                      </div>
                    );
                  }
                  if (entry.kind === "SALE") {
                    const due = entry.totalAmount - entry.paidAmount;
                    return (
                      <div key={entry.id} className="chat-bubble chat-bubble-system">
                        <strong>Sale recorded</strong>
                        <div>{entry.items.map((i) => `${i.itemName} x${i.quantity}`).join(", ")}</div>
                        <div>
                          Total: Rs.{entry.totalAmount.toFixed(2)} · Paid: Rs.{entry.paidAmount.toFixed(2)}
                          {due > 0.004 ? ` · Due: Rs.${due.toFixed(2)}` : ""}
                        </div>
                        <div>Balance after: {formatBalance(entry.balanceAfter)}</div>
                        <span className="chat-bubble-meta">
                          {new Date(entry.createdAt).toLocaleString("en-IN", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" })}
                          <button
                            type="button"
                            onClick={() => handlePrintSaleInvoice(entry)}
                            title="Print this invoice"
                            style={metaLinkStyle}
                          >
                            Print
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSharePdf(entry.id, "SALE")}
                            disabled={sharingId === entry.id}
                            title="Share the actual PDF file (via your phone's share sheet)"
                            style={metaLinkStyle}
                          >
                            {sharingId === entry.id ? "Preparing…" : "Share PDF"}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleResendSaleInvoice(entry, "WHATSAPP")}
                            disabled={resendingId === `${entry.id}-WHATSAPP`}
                            title="Send a WhatsApp message with a link to this invoice"
                            style={metaLinkStyle}
                          >
                            {resendingId === `${entry.id}-WHATSAPP` ? "Preparing…" : "WhatsApp link"}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleResendSaleInvoice(entry, "SMS")}
                            disabled={resendingId === `${entry.id}-SMS`}
                            title="Send an SMS with a link to this invoice"
                            style={metaLinkStyle}
                          >
                            {resendingId === `${entry.id}-SMS` ? "Preparing…" : "SMS link"}
                          </button>
                        </span>
                      </div>
                    );
                  }
                  return (
                    <div key={entry.id} className="chat-bubble chat-bubble-system">
                      <strong>Return recorded</strong>
                      <div>{entry.items}</div>
                      <div>Refund: Rs.{entry.amount.toFixed(2)}</div>
                      <div>Balance after: {formatBalance(entry.balanceAfter)}</div>
                      <span className="chat-bubble-meta">
                        {new Date(entry.createdAt).toLocaleString("en-IN", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" })}
                        <button
                          type="button"
                          onClick={() => handlePrintReturnPdf(entry)}
                          title="Open this return's PDF"
                          style={metaLinkStyle}
                        >
                          PDF
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSharePdf(entry.id, "RETURN")}
                          disabled={sharingId === entry.id}
                          title="Share the actual PDF file (via your phone's share sheet)"
                          style={metaLinkStyle}
                        >
                          {sharingId === entry.id ? "Preparing…" : "Share PDF"}
                        </button>
                      </span>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="chat-thread-composer">
              <div style={{ padding: 16 }} data-kbd-nav-scope>
              {error && <p className="error-text">{error}</p>}
              {notice && <p className="muted" style={{ color: "var(--copper-bright)" }}>{notice}</p>}

              <div className="section-nav" style={{ marginBottom: 14 }}>
                {(["PURCHASE", "RETURN", "CUSTOM"] as MessageType[]).map((t) => (
                  <a
                    key={t}
                    onClick={() => {
                      setMessageType(t);
                      setEditedBody(null);
                    }}
                    style={{
                      cursor: "pointer",
                      borderColor: messageType === t ? "var(--copper)" : undefined,
                      color: messageType === t ? "var(--text)" : undefined,
                    }}
                  >
                    {t === "PURCHASE" ? "Purchase receipt" : t === "RETURN" ? "Return" : "Custom (SMS only)"}
                  </a>
                ))}
              </div>

              {messageType === "PURCHASE" && (
                <>
                  <button type="button" className="btn-secondary" onClick={useLatestSale} style={{ marginBottom: 12 }}>
                    Use latest sale
                  </button>
                  <p className="muted" style={{ margin: "0 0 6px", fontSize: 16 }}>
                    Items purchased — start typing to autoselect from your product catalog. Press Enter or ↓ in the
                    last field to add another row.
                  </p>
                  {renderItemRows()}
                  <div className="field" style={{ maxWidth: 200 }}>
                    <label>Amount paid</label>
                    <input type="number" step="0.01" value={paidAmount} onChange={(e) => setPaidAmount(e.target.value)} />
                  </div>
                </>
              )}

              {messageType === "RETURN" && (
                <>
                  <p className="muted" style={{ margin: "0 0 6px", fontSize: 16 }}>
                    Items returned — press Enter or ↓ in the last field to add another row.
                  </p>
                  {renderItemRows()}
                  <p className="muted" style={{ fontSize: 16 }}>
                    Refund amount is the total above — calculated from each item's price.
                  </p>
                </>
              )}

              {messageType === "CUSTOM" && (
                <div className="field">
                  <label>Message</label>
                  <input value={customBody} onChange={(e) => setCustomBody(e.target.value)} placeholder="Type a message…" />
                  <p className="muted" style={{ marginTop: 4 }}>
                    Sent as SMS only — WhatsApp doesn't allow free-form business-initiated messages.
                  </p>
                </div>
              )}

              <div className="panel" style={{ background: "var(--bg)", padding: 14, margin: "14px 0" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                  <p className="muted" style={{ margin: 0 }}>
                    {messageType === "CUSTOM" ? "Preview" : "Invoice preview — editable before sending"}
                  </p>
                  {isPreviewEdited && (
                    <button
                      type="button"
                      className="btn-secondary"
                      style={{ padding: "2px 8px", fontSize: 15 }}
                      onClick={() => setEditedBody(null)}
                    >
                      Reset to template
                    </button>
                  )}
                </div>
                {messageType === "CUSTOM" ? (
                  <p style={{ margin: 0, fontSize: 18, whiteSpace: "pre-wrap" }}>{previewBody}</p>
                ) : (
                  <textarea
                    value={previewBody}
                    onChange={(e) => setEditedBody(e.target.value)}
                    rows={Math.max(4, previewBody.split("\n").length)}
                    style={{
                      width: "100%",
                      background: "transparent",
                      border: "1px solid var(--panel-border)",
                      borderRadius: "var(--radius)",
                      color: "var(--text)",
                      fontSize: 18,
                      fontFamily: "inherit",
                      padding: 10,
                      resize: "vertical",
                    }}
                  />
                )}
              </div>
              {messageType !== "CUSTOM" && (
                <p className="muted" style={{ margin: "0 0 10px", fontSize: 16 }}>
                  A PDF {messageType === "RETURN" ? "credit note" : "invoice"} link is added automatically when you
                  send — the customer gets this text plus a link to the real, downloadable PDF.
                </p>
              )}

              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                {messageType !== "CUSTOM" && (
                  <button
                    type="button"
                    className="btn-primary"
                    disabled={sending}
                    onClick={() => handleSend("WHATSAPP")}
                  >
                    {sending && <span className="spinner" />}
                    {sending ? "Preparing…" : "Send via WhatsApp"}
                  </button>
                )}
                <button
                  type="button"
                  className={messageType === "CUSTOM" ? "btn-primary" : "btn-secondary"}
                  disabled={sending}
                  onClick={() => handleSend("SMS")}
                >
                  {sending && <span className="spinner" />}
                  {sending ? "Preparing…" : "Send via SMS"}
                </button>
                {messageType !== "CUSTOM" && (
                  <button
                    type="button"
                    className="btn-secondary"
                    disabled={receiptItems.length === 0}
                    onClick={handlePrintInvoice}
                  >
                    Print {messageType === "RETURN" ? "return" : "invoice"}
                  </button>
                )}
              </div>
              <p className="muted" style={{ marginTop: 10, fontSize: 16 }}>
                This opens {messageType === "CUSTOM" ? "your SMS app" : "WhatsApp or your SMS app"} with the message
                already filled in — you just tap Send there. Free, no account needed.
              </p>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
