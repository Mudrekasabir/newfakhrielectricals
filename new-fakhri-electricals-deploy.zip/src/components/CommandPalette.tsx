"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

type Command = {
  label: string;
  description: string;
  href: string;
  group: "Sales" | "Suppliers" | "General";
  roles: Array<"ADMIN" | "SALES" | "SUPPLIER_STAFF">;
  keywords?: string;
};

const COMMANDS: Command[] = [
  { label: "Dashboard", description: "Go home", href: "/dashboard", group: "General", roles: ["ADMIN", "SALES", "SUPPLIER_STAFF"] },
  { label: "Sales", description: "Sales home", href: "/sales", group: "Sales", roles: ["ADMIN", "SALES"] },
  { label: "New sale", description: "Record a sale and message the customer", href: "/sales/new", group: "Sales", roles: ["ADMIN", "SALES"], keywords: "invoice bill" },
  { label: "Customers", description: "Customer list, chat, balances", href: "/sales/customers", group: "Sales", roles: ["ADMIN", "SALES"], keywords: "message whatsapp sms chat" },
  { label: "Sales history", description: "Every past sale", href: "/sales/history", group: "Sales", roles: ["ADMIN", "SALES"], keywords: "invoices past" },
  { label: "Products", description: "Catalog and prices", href: "/sales/products", group: "Sales", roles: ["ADMIN", "SALES"] },
  { label: "Suppliers", description: "Supplier list and balances", href: "/suppliers", group: "Suppliers", roles: ["ADMIN", "SUPPLIER_STAFF"] },
  { label: "Supplier bills", description: "Uploaded bills, all suppliers", href: "/suppliers/bills", group: "Suppliers", roles: ["ADMIN", "SUPPLIER_STAFF"], keywords: "invoice" },
  { label: "Supplier payments", description: "Record and send payment receipts", href: "/suppliers/payments", group: "Suppliers", roles: ["ADMIN", "SUPPLIER_STAFF"], keywords: "pay" },
  { label: "Supplier history", description: "Every bill and payment, all suppliers", href: "/suppliers/history", group: "Suppliers", roles: ["ADMIN", "SUPPLIER_STAFF"], keywords: "ledger" },
];

function isTypingTarget(el: EventTarget | null): boolean {
  if (!(el instanceof HTMLElement)) return false;
  const tag = el.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable;
}

export default function CommandPalette() {
  const router = useRouter();
  const { data: session } = useSession();
  const role = session?.user?.role as Command["roles"][number] | undefined;

  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const available = useMemo(() => (role ? COMMANDS.filter((c) => c.roles.includes(role)) : COMMANDS), [role]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return available;
    return available.filter((c) => `${c.label} ${c.description} ${c.keywords || ""}`.toLowerCase().includes(q));
  }, [available, query]);

  // Global shortcuts: Ctrl/Cmd+K opens the palette from anywhere; "/" jumps
  // straight into the nearest on-page search box instead (skipped while the
  // palette itself is open, or while already typing somewhere).
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      const isCmdK = (e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k";
      if (isCmdK) {
        e.preventDefault();
        setOpen((prev) => !prev);
        return;
      }

      if (open) {
        if (e.key === "Escape") {
          e.preventDefault();
          setOpen(false);
        } else if (e.key === "ArrowDown") {
          e.preventDefault();
          setActiveIndex((i) => Math.min(i + 1, results.length - 1));
        } else if (e.key === "ArrowUp") {
          e.preventDefault();
          setActiveIndex((i) => Math.max(i - 1, 0));
        } else if (e.key === "Enter") {
          e.preventDefault();
          const pick = results[activeIndex];
          if (pick) {
            router.push(pick.href);
            setOpen(false);
          }
        }
        return;
      }

      if (e.key === "/" && !isTypingTarget(e.target)) {
        const el = document.querySelector<HTMLElement>('[data-shortcut="search"]');
        if (el) {
          e.preventDefault();
          el.focus();
        }
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [open, results, activeIndex, router]);

  useEffect(() => {
    if (open) {
      setQuery("");
      setActiveIndex(0);
      // Autofocus needs a tick — the input isn't in the DOM yet on the
      // same render that flips `open`.
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [open]);

  useEffect(() => {
    setActiveIndex(0);
  }, [query]);

  if (!session) return null;

  const groups: Command["group"][] = ["General", "Sales", "Suppliers"];

  return (
    <>
      <button type="button" className="cmdk-hint-badge" onClick={() => setOpen(true)} aria-label="Open command palette">
        <span>Jump to…</span>
        <kbd>{typeof navigator !== "undefined" && navigator.platform?.includes("Mac") ? "⌘K" : "Ctrl K"}</kbd>
      </button>

      {open && (
        <div className="cmdk-backdrop" onClick={() => setOpen(false)}>
          <div className="cmdk-panel" onClick={(e) => e.stopPropagation()}>
            <div className="cmdk-input-row">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="7" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Jump to a page… (Sales, Suppliers, New sale…)"
              />
              <span className="cmdk-esc-hint">Esc</span>
            </div>
            <div className="cmdk-list">
              {results.length === 0 && <p className="cmdk-empty">Nothing matches "{query}"</p>}
              {groups.map((group) => {
                const items = results.filter((c) => c.group === group);
                if (items.length === 0) return null;
                return (
                  <div key={group}>
                    <div className="cmdk-group-label">{group}</div>
                    {items.map((c) => {
                      const globalIndex = results.indexOf(c);
                      return (
                        <div
                          key={c.href}
                          className={`cmdk-item${globalIndex === activeIndex ? " active" : ""}`}
                          onMouseEnter={() => setActiveIndex(globalIndex)}
                          onClick={() => {
                            router.push(c.href);
                            setOpen(false);
                          }}
                        >
                          <span>{c.label}</span>
                          <span className="cmdk-item-desc">{c.description}</span>
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
