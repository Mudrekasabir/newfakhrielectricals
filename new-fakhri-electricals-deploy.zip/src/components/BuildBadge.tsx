import { BUILD_TAG } from "@/lib/version";

export default function BuildBadge() {
  return (
    <div
      style={{
        position: "fixed",
        bottom: 8,
        left: 10,
        fontSize: 13,
        color: "var(--text-muted)",
        opacity: 0.5,
        zIndex: 50,
        pointerEvents: "none",
      }}
    >
      build {BUILD_TAG}
    </div>
  );
}
