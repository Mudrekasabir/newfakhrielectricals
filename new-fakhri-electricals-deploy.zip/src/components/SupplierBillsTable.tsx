"use client";

import { useMemo, useState } from "react";
import AddSupplierBillForm, { SupplierBillRecord } from "@/components/AddSupplierBillForm";

type SupplierOption = { id: string; name: string };

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

export default function SupplierBillsTable({
  initialBills,
  suppliers,
}: {
  initialBills: SupplierBillRecord[];
  suppliers: SupplierOption[];
}) {
  const [bills, setBills] = useState(initialBills);
  const [filterSupplierId, setFilterSupplierId] = useState("");

  const visibleBills = useMemo(
    () => (filterSupplierId ? bills.filter((b) => b.supplierId === filterSupplierId) : bills),
    [bills, filterSupplierId]
  );

  return (
    <>
      <AddSupplierBillForm suppliers={suppliers} onCreated={(bill) => setBills((prev) => [bill, ...prev])} />

      <div className="panel">
        <div className="form-row" style={{ marginBottom: 18 }}>
          <div className="field" style={{ flex: 1, minWidth: 200, marginBottom: 0 }}>
            <label htmlFor="filter-supplier">Filter by supplier</label>
            <select id="filter-supplier" value={filterSupplierId} onChange={(e) => setFilterSupplierId(e.target.value)}>
              <option value="">All suppliers</option>
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {visibleBills.length === 0 ? (
          <p className="muted">No bills uploaded yet.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Bill date</th>
                <th>Supplier</th>
                <th>Bill #</th>
                <th>Amount</th>
                <th>Note</th>
                <th>Bill</th>
                <th>Uploaded by</th>
              </tr>
            </thead>
            <tbody>
              {visibleBills.map((b) => (
                <tr key={b.id} className="table-row-hover">
                  <td>{b.billDate ? formatDate(b.billDate) : formatDate(b.createdAt)}</td>
                  <td>
                    <a href={`/suppliers/${b.supplierId}`} style={{ color: "inherit", textDecoration: "underline" }}>
                      {b.supplierName}
                    </a>
                  </td>
                  <td>{b.billNumber || "—"}</td>
                  <td>Rs.{b.amount.toFixed(2)}</td>
                  <td>{b.note || "—"}</td>
                  <td>
                    <a href={`/api/supplier-bills/${b.id}/file`} target="_blank" rel="noreferrer" className="btn-secondary" style={{ textDecoration: "none" }}>
                      View
                    </a>
                  </td>
                  <td>{b.createdByName}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
