import type { Metadata } from "next";
import "./globals.css";
import Providers from "@/components/Providers";
import BuildBadge from "@/components/BuildBadge";
import CommandPalette from "@/components/CommandPalette";
import KeyboardFormNav from "@/components/KeyboardFormNav";
import ArrowKeyNav from "@/components/ArrowKeyNav";

export const metadata: Metadata = {
  title: "New Fakhri Electricals",
  description: "Sales and supplier management for New Fakhri Electricals",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>
          {children}
          <CommandPalette />
          <KeyboardFormNav />
          <ArrowKeyNav />
        </Providers>
        <BuildBadge />
      </body>
    </html>
  );
}
