import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSalesSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

/**
 * Deletes a logged outbound message from the chat thread. This only removes
 * our record of having sent it (the log/audit trail entry) — it can't and
 * doesn't unsend anything from the customer's actual WhatsApp/SMS, since
 * that leaves our server the moment the link is opened.
 *
 * A PURCHASE/RETURN message also created a real Sale/Return ledger row when
 * it was sent — deleting the message here does NOT touch that ledger entry,
 * so the customer's balance stays accurate. Staff who need to undo the sale
 * itself should use the sale/return records directly, not this endpoint.
 */
export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const { session, error } = await requireSalesSession();
  if (error) return error;

  const existing = await prisma.outboundMessage.findUnique({ where: { id: params.id } });
  if (!existing) {
    return NextResponse.json({ error: "Message not found" }, { status: 404 });
  }

  await prisma.outboundMessage.delete({ where: { id: params.id } });

  await logAudit({
    userId: session!.user.id,
    action: "MESSAGE_DELETED",
    entityType: "OutboundMessage",
    entityId: params.id,
    details: `Deleted a logged ${existing.channel} message`,
  });

  return NextResponse.json({ ok: true });
}
