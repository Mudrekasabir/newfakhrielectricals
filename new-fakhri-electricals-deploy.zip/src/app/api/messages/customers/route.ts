import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSalesSession } from "@/lib/authz";

export async function GET() {
  const { error } = await requireSalesSession();
  if (error) return error;

  const customers = await prisma.customer.findMany({
    include: {
      outboundMessages: { orderBy: { createdAt: "desc" }, take: 1 },
    },
    orderBy: { name: "asc" },
  });

  return NextResponse.json(
    customers.map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone,
      lastMessage: c.outboundMessages[0]?.body ?? null,
      lastMessageAt: c.outboundMessages[0]?.createdAt ?? null,
    }))
  );
}
