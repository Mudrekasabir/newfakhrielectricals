import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSalesSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";
import { isStaleSessionError } from "@/lib/prismaErrors";

export async function GET() {
  const { error } = await requireSalesSession();
  if (error) return error;

  const sales = await prisma.sale.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      customer: true,
      createdBy: { select: { name: true } },
      items: true,
    },
  });

  const serialized = sales.map((sale) => ({
    id: sale.id,
    createdAt: sale.createdAt,
    status: sale.status,
    totalAmount: Number(sale.totalAmount),
    paidAmount: Number(sale.paidAmount),
    customerName: sale.customer.name,
    createdByName: sale.createdBy.name,
    items: sale.items.map((item) => ({
      itemName: item.itemName,
      quantity: item.quantity,
      unitPrice: Number(item.unitPrice),
    })),
  }));

  return NextResponse.json(serialized);
}

// Each line is either a catalog product (productId + quantity — price comes
// from the product) or a one-off item typed in on the spot (customName +
// unitPrice + quantity — no catalog entry). A sale can mix both kinds of lines.
type SaleItemInput = {
  productId?: string;
  customName?: string;
  unitPrice?: number;
  quantity: number;
};

export async function POST(req: NextRequest) {
  const { session, error } = await requireSalesSession();
  if (error) return error;

  const body = await req.json();
  const customerId = String(body.customerId || "");
  const items: SaleItemInput[] = Array.isArray(body.items) ? body.items : [];
  const paidAmount = Number(body.paidAmount ?? 0);

  if (!customerId) {
    return NextResponse.json({ error: "Select a customer" }, { status: 400 });
  }
  if (items.length === 0) {
    return NextResponse.json({ error: "Add at least one item" }, { status: 400 });
  }
  for (const item of items) {
    if (!Number.isInteger(item.quantity) || item.quantity <= 0) {
      return NextResponse.json({ error: "Every item needs a quantity above zero" }, { status: 400 });
    }
    const isCatalogItem = Boolean(item.productId);
    const isCustomItem = Boolean(item.customName && item.customName.trim());
    if (!isCatalogItem && !isCustomItem) {
      return NextResponse.json({ error: "Every item needs either a product or a name" }, { status: 400 });
    }
    if (isCustomItem && !(Number(item.unitPrice) > 0)) {
      return NextResponse.json({ error: `"${item.customName}" needs a price above zero` }, { status: 400 });
    }
  }

  try {
    const result = await prisma.$transaction(async (tx) => {
      const customer = await tx.customer.findUnique({ where: { id: customerId } });
      if (!customer) throw new Error("Customer not found");

      const productIds = items.map((i) => i.productId).filter((id): id is string => Boolean(id));
      const products = productIds.length
        ? await tx.product.findMany({ where: { id: { in: productIds } } })
        : [];

      let totalAmount = 0;
      const itemsToCreate: { productId: string | null; itemName: string; quantity: number; unitPrice: number }[] = [];

      for (const item of items) {
        if (item.productId) {
          const product = products.find((p) => p.id === item.productId);
          if (!product) throw new Error("One of the selected products no longer exists");
          const unitPrice = Number(product.unitPrice);
          totalAmount += unitPrice * item.quantity;
          itemsToCreate.push({ productId: product.id, itemName: product.name, quantity: item.quantity, unitPrice });
        } else {
          const unitPrice = Number(item.unitPrice);
          totalAmount += unitPrice * item.quantity;
          itemsToCreate.push({ productId: null, itemName: item.customName!.trim(), quantity: item.quantity, unitPrice });
        }
      }

      const status = paidAmount >= totalAmount ? "PAID" : paidAmount > 0 ? "PARTIAL" : "DUE";

      const sale = await tx.sale.create({
        data: {
          customerId,
          createdById: session!.user.id,
          totalAmount,
          paidAmount,
          status,
          items: { create: itemsToCreate },
        },
      });

      return sale;
    });

    await logAudit({
      userId: session!.user.id,
      action: "SALE_CREATED",
      entityType: "Sale",
      entityId: result.id,
      details: `Sale of ${Number(result.totalAmount).toFixed(2)} for customer ${customerId}`,
    });

    return NextResponse.json({ id: result.id }, { status: 201 });
  } catch (err) {
    if (isStaleSessionError(err)) {
      return NextResponse.json(
        { error: "Your login session is out of date. Please log out and log back in, then try again." },
        { status: 401 }
      );
    }
    const message = err instanceof Error ? err.message : "Could not record the sale";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
