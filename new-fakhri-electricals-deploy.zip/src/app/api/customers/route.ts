import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSalesSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

export async function GET() {
  const { error } = await requireSalesSession();
  if (error) return error;

  const customers = await prisma.customer.findMany({
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(customers);
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireSalesSession();
  if (error) return error;

  const body = await req.json();
  const name = String(body.name || "").trim();
  const phone = String(body.phone || "").trim();
  const address = body.address ? String(body.address).trim() : null;

  if (!name || !phone) {
    return NextResponse.json({ error: "Name and phone are required" }, { status: 400 });
  }

  const existing = await prisma.customer.findUnique({ where: { phone } });
  if (existing) {
    return NextResponse.json({ error: "A customer with this phone number already exists" }, { status: 409 });
  }

  const customer = await prisma.customer.create({
    data: { name, phone, address },
  });

  await logAudit({
    userId: session!.user.id,
    action: "CUSTOMER_CREATED",
    entityType: "Customer",
    entityId: customer.id,
    details: `Created customer ${name}`,
  });

  return NextResponse.json(customer, { status: 201 });
}
