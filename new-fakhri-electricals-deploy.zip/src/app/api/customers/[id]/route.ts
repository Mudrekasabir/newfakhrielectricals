import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSalesSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const { error } = await requireSalesSession();
  if (error) return error;

  const customer = await prisma.customer.findUnique({ where: { id: params.id } });
  if (!customer) {
    return NextResponse.json({ error: "Customer not found" }, { status: 404 });
  }
  return NextResponse.json(customer);
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const { session, error } = await requireSalesSession();
  if (error) return error;

  const body = await req.json();
  const name = String(body.name || "").trim();
  const phone = String(body.phone || "").trim();
  const address = body.address ? String(body.address).trim() : null;

  if (!name || !phone) {
    return NextResponse.json({ error: "Name and phone are required" }, { status: 400 });
  }

  const existing = await prisma.customer.findUnique({ where: { id: params.id } });
  if (!existing) {
    return NextResponse.json({ error: "Customer not found" }, { status: 404 });
  }

  // Phone numbers are unique — check for a clash with a *different* customer.
  const clash = await prisma.customer.findUnique({ where: { phone } });
  if (clash && clash.id !== params.id) {
    return NextResponse.json({ error: "Another customer already uses this phone number" }, { status: 409 });
  }

  const customer = await prisma.customer.update({
    where: { id: params.id },
    data: { name, phone, address },
  });

  await logAudit({
    userId: session!.user.id,
    action: "CUSTOMER_EDITED",
    entityType: "Customer",
    entityId: customer.id,
    details: `Updated details for ${customer.name}`,
  });

  return NextResponse.json(customer);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const { session, error } = await requireSalesSession();
  if (error) return error;

  const existing = await prisma.customer.findUnique({ where: { id: params.id } });
  if (!existing) {
    return NextResponse.json({ error: "Customer not found" }, { status: 404 });
  }

  // Sales, returns, and outbound messages all reference this customer and
  // are kept as a permanent ledger/audit trail — deleting a customer who
  // has any of that history would either silently orphan those rows or
  // fail on the foreign key, so we block it with a clear reason instead.
  const [saleCount, returnCount, messageCount] = await Promise.all([
    prisma.sale.count({ where: { customerId: params.id } }),
    prisma.return.count({ where: { customerId: params.id } }),
    prisma.outboundMessage.count({ where: { customerId: params.id } }),
  ]);

  if (saleCount > 0 || returnCount > 0 || messageCount > 0) {
    return NextResponse.json(
      {
        error:
          "This customer has recorded sales, returns, or messages, so they can't be deleted — their history has to stay intact.",
      },
      { status: 409 }
    );
  }

  await prisma.customer.delete({ where: { id: params.id } });

  await logAudit({
    userId: session!.user.id,
    action: "CUSTOMER_DELETED",
    entityType: "Customer",
    entityId: params.id,
    details: `Deleted customer ${existing.name}`,
  });

  return NextResponse.json({ ok: true });
}
