import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSalesSession } from "@/lib/authz";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const { error } = await requireSalesSession();
  if (error) return error;

  const sale = await prisma.sale.findFirst({
    where: { customerId: params.id },
    orderBy: { createdAt: "desc" },
    include: { items: true },
  });

  if (!sale) {
    return NextResponse.json({ error: "No sales found for this customer" }, { status: 404 });
  }

  const items = sale.items.map((item) => `${item.quantity}x ${item.itemName}`).join(", ");
  const itemRows = sale.items.map((item) => ({
    name: item.itemName,
    quantity: item.quantity,
    unitPrice: Number(item.unitPrice),
  }));

  return NextResponse.json({
    items,
    itemRows,
    totalAmount: Number(sale.totalAmount),
    paidAmount: Number(sale.paidAmount),
    date: new Date(sale.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }),
  });
}
