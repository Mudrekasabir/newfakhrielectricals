import { NextResponse } from "next/server";
import { requireSalesSession } from "@/lib/authz";
import { getCustomerLedgerSummary } from "@/lib/balance";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const { error } = await requireSalesSession();
  if (error) return error;

  const summary = await getCustomerLedgerSummary(params.id);
  return NextResponse.json(summary);
}
