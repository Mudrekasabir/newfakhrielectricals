import { NextRequest, NextResponse } from "next/server";
import { renderToBuffer } from "@react-pdf/renderer";
import { prisma } from "@/lib/prisma";
import InvoiceDocument from "@/lib/pdf/InvoiceDocument";
import { buildDocNumber, parseReturnItemsSummary } from "@/lib/invoiceNumber";

export const runtime = "nodejs";

// Public, unauthenticated by design — same trust model as the invoice PDF
// route (see that file's comment): the return id is the unguessable token,
// this only ever serves that one read-only document.
export async function GET(_req: NextRequest, { params }: { params: { returnId: string } }) {
  const ret = await prisma.return.findUnique({
    where: { id: params.returnId },
    include: { customer: true },
  });

  if (!ret) {
    return NextResponse.json({ error: "Return not found" }, { status: 404 });
  }

  const items = parseReturnItemsSummary(ret.items).map((i) => ({ ...i, unitPrice: 0 }));

  const buffer = await renderToBuffer(
    InvoiceDocument({
      documentType: "RETURN",
      invoiceNumber: buildDocNumber("RET", ret.id, ret.createdAt),
      date: ret.createdAt.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }),
      customerName: ret.customer.name,
      customerPhone: ret.customer.phone,
      customerAddress: ret.customer.address,
      items,
      totalOverride: Number(ret.amount),
    })
  );

  return new NextResponse(buffer, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="return-${ret.id}.pdf"`,
      "Cache-Control": "private, max-age=0, no-store",
    },
  });
}
