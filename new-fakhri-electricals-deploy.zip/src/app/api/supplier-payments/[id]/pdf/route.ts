import { NextRequest, NextResponse } from "next/server";
import { renderToBuffer } from "@react-pdf/renderer";
import { prisma } from "@/lib/prisma";
import PaymentVoucherDocument from "@/lib/pdf/PaymentVoucherDocument";
import { buildDocNumber } from "@/lib/invoiceNumber";
import { getSupplierBalance } from "@/lib/supplierBalance";

// @react-pdf/renderer relies on Node built-ins internally — can't run on Edge.
export const runtime = "nodejs";

/**
 * Public, unauthenticated by design — same trust model as
 * /api/invoices/[saleId]/pdf: this is the link sent to the *supplier* via
 * WhatsApp/SMS, so it can't require a staff login. The payment id (a cuid)
 * is the access token — long and effectively unguessable. Only ever
 * exposes this one payment's read-only details.
 */
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const payment = await prisma.supplierPayment.findUnique({
    where: { id: params.id },
    include: { supplier: true, bill: { select: { billNumber: true } } },
  });

  if (!payment) {
    return NextResponse.json({ error: "Payment voucher not found" }, { status: 404 });
  }

  const outstandingBalance = await getSupplierBalance(payment.supplierId);

  const buffer = await renderToBuffer(
    PaymentVoucherDocument({
      voucherNumber: buildDocNumber("PAY", payment.id, payment.createdAt),
      date: payment.createdAt.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }),
      supplierName: payment.supplier.name,
      supplierPhone: payment.supplier.phone,
      supplierAddress: payment.supplier.address,
      amount: Number(payment.amount),
      method: payment.method,
      reference: payment.reference,
      billNumber: payment.bill?.billNumber || null,
      note: payment.note,
      outstandingBalance,
    })
  );

  return new NextResponse(buffer, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="payment-voucher-${payment.id}.pdf"`,
      "Cache-Control": "private, max-age=0, no-store",
    },
  });
}
