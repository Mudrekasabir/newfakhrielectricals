import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSuppliersSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

export async function GET(req: NextRequest) {
  const { error } = await requireSuppliersSession();
  if (error) return error;

  const supplierId = req.nextUrl.searchParams.get("supplierId");

  const payments = await prisma.supplierPayment.findMany({
    where: supplierId ? { supplierId } : undefined,
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { supplier: true, bill: { select: { billNumber: true, amount: true } } },
  });

  return NextResponse.json(
    payments.map((p) => ({
      id: p.id,
      createdAt: p.createdAt,
      amount: Number(p.amount),
      method: p.method,
      reference: p.reference,
      note: p.note,
      supplierId: p.supplierId,
      supplierName: p.supplier.name,
      supplierPhone: p.supplier.phone,
      billId: p.billId,
      billLabel: p.bill ? p.bill.billNumber || `Rs.${Number(p.bill.amount).toFixed(2)} bill` : null,
    }))
  );
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireSuppliersSession();
  if (error) return error;

  const body = await req.json();
  const supplierId = String(body.supplierId || "");
  const amount = Number(body.amount);
  const method = body.method ? String(body.method).trim() : null;
  const reference = body.reference ? String(body.reference).trim() : null;
  const note = body.note ? String(body.note).trim() : null;
  const billId = body.billId ? String(body.billId) : null;

  if (!supplierId) {
    return NextResponse.json({ error: "Select a supplier" }, { status: 400 });
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Enter an amount above zero" }, { status: 400 });
  }

  const supplier = await prisma.supplier.findUnique({ where: { id: supplierId } });
  if (!supplier) {
    return NextResponse.json({ error: "Supplier not found" }, { status: 404 });
  }

  let billLabel: string | null = null;
  if (billId) {
    const bill = await prisma.supplierBill.findUnique({ where: { id: billId } });
    if (!bill || bill.supplierId !== supplierId) {
      return NextResponse.json({ error: "That bill doesn't belong to this supplier" }, { status: 400 });
    }
    billLabel = bill.billNumber || `Rs.${Number(bill.amount).toFixed(2)} bill`;
  }

  const payment = await prisma.supplierPayment.create({
    data: { supplierId, billId, amount, method, reference, note },
  });

  await logAudit({
    userId: session!.user.id,
    action: "SUPPLIER_PAYMENT_RECORDED",
    entityType: "SupplierPayment",
    entityId: payment.id,
    details: `Paid ${amount.toFixed(2)} to ${supplier.name}`,
  });

  return NextResponse.json(
    {
      id: payment.id,
      createdAt: payment.createdAt,
      amount: Number(payment.amount),
      method: payment.method,
      reference: payment.reference,
      note: payment.note,
      supplierId: payment.supplierId,
      supplierName: supplier.name,
      supplierPhone: supplier.phone,
      billId: payment.billId,
      billLabel,
    },
    { status: 201 }
  );
}
