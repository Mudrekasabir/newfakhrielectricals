import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSalesSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const { session, error } = await requireSalesSession();
  if (error) return error;

  const body = await req.json();
  const name = String(body.name || "").trim();
  const sku = String(body.sku || "").trim();
  const unit = String(body.unit || "").trim();
  const unitPrice = Number(body.unitPrice);

  if (!name || !sku || !unit || !Number.isFinite(unitPrice) || unitPrice < 0) {
    return NextResponse.json({ error: "Name, SKU, unit, and a valid price are required" }, { status: 400 });
  }

  const skuOwner = await prisma.product.findUnique({ where: { sku } });
  if (skuOwner && skuOwner.id !== params.id) {
    return NextResponse.json({ error: "Another product already uses this SKU" }, { status: 409 });
  }

  const product = await prisma.product.update({
    where: { id: params.id },
    data: { name, sku, unit, unitPrice },
  });

  await logAudit({
    userId: session!.user.id,
    action: "PRODUCT_UPDATED",
    entityType: "Product",
    entityId: product.id,
    details: `Updated product ${name} (SKU ${sku})`,
  });

  return NextResponse.json({ ...product, unitPrice: Number(product.unitPrice) });
}
