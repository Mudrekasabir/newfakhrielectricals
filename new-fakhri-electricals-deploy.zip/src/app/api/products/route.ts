import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSalesSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

export async function GET() {
  const { error } = await requireSalesSession();
  if (error) return error;

  const products = await prisma.product.findMany({
    orderBy: { name: "asc" },
  });

  // Decimal fields aren't plain-serializable to the client, so convert here.
  const serialized = products.map((p) => ({
    ...p,
    unitPrice: Number(p.unitPrice),
  }));

  return NextResponse.json(serialized);
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireSalesSession();
  if (error) return error;

  const body = await req.json();
  const name = String(body.name || "").trim();
  const sku = String(body.sku || "").trim();
  const unit = String(body.unit || "pcs").trim() || "pcs";
  const unitPrice = Number(body.unitPrice);

  if (!name || !sku || !Number.isFinite(unitPrice) || unitPrice < 0) {
    return NextResponse.json({ error: "Name, SKU, and a valid price are required" }, { status: 400 });
  }

  const existing = await prisma.product.findUnique({ where: { sku } });
  if (existing) {
    return NextResponse.json({ error: "A product with this SKU already exists" }, { status: 409 });
  }

  const product = await prisma.product.create({
    data: { name, sku, unit, unitPrice },
  });

  await logAudit({
    userId: session!.user.id,
    action: "PRODUCT_CREATED",
    entityType: "Product",
    entityId: product.id,
    details: `Created product ${name} (SKU ${sku})`,
  });

  return NextResponse.json({ ...product, unitPrice: Number(product.unitPrice) }, { status: 201 });
}
