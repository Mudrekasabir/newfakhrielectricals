import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSuppliersSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

export async function GET() {
  const { error } = await requireSuppliersSession();
  if (error) return error;

  const suppliers = await prisma.supplier.findMany({ orderBy: { name: "asc" } });
  return NextResponse.json(suppliers);
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireSuppliersSession();
  if (error) return error;

  const body = await req.json();
  const name = String(body.name || "").trim();
  const phone = String(body.phone || "").trim();
  const address = body.address ? String(body.address).trim() : null;

  if (!name || !phone) {
    return NextResponse.json({ error: "Name and phone are required" }, { status: 400 });
  }

  const supplier = await prisma.supplier.create({ data: { name, phone, address } });

  await logAudit({
    userId: session!.user.id,
    action: "SUPPLIER_CREATED",
    entityType: "Supplier",
    entityId: supplier.id,
    details: `Added supplier ${name}`,
  });

  return NextResponse.json(supplier, { status: 201 });
}
