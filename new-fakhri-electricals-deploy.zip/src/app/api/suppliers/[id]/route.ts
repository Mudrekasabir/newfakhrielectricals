import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSuppliersSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { error } = await requireSuppliersSession();
  if (error) return error;

  const supplier = await prisma.supplier.findUnique({ where: { id: params.id } });
  if (!supplier) {
    return NextResponse.json({ error: "Supplier not found" }, { status: 404 });
  }
  return NextResponse.json(supplier);
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const { session, error } = await requireSuppliersSession();
  if (error) return error;

  const body = await req.json();
  const name = String(body.name || "").trim();
  const phone = String(body.phone || "").trim();
  const address = body.address ? String(body.address).trim() : null;

  if (!name || !phone) {
    return NextResponse.json({ error: "Name and phone are required" }, { status: 400 });
  }

  const existing = await prisma.supplier.findUnique({ where: { id: params.id } });
  if (!existing) {
    return NextResponse.json({ error: "Supplier not found" }, { status: 404 });
  }

  const supplier = await prisma.supplier.update({
    where: { id: params.id },
    data: { name, phone, address },
  });

  await logAudit({
    userId: session!.user.id,
    action: "SUPPLIER_EDITED",
    entityType: "Supplier",
    entityId: supplier.id,
    details: `Updated details for ${supplier.name}`,
  });

  return NextResponse.json(supplier);
}
