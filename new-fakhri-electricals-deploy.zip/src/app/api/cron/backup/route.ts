import { NextRequest, NextResponse } from "next/server";
import { exportDatabaseSnapshot, encrypt } from "@/lib/backup";
import { pushFileToGitHub } from "@/lib/githubBackupStore";

/**
 * Triggered daily by Vercel Cron (see vercel.json). Not tied to a user
 * session — instead it checks a shared secret Vercel sends automatically,
 * so this endpoint can't be used by anyone who doesn't have that secret,
 * even though it isn't behind a login.
 */
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const encryptionKey = process.env.BACKUP_ENCRYPTION_KEY;
  const githubToken = process.env.GITHUB_TOKEN;
  const githubRepo = process.env.GITHUB_BACKUP_REPO;

  if (!encryptionKey || !githubToken || !githubRepo) {
    return NextResponse.json(
      { error: "Backup is not configured — set BACKUP_ENCRYPTION_KEY, GITHUB_TOKEN, and GITHUB_BACKUP_REPO" },
      { status: 500 }
    );
  }

  try {
    const snapshot = await exportDatabaseSnapshot();
    const json = JSON.stringify(snapshot);
    const encrypted = encrypt(json, encryptionKey);

    const dateLabel = new Date().toISOString().slice(0, 10); // e.g. 2026-09-13
    const path = `backups/${dateLabel}.enc`;

    await pushFileToGitHub({
      token: githubToken,
      repo: githubRepo,
      path,
      content: encrypted,
      message: `Daily backup ${dateLabel}`,
    });

    return NextResponse.json({ ok: true, path, sizeBytes: encrypted.length });
  } catch (err) {
    console.error("Daily backup failed:", err);
    const message = err instanceof Error ? err.message : "Backup failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
