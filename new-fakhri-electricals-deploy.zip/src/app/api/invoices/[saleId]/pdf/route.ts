import { NextRequest, NextResponse } from "next/server";
import { renderToBuffer } from "@react-pdf/renderer";
import { prisma } from "@/lib/prisma";
import InvoiceDocument from "@/lib/pdf/InvoiceDocument";
import { buildDocNumber } from "@/lib/invoiceNumber";

// @react-pdf/renderer relies on Node built-ins internally — this route
// can't run on the Edge runtime.
export const runtime = "nodejs";

/**
 * Public, unauthenticated by design — this is the link that gets sent to
 * the *customer* via WhatsApp/SMS, so it can't require a staff login. The
 * sale id (a cuid) doubles as the access token: long and effectively
 * unguessable, the same trust model most small invoicing tools use for a
 * "view your invoice" link. It only ever exposes read-only data for that
 * one sale — no listing, no other customers' data, and it doesn't accept
 * writes.
 */
export async function GET(_req: NextRequest, { params }: { params: { saleId: string } }) {
  const sale = await prisma.sale.findUnique({
    where: { id: params.saleId },
    include: { items: true, customer: true },
  });

  if (!sale) {
    return NextResponse.json({ error: "Invoice not found" }, { status: 404 });
  }

  const buffer = await renderToBuffer(
    InvoiceDocument({
      documentType: "INVOICE",
      invoiceNumber: buildDocNumber("INV", sale.id, sale.createdAt),
      date: sale.createdAt.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }),
      customerName: sale.customer.name,
      customerPhone: sale.customer.phone,
      customerAddress: sale.customer.address,
      items: sale.items.map((i) => ({ name: i.itemName, quantity: i.quantity, unitPrice: Number(i.unitPrice) })),
      paidAmount: Number(sale.paidAmount),
    })
  );

  return new NextResponse(buffer, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="invoice-${sale.id}.pdf"`,
      "Cache-Control": "private, max-age=0, no-store",
    },
  });
}
