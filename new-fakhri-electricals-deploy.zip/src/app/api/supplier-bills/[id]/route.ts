import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSuppliersSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { error } = await requireSuppliersSession();
  if (error) return error;

  const bill = await prisma.supplierBill.findUnique({
    where: { id: params.id },
    include: { supplier: { select: { name: true, phone: true } } },
  });
  if (!bill) {
    return NextResponse.json({ error: "Bill not found" }, { status: 404 });
  }

  return NextResponse.json({
    id: bill.id,
    supplierId: bill.supplierId,
    supplierName: bill.supplier.name,
    billNumber: bill.billNumber,
    amount: Number(bill.amount),
    billDate: bill.billDate,
    note: bill.note,
    fileName: bill.fileName,
    fileType: bill.fileType,
    createdAt: bill.createdAt,
  });
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const { session, error } = await requireSuppliersSession();
  if (error) return error;

  const bill = await prisma.supplierBill.findUnique({ where: { id: params.id } });
  if (!bill) {
    return NextResponse.json({ error: "Bill not found" }, { status: 404 });
  }

  // Payments that were linked to this bill for reference stay on record —
  // just unlinked — so a payment can never silently disappear.
  await prisma.$transaction([
    prisma.supplierPayment.updateMany({ where: { billId: bill.id }, data: { billId: null } }),
    prisma.supplierBill.delete({ where: { id: bill.id } }),
  ]);

  await logAudit({
    userId: session!.user.id,
    action: "SUPPLIER_BILL_DELETED",
    entityType: "SupplierBill",
    entityId: bill.id,
    details: `Removed bill of ${Number(bill.amount).toFixed(2)}`,
  });

  return NextResponse.json({ ok: true });
}
