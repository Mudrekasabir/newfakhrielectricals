import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSuppliersSession } from "@/lib/authz";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const { error } = await requireSuppliersSession();
  if (error) return error;

  const bill = await prisma.supplierBill.findUnique({
    where: { id: params.id },
    select: { fileData: true, fileType: true, fileName: true },
  });
  if (!bill) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return new NextResponse(bill.fileData, {
    headers: {
      "Content-Type": bill.fileType,
      // "inline" lets images/PDFs open in a new tab instead of forcing a
      // download — staff can eyeball the bill without leaving the browser.
      "Content-Disposition": `inline; filename="${encodeURIComponent(bill.fileName)}"`,
      "Cache-Control": "private, max-age=3600",
    },
  });
}
