import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSuppliersSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";

// Kept well under typical serverless request-body limits (Vercel's default
// is 4.5MB) so uploads fail with our own clear message instead of a generic
// platform-level error.
const MAX_FILE_BYTES = 4 * 1024 * 1024;
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/heic", "image/heif", "application/pdf"];

export async function GET(req: NextRequest) {
  const { error } = await requireSuppliersSession();
  if (error) return error;

  const supplierId = req.nextUrl.searchParams.get("supplierId");

  const bills = await prisma.supplierBill.findMany({
    where: supplierId ? { supplierId } : undefined,
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { supplier: { select: { name: true, phone: true } }, createdBy: { select: { name: true } } },
  });

  return NextResponse.json(
    bills.map((b) => ({
      id: b.id,
      supplierId: b.supplierId,
      supplierName: b.supplier.name,
      supplierPhone: b.supplier.phone,
      billNumber: b.billNumber,
      amount: Number(b.amount),
      billDate: b.billDate,
      note: b.note,
      fileName: b.fileName,
      fileType: b.fileType,
      createdAt: b.createdAt,
      createdByName: b.createdBy.name,
    }))
  );
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireSuppliersSession();
  if (error) return error;

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "Could not read the upload — try again" }, { status: 400 });
  }

  const supplierId = String(form.get("supplierId") || "");
  const amount = Number(form.get("amount"));
  const billNumber = form.get("billNumber") ? String(form.get("billNumber")).trim() : null;
  const billDateRaw = form.get("billDate");
  const note = form.get("note") ? String(form.get("note")).trim() : null;
  const file = form.get("file");

  if (!supplierId) {
    return NextResponse.json({ error: "Select a supplier" }, { status: 400 });
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Enter the bill's total amount (above zero)" }, { status: 400 });
  }
  if (!(file instanceof File) || file.size === 0) {
    return NextResponse.json({ error: "Attach the supplier's bill — a photo or PDF" }, { status: 400 });
  }
  if (file.size > MAX_FILE_BYTES) {
    return NextResponse.json({ error: "That file is too large — please keep it under 4MB" }, { status: 400 });
  }
  if (!ALLOWED_TYPES.includes(file.type)) {
    return NextResponse.json({ error: "Only JPG, PNG, WEBP, or PDF files are supported" }, { status: 400 });
  }

  let billDate: Date | null = null;
  if (billDateRaw) {
    const parsed = new Date(String(billDateRaw));
    if (!Number.isNaN(parsed.getTime())) billDate = parsed;
  }

  const supplier = await prisma.supplier.findUnique({ where: { id: supplierId } });
  if (!supplier) {
    return NextResponse.json({ error: "Supplier not found" }, { status: 404 });
  }

  const fileData = Buffer.from(await file.arrayBuffer());

  const bill = await prisma.supplierBill.create({
    data: {
      supplierId,
      createdById: session!.user.id,
      billNumber,
      amount,
      billDate,
      note,
      fileName: file.name || "bill",
      fileType: file.type,
      fileData,
    },
  });

  await logAudit({
    userId: session!.user.id,
    action: "SUPPLIER_BILL_UPLOADED",
    entityType: "SupplierBill",
    entityId: bill.id,
    details: `Bill of ${amount.toFixed(2)} from supplier ${supplier.name}`,
  });

  return NextResponse.json(
    {
      id: bill.id,
      supplierId: bill.supplierId,
      supplierName: supplier.name,
      supplierPhone: supplier.phone,
      billNumber: bill.billNumber,
      amount: Number(bill.amount),
      billDate: bill.billDate,
      note: bill.note,
      fileName: bill.fileName,
      fileType: bill.fileType,
      createdAt: bill.createdAt,
      createdByName: session!.user.name || "",
    },
    { status: 201 }
  );
}
