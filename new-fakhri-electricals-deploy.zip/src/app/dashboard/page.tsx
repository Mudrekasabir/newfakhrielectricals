import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import SignOutButton from "@/components/SignOutButton";

function greeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const role = session.user.role;
  const canSeeSales = role === "ADMIN" || role === "SALES";
  const canSeeSuppliers = role === "ADMIN" || role === "SUPPLIER_STAFF";
  const firstName = session.user.name?.split(" ")[0] || session.user.name;

  return (
    <div className="page">
      <div className="topbar">
        <span className="brand">
          New Fakhri <span className="brand-mark">Electricals</span>
        </span>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <span className="muted">{session.user.name}</span>
          <SignOutButton />
        </div>
      </div>

      <div className="content" style={{ maxWidth: 980, animation: "dash-fade-in 0.35s ease" }}>
        <h1 style={{ fontSize: 30, marginBottom: 6, letterSpacing: "-0.01em" }}>
          {greeting()}, {firstName}
        </h1>
        <p className="muted" style={{ marginBottom: 32, fontSize: 17 }}>
          What do you want to open? Press{" "}
          <kbd
            style={{
              background: "var(--panel)",
              border: "1px solid var(--panel-border)",
              borderRadius: 4,
              padding: "2px 7px",
              fontFamily: "inherit",
              boxShadow: "0 1px 2px rgba(28,33,40,0.06)",
            }}
          >
            Ctrl
          </kbd>{" "}
          +{" "}
          <kbd
            style={{
              background: "var(--panel)",
              border: "1px solid var(--panel-border)",
              borderRadius: 4,
              padding: "2px 7px",
              fontFamily: "inherit",
              boxShadow: "0 1px 2px rgba(28,33,40,0.06)",
            }}
          >
            K
          </kbd>{" "}
          anytime to jump straight to a page without touching the mouse.
        </p>

        <div className="choice-grid">
          {canSeeSales && (
            <a href="/sales" className="choice-card">
              <div className="choice-card-icon choice-card-icon-sales" aria-hidden="true">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="9" cy="21" r="1" />
                  <circle cx="20" cy="21" r="1" />
                  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                </svg>
              </div>
              <h2>Sales</h2>
              <p>Customers, invoices, daily sales, and WhatsApp/SMS receipts.</p>
            </a>
          )}
          {canSeeSuppliers && (
            <a href="/suppliers" className="choice-card choice-card-suppliers">
              <div className="choice-card-icon choice-card-icon-suppliers" aria-hidden="true">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="1" y="3" width="15" height="13" />
                  <path d="M16 8h4l3 3v5h-7V8z" />
                  <circle cx="5.5" cy="18.5" r="2.5" />
                  <circle cx="18.5" cy="18.5" r="2.5" />
                </svg>
              </div>
              <h2>Suppliers</h2>
              <p>Supplier records, uploaded bills, and payment tracking.</p>
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
