import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SuppliersNav from "@/components/SuppliersNav";
import RecordPaymentForm from "@/components/RecordPaymentForm";

export default async function SupplierPaymentsPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SALES") redirect("/dashboard");

  const [suppliers, payments] = await Promise.all([
    prisma.supplier.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, phone: true } }),
    prisma.supplierPayment.findMany({
      orderBy: { createdAt: "desc" },
      take: 200,
      include: { supplier: true, bill: { select: { billNumber: true, amount: true } } },
    }),
  ]);

  const serializedPayments = payments.map((p) => ({
    id: p.id,
    createdAt: p.createdAt.toISOString(),
    amount: Number(p.amount),
    method: p.method,
    reference: p.reference,
    note: p.note,
    supplierId: p.supplierId,
    supplierName: p.supplier.name,
    supplierPhone: p.supplier.phone,
    billId: p.billId,
    billLabel: p.bill ? p.bill.billNumber || `Rs.${Number(p.bill.amount).toFixed(2)} bill` : null,
  }));

  return (
    <div className="page">
      <div className="topbar">
        <a href="/dashboard" className="muted">
          ← Dashboard
        </a>
        <span className="brand">Suppliers — Payments</span>
        <span />
      </div>
      <div className="content">
        <SuppliersNav />

        {suppliers.length === 0 ? (
          <div className="panel">
            <p className="muted" style={{ margin: 0 }}>
              You need at least one supplier before recording a payment. <a href="/suppliers">Add a supplier</a> first.
            </p>
          </div>
        ) : (
          <RecordPaymentForm suppliers={suppliers} initialPayments={serializedPayments} />
        )}
      </div>
    </div>
  );
}
