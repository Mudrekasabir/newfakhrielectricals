import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SuppliersNav from "@/components/SuppliersNav";
import SupplierBillsTable from "@/components/SupplierBillsTable";

export default async function SupplierBillsPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SALES") redirect("/dashboard");

  const [bills, suppliers] = await Promise.all([
    prisma.supplierBill.findMany({
      orderBy: { createdAt: "desc" },
      take: 200,
      include: { supplier: { select: { name: true } }, createdBy: { select: { name: true } } },
    }),
    prisma.supplier.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true } }),
  ]);

  const serialized = bills.map((b) => ({
    id: b.id,
    supplierId: b.supplierId,
    supplierName: b.supplier.name,
    billNumber: b.billNumber,
    amount: Number(b.amount),
    billDate: b.billDate ? b.billDate.toISOString() : null,
    note: b.note,
    fileName: b.fileName,
    fileType: b.fileType,
    createdAt: b.createdAt.toISOString(),
    createdByName: b.createdBy.name,
  }));

  return (
    <div className="page">
      <div className="topbar">
        <a href="/dashboard" className="muted">
          ← Dashboard
        </a>
        <span className="brand">Suppliers — Bills</span>
        <span />
      </div>
      <div className="content">
        <SuppliersNav />

        {suppliers.length === 0 ? (
          <div className="panel">
            <p className="muted" style={{ margin: 0 }}>
              You need at least one supplier before uploading a bill. <a href="/suppliers">Add a supplier</a> first, then open its page to upload one.
            </p>
          </div>
        ) : (
          <SupplierBillsTable initialBills={serialized} suppliers={suppliers} />
        )}
      </div>
    </div>
  );
}
