import { getServerSession } from "next-auth";
import { redirect, notFound } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SuppliersNav from "@/components/SuppliersNav";
import SupplierDetail from "@/components/SupplierDetail";

export default async function SupplierDetailPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SALES") redirect("/dashboard");

  const supplier = await prisma.supplier.findUnique({ where: { id: params.id } });
  if (!supplier) notFound();

  const [bills, payments] = await Promise.all([
    prisma.supplierBill.findMany({ where: { supplierId: params.id }, orderBy: { createdAt: "desc" } }),
    prisma.supplierPayment.findMany({
      where: { supplierId: params.id },
      orderBy: { createdAt: "desc" },
      include: { bill: { select: { billNumber: true, amount: true } } },
    }),
  ]);

  const serializedBills = bills.map((b) => ({
    id: b.id,
    supplierId: b.supplierId,
    supplierName: supplier.name,
    billNumber: b.billNumber,
    amount: Number(b.amount),
    billDate: b.billDate ? b.billDate.toISOString() : null,
    note: b.note,
    fileName: b.fileName,
    fileType: b.fileType,
    createdAt: b.createdAt.toISOString(),
    createdByName: "",
  }));

  const serializedPayments = payments.map((p) => ({
    id: p.id,
    createdAt: p.createdAt.toISOString(),
    amount: Number(p.amount),
    method: p.method,
    reference: p.reference,
    note: p.note,
    supplierId: p.supplierId,
    supplierName: supplier.name,
    supplierPhone: supplier.phone,
    billId: p.billId,
    billLabel: p.bill ? p.bill.billNumber || `Rs.${Number(p.bill.amount).toFixed(2)} bill` : null,
  }));

  return (
    <div className="page">
      <div className="topbar">
        <a href="/suppliers" className="muted">
          ← Suppliers
        </a>
        <span className="brand">{supplier.name}</span>
        <span />
      </div>
      <div className="content">
        <SuppliersNav />
        <SupplierDetail
          supplier={{ id: supplier.id, name: supplier.name, phone: supplier.phone, address: supplier.address }}
          initialBills={serializedBills}
          initialPayments={serializedPayments}
        />
      </div>
    </div>
  );
}
