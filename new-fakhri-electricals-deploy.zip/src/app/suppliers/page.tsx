import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getAllSupplierBalances } from "@/lib/supplierBalance";
import SuppliersNav from "@/components/SuppliersNav";
import SuppliersManager from "@/components/SuppliersManager";

export default async function SuppliersPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SALES") redirect("/dashboard");

  const [suppliers, balances] = await Promise.all([
    prisma.supplier.findMany({ orderBy: { createdAt: "desc" } }),
    getAllSupplierBalances(),
  ]);

  return (
    <div className="page">
      <div className="topbar">
        <a href="/dashboard" className="muted">
          ← Dashboard
        </a>
        <span className="brand">Suppliers</span>
        <span />
      </div>
      <div className="content">
        <SuppliersNav />
        <SuppliersManager
          initialSuppliers={suppliers.map((s) => ({ id: s.id, name: s.name, phone: s.phone, address: s.address }))}
          initialBalances={balances}
        />
      </div>
    </div>
  );
}
