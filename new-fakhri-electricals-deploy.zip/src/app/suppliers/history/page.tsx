import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SuppliersNav from "@/components/SuppliersNav";
import { formatBalance } from "@/lib/balanceFormat";

function formatDateTime(d: Date) {
  return d.toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default async function SuppliersHistoryPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SALES") redirect("/dashboard");

  const [bills, payments] = await Promise.all([
    prisma.supplierBill.findMany({
      orderBy: { createdAt: "desc" },
      take: 200,
      include: { supplier: { select: { id: true, name: true } } },
    }),
    prisma.supplierPayment.findMany({
      orderBy: { createdAt: "desc" },
      take: 200,
      include: { supplier: { select: { id: true, name: true } }, bill: { select: { billNumber: true } } },
    }),
  ]);

  type Entry =
    | { kind: "bill"; id: string; createdAt: Date; supplierId: string; supplierName: string; amount: number; label: string }
    | { kind: "payment"; id: string; createdAt: Date; supplierId: string; supplierName: string; amount: number; label: string };

  const entries: Entry[] = [
    ...bills.map((b) => ({
      kind: "bill" as const,
      id: b.id,
      createdAt: b.createdAt,
      supplierId: b.supplier.id,
      supplierName: b.supplier.name,
      amount: Number(b.amount),
      label: [b.billNumber, b.note].filter(Boolean).join(" — ") || "Bill",
    })),
    ...payments.map((p) => ({
      kind: "payment" as const,
      id: p.id,
      createdAt: p.createdAt,
      supplierId: p.supplier.id,
      supplierName: p.supplier.name,
      amount: Number(p.amount),
      label: [p.method, p.reference, p.bill?.billNumber ? `against ${p.bill.billNumber}` : null, p.note].filter(Boolean).join(" · ") || "Payment",
    })),
  ].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

  const totalBilled = bills.reduce((sum, b) => sum + Number(b.amount), 0);
  const totalPaid = payments.reduce((sum, p) => sum + Number(p.amount), 0);
  const totalOutstanding = totalBilled - totalPaid;

  return (
    <div className="page">
      <div className="topbar">
        <a href="/dashboard" className="muted">
          ← Dashboard
        </a>
        <span className="brand">Suppliers — History</span>
        <span />
      </div>
      <div className="content">
        <SuppliersNav />

        <div className="panel" style={{ marginBottom: 24, display: "flex", gap: 32, flexWrap: "wrap" }}>
          <div>
            <p className="muted" style={{ margin: "0 0 4px", fontSize: 16 }}>
              Total billed
            </p>
            <p style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Rs.{totalBilled.toFixed(2)}</p>
          </div>
          <div>
            <p className="muted" style={{ margin: "0 0 4px", fontSize: 16 }}>
              Total paid
            </p>
            <p style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Rs.{totalPaid.toFixed(2)}</p>
          </div>
          <div>
            <p className="muted" style={{ margin: "0 0 4px", fontSize: 16 }}>
              Outstanding across all suppliers
            </p>
            <p style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>{formatBalance(totalOutstanding)}</p>
          </div>
        </div>

        <div className="panel">
          <h2 style={{ fontSize: 18, marginTop: 0 }}>Every bill and payment, newest first</h2>
          {entries.length === 0 ? (
            <p className="muted">Nothing recorded yet — upload a bill or record a payment from a supplier's page.</p>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Supplier</th>
                  <th>Type</th>
                  <th>Details</th>
                  <th>Amount</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {entries.map((e) => (
                  <tr key={`${e.kind}-${e.id}`} className="table-row-hover">
                    <td>{formatDateTime(e.createdAt)}</td>
                    <td>
                      <a href={`/suppliers/${e.supplierId}`} style={{ color: "inherit", textDecoration: "underline" }}>
                        {e.supplierName}
                      </a>
                    </td>
                    <td>
                      <span className={e.kind === "bill" ? "tag tag-due" : "tag tag-paid"}>
                        {e.kind === "bill" ? "Bill" : "Payment"}
                      </span>
                    </td>
                    <td>{e.label}</td>
                    <td>{e.kind === "bill" ? "+" : "-"}Rs.{e.amount.toFixed(2)}</td>
                    <td>
                      <a
                        href={e.kind === "bill" ? `/api/supplier-bills/${e.id}/file` : `/api/supplier-payments/${e.id}/pdf`}
                        target="_blank"
                        rel="noreferrer"
                        className="btn-secondary"
                        style={{ textDecoration: "none" }}
                      >
                        {e.kind === "bill" ? "View bill" : "View PDF"}
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
