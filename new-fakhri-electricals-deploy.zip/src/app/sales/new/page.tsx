import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SalesNav from "@/components/SalesNav";
import NewSaleForm from "@/components/NewSaleForm";

export default async function NewSalePage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SUPPLIER_STAFF") redirect("/dashboard");

  const [customers, products] = await Promise.all([
    prisma.customer.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, phone: true } }),
    prisma.product.findMany({ orderBy: { name: "asc" } }),
  ]);

  const serializedProducts = products.map((p) => ({
    id: p.id,
    name: p.name,
    unit: p.unit,
    unitPrice: Number(p.unitPrice),
  }));

  return (
    <div className="page">
      <div className="topbar">
        <a href="/dashboard" className="muted">
          ← Dashboard
        </a>
        <span className="brand">Sales — New sale</span>
        <span />
      </div>
      <div className="content">
        <SalesNav />

        {customers.length === 0 ? (
          <div className="panel">
            <p className="muted" style={{ margin: 0 }}>
              You need at least one customer before recording a sale. <a href="/sales/customers">Add a customer</a> first.
            </p>
          </div>
        ) : (
          <NewSaleForm customers={customers} products={serializedProducts} />
        )}
      </div>
    </div>
  );
}
