import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SalesNav from "@/components/SalesNav";
import ProductsManager from "@/components/ProductsManager";

export default async function ProductsPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SUPPLIER_STAFF") redirect("/dashboard");

  const products = await prisma.product.findMany({ orderBy: { name: "asc" } });

  return (
    <div className="page">
      <div className="topbar">
        <a href="/dashboard" className="muted">
          ← Dashboard
        </a>
        <span className="brand">Sales — Products</span>
        <span />
      </div>
      <div className="content">
        <SalesNav />
        <ProductsManager
          initialProducts={products.map((p) => ({
            id: p.id,
            name: p.name,
            sku: p.sku,
            unit: p.unit,
            unitPrice: Number(p.unitPrice),
          }))}
        />
      </div>
    </div>
  );
}
