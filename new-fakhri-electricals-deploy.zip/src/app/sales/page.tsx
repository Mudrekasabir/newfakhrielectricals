import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import SalesNav from "@/components/SalesNav";
import MessagingConsole from "@/components/MessagingConsole";

export default async function SalesPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SUPPLIER_STAFF") redirect("/dashboard");

  return (
    <div className="page page-fullscreen">
      <div className="topbar">
        <a href="/dashboard" className="muted">
          ← Dashboard
        </a>
        <span className="brand">Sales — Message customers</span>
        <span />
      </div>
      <div className="content content-fullscreen">
        <SalesNav />
        <MessagingConsole />
      </div>
    </div>
  );
}
