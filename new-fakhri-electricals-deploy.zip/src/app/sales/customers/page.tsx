import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SalesNav from "@/components/SalesNav";
import CustomersManager from "@/components/CustomersManager";

export default async function CustomersPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SUPPLIER_STAFF") redirect("/dashboard");

  const [customers, saleTotals, returnTotals] = await Promise.all([
    prisma.customer.findMany({ orderBy: { createdAt: "desc" } }),
    prisma.sale.groupBy({ by: ["customerId"], _sum: { totalAmount: true, paidAmount: true }, _count: true }),
    prisma.return.groupBy({ by: ["customerId"], _sum: { amount: true }, _count: true }),
  ]);

  const balances: Record<string, { balance: number; sales: number; returns: number }> = {};
  for (const row of saleTotals) {
    const due = Number(row._sum.totalAmount || 0) - Number(row._sum.paidAmount || 0);
    balances[row.customerId] = {
      balance: (balances[row.customerId]?.balance || 0) + due,
      sales: row._count,
      returns: balances[row.customerId]?.returns || 0,
    };
  }
  for (const row of returnTotals) {
    const refunded = Number(row._sum.amount || 0);
    balances[row.customerId] = {
      balance: (balances[row.customerId]?.balance || 0) - refunded,
      sales: balances[row.customerId]?.sales || 0,
      returns: row._count,
    };
  }

  return (
    <div className="page">
      <div className="topbar">
        <a href="/dashboard" className="muted">
          ← Dashboard
        </a>
        <span className="brand">Sales — Customers</span>
        <span />
      </div>
      <div className="content">
        <SalesNav />
        <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 12 }}>
          <a href="/sales/customers/ledger" className="btn-secondary" style={{ textDecoration: "none" }}>
            🖨 Print ledger — all customers
          </a>
        </div>
        <CustomersManager
          initialCustomers={customers.map((c) => ({ id: c.id, name: c.name, phone: c.phone, address: c.address }))}
          initialBalances={balances}
        />
      </div>
    </div>
  );
}
