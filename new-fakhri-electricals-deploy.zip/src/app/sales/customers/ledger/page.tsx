import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SalesNav from "@/components/SalesNav";
import CustomerLedgerPrint, { type LedgerRow } from "@/components/CustomerLedgerPrint";

export default async function CustomerLedgerPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SUPPLIER_STAFF") redirect("/dashboard");

  const [customers, saleTotals, returnTotals] = await Promise.all([
    prisma.customer.findMany({ orderBy: { name: "asc" } }),
    prisma.sale.groupBy({ by: ["customerId"], _sum: { totalAmount: true, paidAmount: true } }),
    prisma.return.groupBy({ by: ["customerId"], _sum: { amount: true } }),
  ]);

  const balances: Record<string, number> = {};
  for (const row of saleTotals) {
    const due = Number(row._sum.totalAmount || 0) - Number(row._sum.paidAmount || 0);
    balances[row.customerId] = (balances[row.customerId] || 0) + due;
  }
  for (const row of returnTotals) {
    const refunded = Number(row._sum.amount || 0);
    balances[row.customerId] = (balances[row.customerId] || 0) - refunded;
  }

  const rows: LedgerRow[] = customers.map((c) => ({
    id: c.id,
    name: c.name,
    phone: c.phone,
    address: c.address,
    balance: balances[c.id] || 0,
  }));

  return (
    <div className="page">
      <div className="topbar no-print">
        <a href="/sales/customers" className="muted">
          ← Customers
        </a>
        <span className="brand">Sales — Customer Ledger</span>
        <span />
      </div>
      <div className="content">
        <div className="no-print">
          <SalesNav />
        </div>
        <CustomerLedgerPrint rows={rows} />
      </div>
    </div>
  );
}
