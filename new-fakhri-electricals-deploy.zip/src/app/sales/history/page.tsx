import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SalesNav from "@/components/SalesNav";

function statusTagClass(status: string) {
  if (status === "PAID") return "tag tag-paid";
  if (status === "PARTIAL") return "tag tag-partial";
  return "tag tag-due";
}

export default async function SalesHistoryPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  if (session.user.role === "SUPPLIER_STAFF") redirect("/dashboard");

  const sales = await prisma.sale.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      customer: true,
      createdBy: { select: { name: true } },
      items: true,
    },
  });

  return (
    <div className="page">
      <div className="topbar">
        <a href="/dashboard" className="muted">
          ← Dashboard
        </a>
        <span className="brand">Sales — History</span>
        <span />
      </div>
      <div className="content">
        <SalesNav />

        <div className="panel">
          {sales.length === 0 ? (
            <p className="muted">No sales recorded yet.</p>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Customer</th>
                  <th>Items</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Recorded by</th>
                </tr>
              </thead>
              <tbody>
                {sales.map((sale) => (
                  <tr key={sale.id}>
                    <td>
                      {new Date(sale.createdAt).toLocaleString("en-IN", {
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </td>
                    <td>{sale.customer.name}</td>
                    <td>
                      {sale.items.map((item) => `${item.itemName} ×${item.quantity}`).join(", ")}
                    </td>
                    <td>{Number(sale.totalAmount).toFixed(2)}</td>
                    <td>
                      <span className={statusTagClass(sale.status)}>{sale.status}</span>
                    </td>
                    <td>{sale.createdBy.name}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
