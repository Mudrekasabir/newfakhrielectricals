import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import LoginForm from "@/components/LoginForm";

export default async function LoginPage() {
  const session = await getServerSession(authOptions);
  if (session) redirect("/dashboard");

  return (
    <div className="page">
      <div className="topbar">
        <span className="brand">
          New Fakhri <span className="brand-mark">Electricals</span>
        </span>
      </div>
      <div className="content">
        <LoginForm />
      </div>
    </div>
  );
}
