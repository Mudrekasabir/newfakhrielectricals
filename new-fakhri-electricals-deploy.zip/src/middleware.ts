import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    const { pathname } = req.nextUrl;
    const role = req.nextauth.token?.role;

    // A Sales-only account can never reach Supplier pages, and vice versa.
    // Admin passes through to both. This is the server-side enforcement —
    // the UI also hides links the role can't use, but this is what actually
    // stops someone typing the URL directly.
    if (pathname.startsWith("/suppliers") && role === "SALES") {
      return NextResponse.redirect(new URL("/dashboard", req.url));
    }
    if (pathname.startsWith("/sales") && role === "SUPPLIER_STAFF") {
      return NextResponse.redirect(new URL("/dashboard", req.url));
    }

    return NextResponse.next();
  },
  {
    callbacks: {
      // Must be logged in to reach any matched route below.
      authorized: ({ token }) => !!token,
    },
  }
);

export const config = {
  matcher: ["/dashboard/:path*", "/sales/:path*", "/suppliers/:path*"],
};
