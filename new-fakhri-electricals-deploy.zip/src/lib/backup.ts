import crypto from "crypto";
import { prisma } from "@/lib/prisma";

/**
 * Every table, exported as plain JSON. This is a full logical snapshot —
 * small enough for a shop's dataset to stay a lightweight text file (not a
 * binary DB dump), which is what makes committing it to git practical.
 */
export async function exportDatabaseSnapshot() {
  const [
    users,
    customers,
    products,
    sales,
    saleItems,
    outboundMessages,
    returns,
    suppliers,
    supplierBills,
    supplierPayments,
    auditLogs,
  ] = await Promise.all([
    prisma.user.findMany(),
    prisma.customer.findMany(),
    prisma.product.findMany(),
    prisma.sale.findMany(),
    prisma.saleItem.findMany(),
    prisma.outboundMessage.findMany(),
    prisma.return.findMany(),
    prisma.supplier.findMany(),
    prisma.supplierBill.findMany(),
    prisma.supplierPayment.findMany(),
    prisma.auditLog.findMany(),
  ]);

  return {
    exportedAt: new Date().toISOString(),
    schemaVersion: 1,
    tables: {
      users, // passwordHash is bcrypt-hashed already; kept so a restore can still log in
      customers,
      products,
      sales,
      saleItems,
      outboundMessages,
      returns,
      suppliers,
      supplierBills,
      supplierPayments,
      auditLogs,
    },
  };
}

const ALGORITHM = "aes-256-gcm";

/**
 * AES-256-GCM with a random IV per backup. BACKUP_ENCRYPTION_KEY must be a
 * 32-byte key, base64-encoded (generate with `openssl rand -base64 32`).
 * Output is a single self-contained string: iv, authTag, and ciphertext
 * each base64, colon-separated — everything needed to decrypt is in the
 * file itself except the key, which never leaves your env vars.
 */
export function encrypt(plaintext: string, base64Key: string): string {
  const key = Buffer.from(base64Key, "base64");
  if (key.length !== 32) {
    throw new Error("BACKUP_ENCRYPTION_KEY must decode to exactly 32 bytes — generate with `openssl rand -base64 32`");
  }
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return [iv.toString("base64"), authTag.toString("base64"), ciphertext.toString("base64")].join(":");
}

export function decrypt(payload: string, base64Key: string): string {
  const key = Buffer.from(base64Key, "base64");
  const [ivB64, authTagB64, ciphertextB64] = payload.split(":");
  if (!ivB64 || !authTagB64 || !ciphertextB64) {
    throw new Error("Malformed backup payload — expected iv:authTag:ciphertext");
  }
  const decipher = crypto.createDecipheriv(ALGORITHM, key, Buffer.from(ivB64, "base64"));
  decipher.setAuthTag(Buffer.from(authTagB64, "base64"));
  const plaintext = Buffer.concat([decipher.update(Buffer.from(ciphertextB64, "base64")), decipher.final()]);
  return plaintext.toString("utf8");
}
