// Bump this string whenever you hand off a new build. It's shown as a tiny
// badge in the corner of every page — after replacing the project folder,
// glance at the badge instead of hunting through files to confirm the new
// code actually deployed.
export const BUILD_TAG = "2026-09-07.fast-ui-3";
