/**
 * Creates a new file in a GitHub repo (no existing-SHA lookup needed, since
 * every backup gets its own dated path and is never overwritten). Requires
 * a fine-grained personal access token with "Contents: Read and write" on
 * just that one repo — nothing broader.
 */
export async function pushFileToGitHub(params: {
  token: string;
  repo: string; // "owner/repo-name"
  path: string; // e.g. "backups/2026-09-13.enc"
  content: string; // raw file content, will be base64-encoded here
  message: string;
}): Promise<void> {
  const { token, repo, path, content, message } = params;
  const res = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      message,
      content: Buffer.from(content, "utf8").toString("base64"),
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`GitHub push failed (${res.status}): ${body}`);
  }
}
