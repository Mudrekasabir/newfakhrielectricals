// No provider, no API keys, no approvals — this just builds the standard
// "click to chat" / "click to text" links that WhatsApp and every phone's
// SMS app already support. Opening one of these is exactly the same as a
// person manually opening a chat and typing the message; staff still taps
// Send inside WhatsApp/Messages themselves.

// Customer phones are stored as plain local numbers (see Customer.phone) —
// normalize to E.164, assuming India (+91) when no country code is given.
export function toE164(phone: string): string {
  if (phone.startsWith("+")) return phone;
  let digits = phone.replace(/\D/g, "");

  // Common in India: a number typed/copied with its trunk prefix, e.g.
  // "09893775528" for "9893775528". Strip it before the length checks
  // below, or this would otherwise become the invalid "+09893775528".
  if (digits.length === 11 && digits.startsWith("0")) {
    digits = digits.slice(1);
  }

  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 12 && digits.startsWith("91")) return `+${digits}`;
  return `+${digits}`;
}

/**
 * wa.me link: opens WhatsApp (app or web) with the chat to this number
 * pre-filled with the given text. Works with no WhatsApp Business Account,
 * no templates, no approval — it's the same link WhatsApp's own "click to
 * chat" tool generates.
 */
export function buildWhatsAppLink(phone: string, text: string): string {
  const digits = toE164(phone).replace(/\D/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}

/**
 * sms: link: opens the phone's SMS app with the recipient and body
 * pre-filled. The separator before "body=" differs by platform — iOS wants
 * "&", Android wants "?" — so the caller should pass the right one (see
 * smsBodySeparator below, which needs the browser's user agent).
 */
export function buildSmsLink(phone: string, text: string, separator: "?" | "&" = "?"): string {
  return `sms:${toE164(phone)}${separator}body=${encodeURIComponent(text)}`;
}

/** Client-only: iOS expects "&body=", Android/others expect "?body=". */
export function smsBodySeparator(): "?" | "&" {
  if (typeof navigator === "undefined") return "?";
  return /iPhone|iPad|iPod/i.test(navigator.userAgent) ? "&" : "?";
}
