import { prisma } from "@/lib/prisma";

/**
 * Records who did what, to which record, and when.
 * Call this from every route that creates/edits/deletes sales,
 * suppliers, supplier bills, or payments.
 *
 * This never throws. The real operation (the sale, the supplier edit,
 * the payment, etc.) has already been committed by the time this runs —
 * if the audit write itself fails for any reason (e.g. a stale JWT
 * session pointing at a userId that no longer exists after a database
 * reseed), that should never turn a successful save into an error the
 * user sees. Failures are logged server-side instead.
 */
export async function logAudit(params: {
  userId: string | null;
  action: string;
  entityType: string;
  entityId: string;
  details?: string;
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: params.userId,
        action: params.action,
        entityType: params.entityType,
        entityId: params.entityId,
        details: params.details,
      },
    });
  } catch (err) {
    console.error("logAudit failed (non-fatal):", params.action, err);
  }
}
