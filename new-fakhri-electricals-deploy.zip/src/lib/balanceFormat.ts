// No imports here on purpose — this file gets used from client components
// (chat panel, customers list), so it must never pull in the Prisma client
// or anything else server-only. Keep it pure functions on plain numbers.

/** Human-readable balance label — shared by every screen that shows a balance. */
export function formatBalance(bal: number): string {
  if (bal > 0.004) return `Rs.${bal.toFixed(2)} due`;
  if (bal < -0.004) return `Rs.${Math.abs(bal).toFixed(2)} credit`;
  return "Fully settled";
}

/** CSS class for the balance pill — due (red), credit (amber), settled (copper). */
export function balanceTagClass(bal: number): string {
  if (bal > 0.004) return "tag tag-due";
  if (bal < -0.004) return "tag tag-partial";
  return "tag tag-paid";
}
