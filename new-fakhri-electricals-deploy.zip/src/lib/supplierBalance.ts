import { prisma } from "@/lib/prisma";

/**
 * Positive = the shop owes this supplier (due). Negative would mean the
 * shop has overpaid (credit) — shouldn't normally happen, but the formula
 * handles it the same way getCustomerBalance does. Always computed from
 * real bills/payments rows, never stored, so it can't drift.
 */
export async function getSupplierBalance(supplierId: string): Promise<number> {
  const [billsAgg, paymentsAgg] = await Promise.all([
    prisma.supplierBill.aggregate({ where: { supplierId }, _sum: { amount: true } }),
    prisma.supplierPayment.aggregate({ where: { supplierId }, _sum: { amount: true } }),
  ]);

  const billed = Number(billsAgg._sum.amount || 0);
  const paid = Number(paymentsAgg._sum.amount || 0);
  return billed - paid;
}

export type SupplierBalanceInfo = { balance: number; bills: number; payments: number };

/**
 * Balances (and bill/payment counts) for every supplier at once — used on
 * the suppliers list so it doesn't run one query per row.
 */
export async function getAllSupplierBalances(): Promise<Record<string, SupplierBalanceInfo>> {
  const [billTotals, paymentTotals] = await Promise.all([
    prisma.supplierBill.groupBy({ by: ["supplierId"], _sum: { amount: true }, _count: true }),
    prisma.supplierPayment.groupBy({ by: ["supplierId"], _sum: { amount: true }, _count: true }),
  ]);

  const balances: Record<string, SupplierBalanceInfo> = {};
  for (const row of billTotals) {
    balances[row.supplierId] = {
      balance: (balances[row.supplierId]?.balance || 0) + Number(row._sum.amount || 0),
      bills: row._count,
      payments: balances[row.supplierId]?.payments || 0,
    };
  }
  for (const row of paymentTotals) {
    balances[row.supplierId] = {
      balance: (balances[row.supplierId]?.balance || 0) - Number(row._sum.amount || 0),
      bills: balances[row.supplierId]?.bills || 0,
      payments: row._count,
    };
  }
  return balances;
}

// Re-exported for convenience so callers only need one import for both the
// numbers and their display formatting.
export { formatBalance, balanceTagClass } from "@/lib/balanceFormat";
