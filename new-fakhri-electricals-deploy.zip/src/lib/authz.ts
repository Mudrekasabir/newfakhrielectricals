import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";

/**
 * Every Sales API route calls this first. It re-checks the role on the
 * server, so this is what actually stops a Supplier-only account from
 * hitting these endpoints directly (a hidden UI link is not security).
 */
export async function requireSalesSession() {
  const session = await getServerSession(authOptions);

  if (!session) {
    return {
      session: null,
      error: NextResponse.json({ error: "Not authenticated" }, { status: 401 }),
    };
  }

  if (session.user.role !== "ADMIN" && session.user.role !== "SALES") {
    return {
      session: null,
      error: NextResponse.json({ error: "Forbidden" }, { status: 403 }),
    };
  }

  return { session, error: null as null };
}

/**
 * Same idea, for Supplier pages — an ADMIN or SUPPLIER_STAFF account only.
 */
export async function requireSuppliersSession() {
  const session = await getServerSession(authOptions);

  if (!session) {
    return {
      session: null,
      error: NextResponse.json({ error: "Not authenticated" }, { status: 401 }),
    };
  }

  if (session.user.role !== "ADMIN" && session.user.role !== "SUPPLIER_STAFF") {
    return {
      session: null,
      error: NextResponse.json({ error: "Forbidden" }, { status: 403 }),
    };
  }

  return { session, error: null as null };
}
