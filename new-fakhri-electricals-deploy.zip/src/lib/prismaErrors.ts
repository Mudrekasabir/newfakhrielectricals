/**
 * True when a Prisma write failed because a foreign key it referenced
 * doesn't exist — specifically the pattern that shows up when a login
 * session (JWT) was issued for a user row that's since been deleted or
 * recreated (e.g. after reseeding the database). The session cookie is
 * still "valid" (correctly signed) but the user id inside it no longer
 * exists, so any write that stamps `createdById` on a new record fails.
 *
 * Detected via Prisma's error code P2003 (foreign key constraint failed).
 */
export function isStaleSessionError(err: unknown): boolean {
  return (
    typeof err === "object" &&
    err !== null &&
    "code" in err &&
    (err as { code?: string }).code === "P2003"
  );
}
