// Server-only (rendered inside an API route with @react-pdf/renderer's
// `renderToBuffer` — never imported from a "use client" component). This is
// the actual PDF that gets linked from the WhatsApp/SMS invoice message, and
// what "Print" opens for both a live composer preview and a past sale, so
// there is exactly one invoice layout in the whole app, not several that
// could drift out of sync.
import { Document, Page, View, Text, StyleSheet } from "@react-pdf/renderer";
import { SHOP_NAME, SHOP_ADDRESS, SHOP_PHONE } from "@/lib/receiptTemplates";

export type InvoiceLineItem = { name: string; quantity: number; unitPrice: number };

export type InvoiceDocumentProps = {
  documentType: "INVOICE" | "RETURN";
  invoiceNumber: string;
  date: string; // pre-formatted display date, e.g. "6 Sep 2026"
  customerName: string;
  customerPhone: string;
  customerAddress?: string | null;
  items: InvoiceLineItem[];
  paidAmount?: number; // INVOICE only — ignored for RETURN
  // RETURN only — Return records store an items *summary* string (e.g.
  // "2x Wire, 1x Switch"), not per-line pricing, so the refund total can't
  // be derived from `items` the way an invoice's total can. Pass the real
  // recorded refund amount here instead.
  totalOverride?: number;
};

const copper = "#b8703f";
const ink = "#1a1a1a";
const muted = "#6b6b6b";
const border = "#e2ddd4";

const styles = StyleSheet.create({
  page: { padding: 36, fontSize: 11, color: ink, fontFamily: "Helvetica" },
  band: { height: 6, backgroundColor: copper, marginBottom: 24 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 24 },
  shopName: { fontSize: 20, fontFamily: "Helvetica-Bold", marginBottom: 4 },
  mutedText: { color: muted, fontSize: 10, lineHeight: 1.5 },
  docType: { fontSize: 18, fontFamily: "Helvetica-Bold", textAlign: "right", marginBottom: 4, color: copper },
  metaLabel: { color: muted, fontSize: 9, textAlign: "right" },
  metaValue: { fontSize: 11, textAlign: "right", marginBottom: 4 },
  billTo: { marginBottom: 20, paddingBottom: 14, borderBottom: `1px solid ${border}` },
  billToLabel: { color: muted, fontSize: 9, marginBottom: 3, letterSpacing: 0.5 },
  billToName: { fontSize: 14, fontFamily: "Helvetica-Bold", marginBottom: 2 },
  table: { marginBottom: 16 },
  tableHeaderRow: {
    flexDirection: "row",
    borderBottom: `1px solid ${ink}`,
    paddingBottom: 6,
    marginBottom: 6,
  },
  tableRow: {
    flexDirection: "row",
    borderBottom: `1px solid ${border}`,
    paddingVertical: 6,
  },
  th: { color: muted, fontSize: 9, letterSpacing: 0.5 },
  colNo: { width: "6%" },
  colName: { width: "44%" },
  colNameWide: { width: "80%" },
  colQty: { width: "14%", textAlign: "right" },
  colPrice: { width: "18%", textAlign: "right" },
  colAmount: { width: "18%", textAlign: "right" },
  totalsBlock: { width: 220, marginLeft: "auto", marginTop: 6 },
  totalsRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 3 },
  grandRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderTop: `1px solid ${ink}`,
    marginTop: 4,
    paddingTop: 8,
  },
  grandLabel: { fontSize: 14, fontFamily: "Helvetica-Bold" },
  grandValueDue: { fontSize: 14, fontFamily: "Helvetica-Bold", color: "#b5342a" },
  grandValueOk: { fontSize: 14, fontFamily: "Helvetica-Bold", color: "#1f7a3d" },
  footer: {
    position: "absolute",
    bottom: 36,
    left: 36,
    right: 36,
    textAlign: "center",
    color: muted,
    fontSize: 10,
    borderTop: `1px solid ${border}`,
    paddingTop: 10,
  },
});

function money(n: number): string {
  return `Rs.${n.toFixed(2)}`;
}

export default function InvoiceDocument({
  documentType,
  invoiceNumber,
  date,
  customerName,
  customerPhone,
  customerAddress,
  items,
  paidAmount = 0,
  totalOverride,
}: InvoiceDocumentProps) {
  const total = totalOverride ?? items.reduce((sum, i) => sum + i.quantity * i.unitPrice, 0);
  const due = documentType === "INVOICE" ? total - paidAmount : 0;
  const isReturn = documentType === "RETURN";

  return (
    <Document title={`${isReturn ? "Return" : "Invoice"} ${invoiceNumber}`}>
      <Page size="A4" style={styles.page}>
        <View style={styles.band} />

        <View style={styles.headerRow}>
          <View>
            <Text style={styles.shopName}>{SHOP_NAME}</Text>
            <Text style={styles.mutedText}>{SHOP_ADDRESS}</Text>
            <Text style={styles.mutedText}>{SHOP_PHONE}</Text>
          </View>
          <View>
            <Text style={styles.docType}>{isReturn ? "RETURN / CREDIT NOTE" : "INVOICE"}</Text>
            <Text style={styles.metaLabel}>{isReturn ? "RETURN #" : "INVOICE #"}</Text>
            <Text style={styles.metaValue}>{invoiceNumber}</Text>
            <Text style={styles.metaLabel}>DATE</Text>
            <Text style={styles.metaValue}>{date}</Text>
          </View>
        </View>

        <View style={styles.billTo}>
          <Text style={styles.billToLabel}>BILL TO</Text>
          <Text style={styles.billToName}>{customerName}</Text>
          <Text style={styles.mutedText}>{customerPhone}</Text>
          {customerAddress ? <Text style={styles.mutedText}>{customerAddress}</Text> : null}
        </View>

        <View style={styles.table}>
          <View style={styles.tableHeaderRow}>
            <Text style={[styles.th, styles.colNo]}>#</Text>
            <Text style={[styles.th, isReturn ? styles.colNameWide : styles.colName]}>DESCRIPTION</Text>
            <Text style={[styles.th, styles.colQty]}>QTY</Text>
            {!isReturn && <Text style={[styles.th, styles.colPrice]}>PRICE</Text>}
            {!isReturn && <Text style={[styles.th, styles.colAmount]}>AMOUNT</Text>}
          </View>
          {items.map((item, i) => (
            <View style={styles.tableRow} key={i}>
              <Text style={styles.colNo}>{i + 1}</Text>
              <Text style={isReturn ? styles.colNameWide : styles.colName}>{item.name}</Text>
              <Text style={styles.colQty}>{item.quantity}</Text>
              {!isReturn && <Text style={styles.colPrice}>{money(item.unitPrice)}</Text>}
              {!isReturn && <Text style={styles.colAmount}>{money(item.quantity * item.unitPrice)}</Text>}
            </View>
          ))}
        </View>

        <View style={styles.totalsBlock}>
          {isReturn ? (
            <View style={styles.grandRow}>
              <Text style={styles.grandLabel}>Refund amount</Text>
              <Text style={styles.grandLabel}>{money(total)}</Text>
            </View>
          ) : (
            <>
              <View style={styles.totalsRow}>
                <Text>Total</Text>
                <Text>{money(total)}</Text>
              </View>
              <View style={styles.totalsRow}>
                <Text>Paid</Text>
                <Text>{money(paidAmount)}</Text>
              </View>
              <View style={styles.grandRow}>
                <Text style={styles.grandLabel}>{due > 0.004 ? "Balance due" : "Status"}</Text>
                <Text style={due > 0.004 ? styles.grandValueDue : styles.grandValueOk}>
                  {due > 0.004 ? money(due) : "Paid in full"}
                </Text>
              </View>
            </>
          )}
        </View>

        <Text style={styles.footer}>Thank you for your business — {SHOP_NAME}</Text>
      </Page>
    </Document>
  );
}
