// The Sale/Return primary keys are cuids — unique but not something you'd
// want printed on a customer-facing invoice. This turns one into a short,
// readable number like "INV-20260906-K3F9A" by combining the record's date
// with the last few characters of its id, which is stable (same id always
// produces the same number) without needing a separate counter/table.
export function buildDocNumber(prefix: "INV" | "RET" | "PAY" | "RCT", id: string, createdAt: Date): string {
  const y = createdAt.getFullYear();
  const m = String(createdAt.getMonth() + 1).padStart(2, "0");
  const d = String(createdAt.getDate()).padStart(2, "0");
  const suffix = id.slice(-5).toUpperCase();
  return `${prefix}-${y}${m}${d}-${suffix}`;
}

/**
 * Return.items is stored as a plain summary string like "2x Wire, 1x
 * Switch" (see the RETURN branch of POST /api/messages) rather than
 * structured rows — this turns it back into rows for the PDF's table.
 * Unit price is unrecoverable from that string (returns only ever recorded
 * a single lump refund amount, not a per-line price), so each row is
 * quantity + description only; the actual refund total is passed to the
 * PDF separately rather than summed from these.
 */
export function parseReturnItemsSummary(summary: string): { name: string; quantity: number }[] {
  const parts = summary
    .split(",")
    .map((p) => p.trim())
    .filter(Boolean);

  if (parts.length === 0) return [{ name: summary.trim() || "Returned item", quantity: 1 }];

  return parts.map((part) => {
    const match = part.match(/^(\d+)\s*x\s*(.+)$/i);
    if (match) {
      return { name: match[2].trim(), quantity: Number(match[1]) };
    }
    return { name: part, quantity: 1 };
  });
}

