// Isomorphic on purpose (no server-only APIs) — imported by both the API
// route (to render the real, authoritative message) and the chat compose
// screen (to render an identical live preview), so what staff sees before
// sending is always exactly what gets sent.
//
// These render plain text, not WhatsApp markdown (*bold*, etc.) — the same
// body goes out over SMS too, which would show those symbols literally
// instead of rendering them. A divider line, capitalised labels for the
// headline numbers, and real structure do the same "this is a proper bill,
// not a note" job without depending on the channel.

export const SHOP_NAME = "New Fakhri Electricals";
// Used on the printable PDF invoice header and now in the message text
// too — plain placeholders for now; update these two once the shop's real
// address/phone are on hand.
export const SHOP_ADDRESS = "Your shop address here";
export const SHOP_PHONE = "Your phone number here";

const DIVIDER = "------------------------------";

export type ReceiptItem = {
  name: string;
  quantity: number;
  unitPrice: number;
};

/** "6 Sep 2026" style date, used as the default when the caller doesn't pin one. */
export function todayDateLabel(): string {
  return new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

export function lineItemsTotal(items: ReceiptItem[]): number {
  return items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
}

function money(n: number): string {
  return `Rs.${n.toFixed(2)}`;
}

// Two lines per item — the name on its own line, quantity/rate/amount
// indented below — reads far better than one long crammed line on a phone
// screen, especially once item names get longer than a word or two.
function formatPricedItemLines(items: ReceiptItem[]): string {
  return items
    .map((item, i) => {
      const amount = item.unitPrice * item.quantity;
      return `${i + 1}) ${item.name}\n   Qty ${item.quantity} x ${money(item.unitPrice)} = ${money(amount)}`;
    })
    .join("\n");
}

function formatPlainItemLines(items: { name: string; quantity: number }[]): string {
  return items.map((item, i) => `${i + 1}) ${item.name} x${item.quantity}`).join("\n");
}

function shopHeader(): string {
  return `${SHOP_NAME}\n${SHOP_ADDRESS}\nPh: ${SHOP_PHONE}`;
}

export type PurchaseReceiptData = {
  customerName: string;
  customerPhone?: string;
  items: ReceiptItem[];
  paidAmount: number;
  date: string; // e.g. "6 Sep 2026"
};

export function renderPurchaseReceipt(data: PurchaseReceiptData): string {
  const totalAmount = lineItemsTotal(data.items);
  const due = totalAmount - data.paidAmount;
  const billTo = data.customerPhone ? `${data.customerName} (${data.customerPhone})` : data.customerName;

  const statusLine =
    due > 0.004
      ? `BALANCE DUE: ${money(due)}`
      : data.paidAmount > totalAmount + 0.004
        ? `PAID IN FULL — change/credit: ${money(data.paidAmount - totalAmount)}`
        : "STATUS: PAID IN FULL";

  return (
    `${shopHeader()}\n` +
    `${DIVIDER}\n` +
    `INVOICE - ${data.date}\n` +
    `Bill to: ${billTo}\n\n` +
    `${formatPricedItemLines(data.items)}\n` +
    `${DIVIDER}\n` +
    `Total: ${money(totalAmount)}\n` +
    `Paid:  ${money(data.paidAmount)}\n` +
    `${statusLine}\n` +
    `${DIVIDER}\n` +
    `Thank you for your business!`
  );
}

export type SupplierPaymentReceiptData = {
  supplierName: string;
  amount: number;
  method: string | null;
  reference?: string | null;
  note: string | null;
  date: string;
};

export function renderSupplierPaymentReceipt(data: SupplierPaymentReceiptData): string {
  return (
    `${shopHeader()}\n` +
    `${DIVIDER}\n` +
    `PAYMENT CONFIRMATION - ${data.date}\n` +
    `To: ${data.supplierName}\n\n` +
    `Amount paid: ${money(data.amount)}\n` +
    `${data.method ? `Method: ${data.method}\n` : ""}` +
    `${data.reference ? `Reference: ${data.reference}\n` : ""}` +
    `${data.note ? `Note: ${data.note}\n` : ""}` +
    `${DIVIDER}\n` +
    `Thank you.`
  );
}

export type ReturnReceiptData = {
  customerName: string;
  customerPhone?: string;
  items: ReceiptItem[];
  date: string;
  updatedBalance: number; // positive = still owes this much, negative = credit
};

export function renderReturnReceipt(data: ReturnReceiptData): string {
  const amount = lineItemsTotal(data.items);
  const billTo = data.customerPhone ? `${data.customerName} (${data.customerPhone})` : data.customerName;
  const balanceLine =
    data.updatedBalance > 0.004
      ? `UPDATED BALANCE: ${money(data.updatedBalance)} due`
      : data.updatedBalance < -0.004
        ? `You now have a credit of ${money(Math.abs(data.updatedBalance))} with us`
        : "Your account is fully settled";

  return (
    `${shopHeader()}\n` +
    `${DIVIDER}\n` +
    `RETURN / CREDIT NOTE - ${data.date}\n` +
    `Customer: ${billTo}\n\n` +
    `${formatPlainItemLines(data.items)}\n` +
    `${DIVIDER}\n` +
    `Refund amount: ${money(amount)}\n` +
    `${balanceLine}\n` +
    `${DIVIDER}\n` +
    `Thank you.`
  );
}

export type CustomerPaymentReceiptData = {
  customerName: string;
  customerPhone?: string;
  amount: number;
  method: string | null;
  reference?: string | null;
  note: string | null;
  date: string;
  updatedBalance: number; // positive = still owes this much, negative = credit
};

// Confirms a payment received from a customer *after* a purchase — e.g.
// they bought on credit and came back later to pay off some or all of it.
// Mirrors renderSupplierPaymentReceipt in shape, but also quotes the
// updated balance the way renderReturnReceipt does, since that's the
// number a customer actually cares about after paying something off.
export function renderCustomerPaymentReceipt(data: CustomerPaymentReceiptData): string {
  const billTo = data.customerPhone ? `${data.customerName} (${data.customerPhone})` : data.customerName;
  const balanceLine =
    data.updatedBalance > 0.004
      ? `BALANCE REMAINING: ${money(data.updatedBalance)} due`
      : data.updatedBalance < -0.004
        ? `You now have a credit of ${money(Math.abs(data.updatedBalance))} with us`
        : "Your account is fully settled";

  return (
    `${shopHeader()}\n` +
    `${DIVIDER}\n` +
    `PAYMENT RECEIVED - ${data.date}\n` +
    `From: ${billTo}\n\n` +
    `Amount received: ${money(data.amount)}\n` +
    `${data.method ? `Method: ${data.method}\n` : ""}` +
    `${data.reference ? `Reference: ${data.reference}\n` : ""}` +
    `${data.note ? `Note: ${data.note}\n` : ""}` +
    `${balanceLine}\n` +
    `${DIVIDER}\n` +
    `Thank you.`
  );
}
