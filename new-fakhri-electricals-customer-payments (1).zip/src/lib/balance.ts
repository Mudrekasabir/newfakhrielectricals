import { prisma } from "@/lib/prisma";
import type { Prisma, PrismaClient } from "@prisma/client";

type Db = PrismaClient | Prisma.TransactionClient;

/**
 * Positive = customer owes the shop (due). Negative = shop owes the
 * customer (credit, e.g. they returned more than they currently owe, or
 * overpaid). Computed from real records each time rather than stored, so
 * it's always consistent with the sales/returns/payments tables.
 *
 * Accepts an optional transaction client (`tx`) so it can be called from
 * inside a `prisma.$transaction(...)` and see uncommitted writes made
 * earlier in that same transaction — calling it with the plain `prisma`
 * client from inside a transaction would miss those.
 */
export async function getCustomerBalance(customerId: string, db: Db = prisma): Promise<number> {
  const [salesAgg, returnsAgg, paymentsAgg] = await Promise.all([
    db.sale.aggregate({
      where: { customerId },
      _sum: { totalAmount: true, paidAmount: true },
    }),
    db.return.aggregate({
      where: { customerId },
      _sum: { amount: true },
    }),
    db.customerPayment.aggregate({
      where: { customerId },
      _sum: { amount: true },
    }),
  ]);

  const totalAmount = Number(salesAgg._sum.totalAmount || 0);
  const paidAmount = Number(salesAgg._sum.paidAmount || 0);
  const returnedAmount = Number(returnsAgg._sum.amount || 0);
  const paymentsReceived = Number(paymentsAgg._sum.amount || 0);

  return totalAmount - paidAmount - returnedAmount - paymentsReceived;
}

export type LedgerSummary = {
  balance: number;
  saleCount: number;
  returnCount: number;
  paymentCount: number;
};

/**
 * Same calculation as getCustomerBalance, but also returns how many sale,
 * return, and payment records went into it — shown in the UI so staff can
 * sanity-check "is this balance actually reading anything" at a glance,
 * without needing to open the database.
 */
export async function getCustomerLedgerSummary(customerId: string, db: Db = prisma): Promise<LedgerSummary> {
  const [salesAgg, returnsAgg, paymentsAgg] = await Promise.all([
    db.sale.aggregate({
      where: { customerId },
      _sum: { totalAmount: true, paidAmount: true },
      _count: true,
    }),
    db.return.aggregate({
      where: { customerId },
      _sum: { amount: true },
      _count: true,
    }),
    db.customerPayment.aggregate({
      where: { customerId },
      _sum: { amount: true },
      _count: true,
    }),
  ]);

  const totalAmount = Number(salesAgg._sum.totalAmount || 0);
  const paidAmount = Number(salesAgg._sum.paidAmount || 0);
  const returnedAmount = Number(returnsAgg._sum.amount || 0);
  const paymentsReceived = Number(paymentsAgg._sum.amount || 0);

  return {
    balance: totalAmount - paidAmount - returnedAmount - paymentsReceived,
    saleCount: salesAgg._count,
    returnCount: returnsAgg._count,
    paymentCount: paymentsAgg._count,
  };
}

// Re-exported so existing server-side imports of these two helpers from
// "@/lib/balance" keep working — the actual implementation lives in
// balanceFormat.ts, which has no server-only imports and is safe to use
// from client components too.
export { formatBalance, balanceTagClass } from "@/lib/balanceFormat";
