// Server-only, same pattern as PaymentVoucherDocument.tsx — this is the
// actual PDF linked from the WhatsApp/SMS payment-received confirmation
// sent to a *customer* after they pay off some or all of what they owe.
import { Document, Page, View, Text, StyleSheet } from "@react-pdf/renderer";
import { SHOP_NAME, SHOP_ADDRESS, SHOP_PHONE } from "@/lib/receiptTemplates";

export type CustomerPaymentReceiptProps = {
  receiptNumber: string;
  date: string; // pre-formatted display date, e.g. "6 Sep 2026"
  customerName: string;
  customerPhone: string;
  customerAddress?: string | null;
  amount: number;
  method?: string | null;
  reference?: string | null;
  note?: string | null;
  updatedBalance: number; // what the customer still owes, after this payment (negative = credit)
};

const copper = "#b8703f";
const ink = "#1a1a1a";
const muted = "#6b6b6b";
const border = "#e2ddd4";

const styles = StyleSheet.create({
  page: { padding: 36, fontSize: 11, color: ink, fontFamily: "Helvetica" },
  band: { height: 6, backgroundColor: copper, marginBottom: 24 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 24 },
  shopName: { fontSize: 20, fontFamily: "Helvetica-Bold", marginBottom: 4 },
  mutedText: { color: muted, fontSize: 10, lineHeight: 1.5 },
  docType: { fontSize: 18, fontFamily: "Helvetica-Bold", textAlign: "right", marginBottom: 4, color: copper },
  metaLabel: { color: muted, fontSize: 9, textAlign: "right" },
  metaValue: { fontSize: 11, textAlign: "right", marginBottom: 4 },
  receivedFrom: { marginBottom: 20, paddingBottom: 14, borderBottom: `1px solid ${border}` },
  receivedFromLabel: { color: muted, fontSize: 9, marginBottom: 3, letterSpacing: 0.5 },
  receivedFromName: { fontSize: 14, fontFamily: "Helvetica-Bold", marginBottom: 2 },
  detailsBlock: { marginBottom: 20 },
  detailRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 6,
    borderBottom: `1px solid ${border}`,
  },
  detailLabel: { color: muted },
  detailValue: { fontFamily: "Helvetica-Bold" },
  totalsBlock: { width: 240, marginLeft: "auto", marginTop: 10 },
  grandRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderTop: `1px solid ${ink}`,
    marginTop: 4,
    paddingTop: 8,
  },
  grandLabel: { fontSize: 14, fontFamily: "Helvetica-Bold" },
  amountValue: { fontSize: 16, fontFamily: "Helvetica-Bold", color: "#1f7a3d" },
  balanceRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 3 },
  balanceDue: { color: "#b5342a", fontFamily: "Helvetica-Bold" },
  balanceOk: { color: "#1f7a3d", fontFamily: "Helvetica-Bold" },
  footer: {
    position: "absolute",
    bottom: 36,
    left: 36,
    right: 36,
    textAlign: "center",
    color: muted,
    fontSize: 10,
    borderTop: `1px solid ${border}`,
    paddingTop: 10,
  },
});

function money(n: number): string {
  return `Rs.${n.toFixed(2)}`;
}

export default function CustomerPaymentReceiptDocument({
  receiptNumber,
  date,
  customerName,
  customerPhone,
  customerAddress,
  amount,
  method,
  reference,
  note,
  updatedBalance,
}: CustomerPaymentReceiptProps) {
  return (
    <Document title={`Payment Receipt ${receiptNumber}`}>
      <Page size="A4" style={styles.page}>
        <View style={styles.band} />

        <View style={styles.headerRow}>
          <View>
            <Text style={styles.shopName}>{SHOP_NAME}</Text>
            <Text style={styles.mutedText}>{SHOP_ADDRESS}</Text>
            <Text style={styles.mutedText}>{SHOP_PHONE}</Text>
          </View>
          <View>
            <Text style={styles.docType}>PAYMENT RECEIPT</Text>
            <Text style={styles.metaLabel}>RECEIPT #</Text>
            <Text style={styles.metaValue}>{receiptNumber}</Text>
            <Text style={styles.metaLabel}>DATE</Text>
            <Text style={styles.metaValue}>{date}</Text>
          </View>
        </View>

        <View style={styles.receivedFrom}>
          <Text style={styles.receivedFromLabel}>RECEIVED FROM</Text>
          <Text style={styles.receivedFromName}>{customerName}</Text>
          <Text style={styles.mutedText}>{customerPhone}</Text>
          {customerAddress ? <Text style={styles.mutedText}>{customerAddress}</Text> : null}
        </View>

        <View style={styles.detailsBlock}>
          {method ? (
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Payment method</Text>
              <Text style={styles.detailValue}>{method}</Text>
            </View>
          ) : null}
          {reference ? (
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Reference</Text>
              <Text style={styles.detailValue}>{reference}</Text>
            </View>
          ) : null}
          {note ? (
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Note</Text>
              <Text style={styles.detailValue}>{note}</Text>
            </View>
          ) : null}
        </View>

        <View style={styles.totalsBlock}>
          <View style={styles.grandRow}>
            <Text style={styles.grandLabel}>Amount received</Text>
            <Text style={styles.amountValue}>{money(amount)}</Text>
          </View>
          <View style={styles.balanceRow}>
            <Text style={styles.detailLabel}>{updatedBalance > 0.004 ? "Balance still due" : "Account status"}</Text>
            <Text style={updatedBalance > 0.004 ? styles.balanceDue : styles.balanceOk}>
              {updatedBalance > 0.004
                ? money(updatedBalance)
                : updatedBalance < -0.004
                  ? `Credit of ${money(Math.abs(updatedBalance))}`
                  : "Fully settled"}
            </Text>
          </View>
        </View>

        <Text style={styles.footer}>This confirms payment received — {SHOP_NAME}</Text>
      </Page>
    </Document>
  );
}
