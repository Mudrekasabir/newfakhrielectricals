import { NextRequest, NextResponse } from "next/server";
import { renderToBuffer } from "@react-pdf/renderer";
import { prisma } from "@/lib/prisma";
import CustomerPaymentReceiptDocument from "@/lib/pdf/CustomerPaymentReceiptDocument";
import { buildDocNumber } from "@/lib/invoiceNumber";
import { getCustomerBalance } from "@/lib/balance";

// @react-pdf/renderer relies on Node built-ins internally — can't run on Edge.
export const runtime = "nodejs";

/**
 * Public, unauthenticated by design — same trust model as
 * /api/invoices/[saleId]/pdf and /api/returns/[returnId]/pdf: this is the
 * link sent to the *customer* via WhatsApp/SMS, so it can't require a staff
 * login. The payment id (a cuid) is the access token — long and
 * effectively unguessable. Only ever exposes this one payment's read-only
 * details.
 */
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const payment = await prisma.customerPayment.findUnique({
    where: { id: params.id },
    include: { customer: true },
  });

  if (!payment) {
    return NextResponse.json({ error: "Payment receipt not found" }, { status: 404 });
  }

  const updatedBalance = await getCustomerBalance(payment.customerId);

  const buffer = await renderToBuffer(
    CustomerPaymentReceiptDocument({
      receiptNumber: buildDocNumber("RCT", payment.id, payment.createdAt),
      date: payment.createdAt.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }),
      customerName: payment.customer.name,
      customerPhone: payment.customer.phone,
      customerAddress: payment.customer.address,
      amount: Number(payment.amount),
      method: payment.method,
      reference: payment.reference,
      note: payment.note,
      updatedBalance,
    })
  );

  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="payment-receipt-${payment.id}.pdf"`,
      "Cache-Control": "private, max-age=0, no-store",
    },
  });
}
