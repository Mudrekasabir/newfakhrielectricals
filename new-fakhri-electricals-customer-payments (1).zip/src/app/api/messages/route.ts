import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSalesSession } from "@/lib/authz";
import { logAudit } from "@/lib/audit";
import { buildWhatsAppLink, buildSmsLink } from "@/lib/messageLinks";
import { getCustomerBalance } from "@/lib/balance";
import {
  renderPurchaseReceipt,
  renderReturnReceipt,
  renderCustomerPaymentReceipt,
  lineItemsTotal,
  todayDateLabel,
  type ReceiptItem,
} from "@/lib/receiptTemplates";
import { isStaleSessionError } from "@/lib/prismaErrors";

// The absolute origin to prefix onto the PDF invoice link included in the
// message body — req.nextUrl.origin already resolves to wherever the app
// is actually deployed (localhost while developing, the real domain in
// production), so nothing needs to be hardcoded or configured separately.
function pdfBaseUrl(req: NextRequest): string {
  return req.nextUrl.origin;
}

export async function GET(req: NextRequest) {
  const { error } = await requireSalesSession();
  if (error) return error;

  const customerId = req.nextUrl.searchParams.get("customerId");
  if (!customerId) {
    return NextResponse.json({ error: "customerId is required" }, { status: 400 });
  }

  // Build one merged, chronological timeline: messages actually sent, plus
  // every sale and return recorded for this customer (via New Sale / the
  // Return tab) — so a sale shows up in the chat even if nobody hit Send.
  // Each sale/return entry also carries the running balance right after it,
  // computed by walking the ledger in order.
  const [messages, sales, returns, payments] = await Promise.all([
    prisma.outboundMessage.findMany({ where: { customerId }, orderBy: { createdAt: "asc" } }),
    prisma.sale.findMany({ where: { customerId }, include: { items: true }, orderBy: { createdAt: "asc" } }),
    prisma.return.findMany({ where: { customerId }, orderBy: { createdAt: "asc" } }),
    prisma.customerPayment.findMany({ where: { customerId }, orderBy: { createdAt: "asc" } }),
  ]);

  type LedgerEvent =
    | { kind: "SALE"; createdAt: Date; id: string; items: { itemName: string; quantity: number; unitPrice: number }[]; totalAmount: number; paidAmount: number }
    | { kind: "RETURN"; createdAt: Date; id: string; items: string; amount: number }
    | { kind: "PAYMENT"; createdAt: Date; id: string; amount: number; method: string | null; reference: string | null; note: string | null };

  const ledgerEvents: LedgerEvent[] = [
    ...sales.map((s) => ({
      kind: "SALE" as const,
      createdAt: s.createdAt,
      id: s.id,
      items: s.items.map((i) => ({ itemName: i.itemName, quantity: i.quantity, unitPrice: Number(i.unitPrice) })),
      totalAmount: Number(s.totalAmount),
      paidAmount: Number(s.paidAmount),
    })),
    ...returns.map((r) => ({ kind: "RETURN" as const, createdAt: r.createdAt, id: r.id, items: r.items, amount: Number(r.amount) })),
    ...payments.map((p) => ({
      kind: "PAYMENT" as const,
      createdAt: p.createdAt,
      id: p.id,
      amount: Number(p.amount),
      method: p.method,
      reference: p.reference,
      note: p.note,
    })),
  ].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());

  let runningBalance = 0;
  const ledgerEntries = ledgerEvents.map((event) => {
    if (event.kind === "SALE") {
      runningBalance += event.totalAmount - event.paidAmount;
      return {
        kind: "SALE" as const,
        id: event.id,
        createdAt: event.createdAt,
        items: event.items,
        totalAmount: event.totalAmount,
        paidAmount: event.paidAmount,
        balanceAfter: runningBalance,
      };
    }
    if (event.kind === "RETURN") {
      runningBalance -= event.amount;
      return {
        kind: "RETURN" as const,
        id: event.id,
        createdAt: event.createdAt,
        items: event.items,
        amount: event.amount,
        balanceAfter: runningBalance,
      };
    }
    runningBalance -= event.amount;
    return {
      kind: "PAYMENT" as const,
      id: event.id,
      createdAt: event.createdAt,
      amount: event.amount,
      method: event.method,
      reference: event.reference,
      note: event.note,
      balanceAfter: runningBalance,
    };
  });

  const messageEntries = messages.map((m) => ({
    kind: "MESSAGE" as const,
    id: m.id,
    createdAt: m.createdAt,
    messageType: m.messageType,
    channel: m.channel,
    body: m.body,
  }));

  const timeline = [...messageEntries, ...ledgerEntries].sort(
    (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  return NextResponse.json(timeline);
}

type Body = {
  customerId: string;
  messageType: "PURCHASE" | "RETURN" | "PAYMENT" | "CUSTOM";
  channel: "WHATSAPP" | "SMS";
  // PURCHASE / RETURN — priced line items; the total/refund amount is always
  // computed from these server-side, never trusted from the client.
  items?: ReceiptItem[];
  paidAmount?: number; // PURCHASE only
  // PAYMENT — a customer paying off some/all of what they owe, independent
  // of any single sale. amount is required; method/reference/note/saleId
  // are all optional context, same shape as a supplier payment.
  amount?: number;
  method?: string;
  reference?: string;
  note?: string;
  saleId?: string;
  // Resends an already-recorded sale's invoice (e.g. the "Send via
  // WhatsApp/SMS" action on a past sale in the chat thread) instead of
  // recording a new one. When set, `items`/`paidAmount` are ignored — the
  // amounts are re-read from that Sale so the resent invoice always matches
  // the ledger, and no second Sale row gets created.
  // (Note: also reused as "apply this PAYMENT to this sale" when messageType is PAYMENT.)
  // CUSTOM
  customBody?: string;
  // Optional — lets staff tweak the auto-generated PURCHASE/RETURN/PAYMENT
  // receipt text (wording, an extra note, etc.) before it's sent. The
  // Sale/Return/Payment ledger entry is still created from the structured
  // fields exactly as before, so the amounts owed always stay accurate even
  // if the message text itself was hand-edited. Falls back to the standard
  // template when omitted or blank.
  editedBody?: string;
  date?: string;
  // client's platform-specific sms: separator, ignored for WHATSAPP
  smsSeparator?: "?" | "&";
};

function validateItems(items: unknown): items is ReceiptItem[] {
  if (!Array.isArray(items) || items.length === 0) return false;
  return items.every((i: any) => {
    return (
      i &&
      typeof i.name === "string" &&
      i.name.trim().length > 0 &&
      Number.isFinite(i.quantity) &&
      i.quantity > 0 &&
      Number.isFinite(i.unitPrice) &&
      i.unitPrice >= 0
    );
  });
}

/**
 * No provider in the loop — this renders the canonical invoice-style receipt
 * text server-side (so amounts can't be tampered with from the client),
 * builds the wa.me / sms: link for the channel staff picked, and logs the
 * message. The actual send happens when the client opens the returned link
 * and staff taps Send inside WhatsApp/Messages.
 *
 * For RETURN messages, this also records a Return ledger entry (see
 * src/lib/balance.ts) so the customer's balance is reduced by the refund
 * amount — the receipt text quotes the updated balance.
 */
export async function POST(req: NextRequest) {
  try {
    const { session, error } = await requireSalesSession();
    if (error) return error;

    const body: Body = await req.json();
    const customer = await prisma.customer.findUnique({ where: { id: body.customerId } });
    if (!customer) {
      return NextResponse.json({ error: "Customer not found" }, { status: 404 });
    }

    if (body.messageType === "CUSTOM" && body.channel !== "SMS") {
      return NextResponse.json(
        { error: "Custom messages can only be sent as SMS — WhatsApp doesn't allow free-form business-initiated messages" },
        { status: 400 }
      );
    }

    const date = body.date || todayDateLabel();

    let renderedBody: string;
    let isResend = false;

    if (body.messageType === "PURCHASE" && body.saleId) {
      // Resending an existing invoice — load the real, already-recorded
      // sale rather than trusting client-supplied items, and don't touch
      // the ledger at all.
      const sale = await prisma.sale.findUnique({
        where: { id: body.saleId },
        include: { items: true },
      });
      if (!sale || sale.customerId !== customer.id) {
        return NextResponse.json({ error: "Sale not found for this customer" }, { status: 404 });
      }

      const items: ReceiptItem[] = sale.items.map((i) => ({
        name: i.itemName,
        quantity: i.quantity,
        unitPrice: Number(i.unitPrice),
      }));
      const template = renderPurchaseReceipt({
        customerName: customer.name,
        customerPhone: customer.phone,
        items,
        paidAmount: Number(sale.paidAmount),
        date,
      });
      const edited = (body.editedBody || "").trim();
      renderedBody = `${edited || template}\n\nInvoice PDF: ${pdfBaseUrl(req)}/api/invoices/${sale.id}/pdf`;
      isResend = true;
    } else if (body.messageType === "PURCHASE") {
      if (!validateItems(body.items)) {
        return NextResponse.json({ error: "Add at least one item with a name, quantity, and price" }, { status: 400 });
      }
      const items = body.items;
      const totalAmount = lineItemsTotal(items);
      const paidAmount = Number(body.paidAmount || 0);
      const status = paidAmount >= totalAmount ? "PAID" : paidAmount > 0 ? "PARTIAL" : "DUE";

      // This is the fix: a "Purchase receipt" message must create a real Sale
      // row, or the customer's balance never moves no matter what gets sent.
      // Wrapped in a transaction with the receipt render so the amounts in
      // the message always match what actually landed in the ledger.
      renderedBody = await prisma.$transaction(async (tx) => {
        const sale = await tx.sale.create({
          data: {
            customerId: customer.id,
            createdById: session!.user.id,
            totalAmount,
            paidAmount,
            status,
            items: {
              create: items.map((i) => ({
                productId: null,
                itemName: i.name,
                quantity: Math.round(i.quantity),
                unitPrice: i.unitPrice,
              })),
            },
          },
        });

        const template = renderPurchaseReceipt({ customerName: customer.name, customerPhone: customer.phone, items, paidAmount, date });
        const edited = (body.editedBody || "").trim();
        return `${edited || template}\n\nInvoice PDF: ${pdfBaseUrl(req)}/api/invoices/${sale.id}/pdf`;
      });
    } else if (body.messageType === "RETURN") {
      if (!validateItems(body.items)) {
        return NextResponse.json({ error: "Add at least one returned item with a name, quantity, and price" }, { status: 400 });
      }
      const items = body.items;
      const returnAmount = lineItemsTotal(items);
      const itemsSummary = items.map((i) => `${i.quantity}x ${i.name}`).join(", ");

      // Record the return and render the receipt in one transaction so the
      // balance quoted in the message always matches the ledger.
      renderedBody = await prisma.$transaction(async (tx) => {
        const ret = await tx.return.create({
          data: {
            customerId: customer.id,
            staffUserId: session!.user.id,
            items: itemsSummary,
            amount: returnAmount,
          },
        });

        const updatedBalance = await getCustomerBalance(customer.id, tx);
        const template = renderReturnReceipt({ customerName: customer.name, customerPhone: customer.phone, items, date, updatedBalance });
        const edited = (body.editedBody || "").trim();
        return `${edited || template}\n\nReturn PDF: ${pdfBaseUrl(req)}/api/returns/${ret.id}/pdf`;
      });
    } else if (body.messageType === "PAYMENT") {
      const amount = Number(body.amount);
      if (!Number.isFinite(amount) || amount <= 0) {
        return NextResponse.json({ error: "Enter the amount the customer paid (above zero)" }, { status: 400 });
      }
      const method = body.method ? String(body.method).trim() : null;
      const reference = body.reference ? String(body.reference).trim() : null;
      const note = body.note ? String(body.note).trim() : null;
      const saleId = body.saleId ? String(body.saleId) : null;

      if (saleId) {
        const sale = await prisma.sale.findUnique({ where: { id: saleId } });
        if (!sale || sale.customerId !== customer.id) {
          return NextResponse.json({ error: "That sale doesn't belong to this customer" }, { status: 400 });
        }
      }

      // Record the payment and render the receipt in one transaction so the
      // balance quoted in the message always matches the ledger — same
      // pattern as PURCHASE/RETURN above.
      renderedBody = await prisma.$transaction(async (tx) => {
        const payment = await tx.customerPayment.create({
          data: { customerId: customer.id, staffUserId: session!.user.id, saleId, amount, method, reference, note },
        });

        const updatedBalance = await getCustomerBalance(customer.id, tx);
        const template = renderCustomerPaymentReceipt({
          customerName: customer.name,
          customerPhone: customer.phone,
          amount,
          method,
          reference,
          note,
          date,
          updatedBalance,
        });
        const edited = (body.editedBody || "").trim();
        return `${edited || template}\n\nReceipt PDF: ${pdfBaseUrl(req)}/api/customer-payments/${payment.id}/pdf`;
      });
    } else {
      const customBody = (body.customBody || "").trim();
      if (!customBody) {
        return NextResponse.json({ error: "Message body is required" }, { status: 400 });
      }
      renderedBody = customBody;
    }

    const link =
      body.channel === "WHATSAPP"
        ? buildWhatsAppLink(customer.phone, renderedBody)
        : buildSmsLink(customer.phone, renderedBody, body.smsSeparator || "?");

    const record = await prisma.outboundMessage.create({
      data: {
        customerId: customer.id,
        staffUserId: session!.user.id,
        messageType: body.messageType,
        channel: body.channel,
        body: renderedBody,
      },
    });

    await logAudit({
      userId: session!.user.id,
      action: isResend ? "MESSAGE_RESENT" : "MESSAGE_SENT",
      entityType: "OutboundMessage",
      entityId: record.id,
      details: `${isResend ? "Resent" : "Opened"} ${record.channel} to ${customer.name}`,
    });

    if (body.messageType === "PURCHASE" && !isResend) {
      await logAudit({
        userId: session!.user.id,
        action: "SALE_CREATED",
        entityType: "Customer",
        entityId: customer.id,
        details: `Sale recorded via purchase receipt to ${customer.name}`,
      });
    }

    if (body.messageType === "PAYMENT") {
      await logAudit({
        userId: session!.user.id,
        action: "CUSTOMER_PAYMENT_RECORDED",
        entityType: "Customer",
        entityId: customer.id,
        details: `Payment of ${Number(body.amount).toFixed(2)} recorded for ${customer.name}`,
      });
    }

    return NextResponse.json({ ...record, link }, { status: 201 });
  } catch (err) {
    console.error("POST /api/messages failed:", err);
    if (isStaleSessionError(err)) {
      return NextResponse.json(
        { error: "Your login session is out of date. Please log out and log back in, then try again." },
        { status: 401 }
      );
    }
    const message = err instanceof Error ? err.message : "Something went wrong preparing the message";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
