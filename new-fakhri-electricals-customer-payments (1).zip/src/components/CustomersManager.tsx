"use client";

import { useState } from "react";
import { balanceTagClass, formatBalance } from "@/lib/balanceFormat";

type Customer = { id: string; name: string; phone: string; address: string | null };
type BalanceInfo = { balance: number; sales: number; returns: number; payments: number };

export default function CustomersManager({
  initialCustomers,
  initialBalances,
}: {
  initialCustomers: Customer[];
  initialBalances: Record<string, BalanceInfo>;
}) {
  const [customers, setCustomers] = useState(initialCustomers);
  const [balances] = useState(initialBalances);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editAddress, setEditAddress] = useState("");
  const [editError, setEditError] = useState<string | null>(null);
  const [editSaving, setEditSaving] = useState(false);

  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deleteError, setDeleteError] = useState<Record<string, string>>({});

  function startEdit(c: Customer) {
    setEditingId(c.id);
    setEditName(c.name);
    setEditPhone(c.phone);
    setEditAddress(c.address || "");
    setEditError(null);
  }

  function cancelEdit() {
    setEditingId(null);
    setEditError(null);
  }

  function handleEditKeyDown(e: React.KeyboardEvent<HTMLInputElement>, id: string) {
    if (e.key === "Enter") {
      e.preventDefault();
      // Stop this Enter from also reaching KeyboardFormNav's document-level
      // listener — these three fields aren't wrapped in a form/nav-scope,
      // so without this it would fall back to hunting for "the next
      // focusable element on the whole page" (e.g. a customer row further
      // down, or a button elsewhere) instead of just saving this row.
      e.stopPropagation();
      saveEdit(id);
    } else if (e.key === "Escape") {
      e.preventDefault();
      cancelEdit();
    }
  }

  async function saveEdit(id: string) {
    setEditError(null);
    if (!editName.trim() || !editPhone.trim()) {
      setEditError("Name and phone are required");
      return;
    }
    setEditSaving(true);
    const res = await fetch(`/api/customers/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: editName.trim(),
        phone: editPhone.trim(),
        address: editAddress.trim() || null,
      }),
    });
    setEditSaving(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setEditError(data.error || "Could not save changes — try again");
      return;
    }

    const saved: Customer = await res.json();
    setCustomers((prev) => prev.map((c) => (c.id === id ? saved : c)));
    setEditingId(null);
  }

  async function handleDelete(c: Customer) {
    if (!window.confirm(`Delete ${c.name}? This can't be undone.`)) return;

    setDeleteError((prev) => ({ ...prev, [c.id]: "" }));
    setDeletingId(c.id);
    const res = await fetch(`/api/customers/${c.id}`, { method: "DELETE" });
    setDeletingId(null);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setDeleteError((prev) => ({
        ...prev,
        [c.id]: data.error || "Could not delete this customer — try again",
      }));
      return;
    }

    setCustomers((prev) => prev.filter((x) => x.id !== c.id));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!name.trim() || !phone.trim()) {
      setError("Name and phone are required");
      return;
    }

    const tempId = `temp-${Date.now()}`;
    const payload = { name: name.trim(), phone: phone.trim(), address: address.trim() || null };

    // Shows up in the list immediately — the network call happens in the
    // background instead of blocking the screen.
    setCustomers((prev) => [{ id: tempId, ...payload }, ...prev]);
    setName("");
    setPhone("");
    setAddress("");
    setSubmitting(true);

    const res = await fetch("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setSubmitting(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setCustomers((prev) => prev.filter((c) => c.id !== tempId));
      setError(data.error || "Could not add the customer — try again");
      setName(payload.name);
      setPhone(payload.phone);
      setAddress(payload.address || "");
      return;
    }

    const saved: Customer = await res.json();
    setCustomers((prev) => prev.map((c) => (c.id === tempId ? saved : c)));
  }

  return (
    <>
      <form onSubmit={handleSubmit} className="panel" style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 18, marginTop: 0 }}>Add a customer</h2>

        {error && <p className="error-text">{error}</p>}

        <div className="form-row">
          <div className="field" style={{ flex: 2, minWidth: 180 }}>
            <label htmlFor="name">Name</label>
            <input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="field" style={{ flex: 1, minWidth: 140 }}>
            <label htmlFor="phone">Phone</label>
            <input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} required />
          </div>
          <div className="field" style={{ flex: 2, minWidth: 180 }}>
            <label htmlFor="address">Address (optional)</label>
            <input id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>
          <button type="submit" className="btn-primary" style={{ marginBottom: 18 }}>
            Add customer
          </button>
        </div>
      </form>

      <div className="panel">
        {customers.length === 0 ? (
          <p className="muted">No customers yet — add the first one above.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Balance</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c) => {
                const info = balances[c.id];
                const isPending = c.id.startsWith("temp-") && submitting;
                const isEditing = editingId === c.id;
                const isDeleting = deletingId === c.id;

                if (isEditing) {
                  return (
                    <tr key={c.id} className="table-row-hover">
                      <td>
                        <input
                          autoFocus
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          onKeyDown={(e) => handleEditKeyDown(e, c.id)}
                          style={{ width: "100%" }}
                        />
                      </td>
                      <td>
                        <input
                          value={editPhone}
                          onChange={(e) => setEditPhone(e.target.value)}
                          onKeyDown={(e) => handleEditKeyDown(e, c.id)}
                          style={{ width: "100%" }}
                        />
                      </td>
                      <td>
                        <input
                          value={editAddress}
                          onChange={(e) => setEditAddress(e.target.value)}
                          onKeyDown={(e) => handleEditKeyDown(e, c.id)}
                          style={{ width: "100%" }}
                        />
                      </td>
                      <td>
                        {info ? (
                          <span className={balanceTagClass(info.balance)}>{formatBalance(info.balance)}</span>
                        ) : (
                          <span className="tag tag-paid">Fully settled</span>
                        )}
                      </td>
                      <td>
                        <div style={{ display: "flex", gap: 8 }}>
                          <button type="button" className="btn-primary" disabled={editSaving} onClick={() => saveEdit(c.id)}>
                            {editSaving ? "Saving…" : "Save"}
                          </button>
                          <button type="button" className="btn-secondary" disabled={editSaving} onClick={cancelEdit}>
                            Cancel
                          </button>
                        </div>
                        {editError && <p className="error-text" style={{ margin: "6px 0 0" }}>{editError}</p>}
                      </td>
                    </tr>
                  );
                }

                return (
                  <tr key={c.id} className="table-row-hover" style={isPending ? { opacity: 0.6 } : undefined}>
                    <td>{c.name}</td>
                    <td>{c.phone}</td>
                    <td>{c.address || "—"}</td>
                    <td>
                      {info ? (
                        <span
                          className={balanceTagClass(info.balance)}
                          title={`${info.sales} sale${info.sales === 1 ? "" : "s"} · ${info.returns} return${info.returns === 1 ? "" : "s"} · ${info.payments} payment${info.payments === 1 ? "" : "s"}`}
                        >
                          {formatBalance(info.balance)}
                        </span>
                      ) : (
                        <span className="tag tag-paid">Fully settled</span>
                      )}
                    </td>
                    <td>
                      {!c.id.startsWith("temp-") && (
                        <div style={{ display: "flex", gap: 8 }}>
                          <button type="button" className="btn-secondary" onClick={() => startEdit(c)}>
                            Edit
                          </button>
                          <button
                            type="button"
                            className="btn-secondary"
                            disabled={isDeleting}
                            onClick={() => handleDelete(c)}
                          >
                            {isDeleting ? "Deleting…" : "Delete"}
                          </button>
                        </div>
                      )}
                      {deleteError[c.id] && (
                        <p className="error-text" style={{ margin: "6px 0 0", maxWidth: 220 }}>
                          {deleteError[c.id]}
                        </p>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
